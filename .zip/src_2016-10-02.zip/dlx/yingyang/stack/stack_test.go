﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stack_test

import (
	"dlx/yingyang/stack"

	stacklist		"dlx/list/stack4list"
	stackelem		"dlx/list/stack4element"
	stacknormal		"dlx/yingyang/stack/normal/stack"
	stackccsafe		"dlx/yingyang/stack/concurrencysafe/stack"
)

func testListStack(s stack.ListStack) {}
func testElemStack(s stack.ElemStack) {}
func testAnyStack(s stack.AnyStack) {}

func ExampleSpot() {
	var ls = stacklist.New()
	testListStack(ls)

	var es = stackelem.New()
	testElemStack(es)

	var ns = stacknormal.New()
	testAnyStack(ns)

	var cs = stackccsafe.New()
	testAnyStack(cs)

}