﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
listmore.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- e.List()		*List
	- e.Values()		[]interface {}

	- NewList( v )	returns a list, the Root() of which carries v as Value

	- l.Root()		*Element
	- l.Elements()		[]*Element
	- l.Values()		[]interface {}

	- l.ValuesPushBack( v...)
	- l.ValuesPushFront( v...)

	- l.unList(a *List)
	- l.reList(a *List)
	- l.unListExcept(a *List, memo *Element)
	- l.reListExcept(a *List, memo *Element)

	- l.unLink(e *Element)
	- l.reLink(e *Element)

*/
package list

// ===========================================================================
// func (e *Element) ...

// List returns the list this element belongs to
func (e *Element) List() *List {
	return e.list
}

// Elements returns the Elements as a slice
// of the list of the element (syntactic sugar)
func (e *Element) Elements() []*Element {
	return e.List().Elements()
}

// Values returns the Values as a slice
// of the list of the element (syntactic sugar)
func (e *Element) Values() []interface {} {
	return e.List().Values()
}

// ===========================================================================
// func (l *List) ...

// NewList( v ) returns a list, the Root() of which carries v, (and is Away to nil)
func NewList ( v interface{} ) *List {
	var list = New()
	list.root.Value = v
	return list
}

// Root returns the root element of list l
func (l *List) Root() *Element {
	return &l.root
}

// Elements returns the elements of list l as a slice
func (l *List) Elements() []*Element {
	var data = make( []*Element, 0, l.Len() )
	for e := l.Front(); e != nil; e = e.Next() {
		data = append( data, e )
	}
	return data
}

// Values returns the Values as a slice
func (l *List) Values() []interface{} {
	var data = make( []interface{}, 0, l.Len() )
	for e := l.Front(); e != nil; e = e.Next() {
		data = append( data, e.Value )
	}
	return data
}

// ValuesPushBack appends a slice of Values
func (l *List) ValuesPushBack (values... interface{} ) {
//	valuesDo( l.PushBack, values... )
	for _, value := range values {
		l.PushBack( value )
	}
}

// ValuesPushFront prepends a slice of Values
func (l *List) ValuesPushFront (values... interface{} ) {
	valuesDo( l.PushFront, values... )
}

// valuesDo executes the given function on a slice of Values
func valuesDo (do func( v interface{} ) *Element, values... interface{} ) {
	for _, value := range values {
		do( value )
	}
}

/*
func (l *List) unList(a *List) {
// could also be done by calling l.ccListExcept(a, nil)
	for e := a.next; e != nil; e = e.next {
		l.unLink(e)
	}
}

func (l *List) reList(a *List) {
	for e := a.Root(); e != nil; e = e.Prev() {
		l.reLink(e)
	}
}

func (l *List) unListExcept(a *List, memo *Element) {
	for e := a.Root(); e != nil; e = e.Next() {
		if e != memo {
			l.unLink(e)
		}
	}
}

func (l *List) reListExcept(a *List, memo *Element) {
	for e := a.Root(); e != nil; e = e.Next() {
		if e != memo {
			l.reLink(e)
		}
	}
}
*/


// unLink a list's element (temporarily!) from it's list
func (l *List) unLink(e *Element) {
	if e.list != l {panic("not a member!")}
	e.unLink()
}

// reLink a list's temporarily unLinked element to it's list
func (l *List) reLink(e *Element) {
	if e.list != l {panic("not a member!")}
	e.reLink()
}

// unLink an element (temporarily!) from it's list
func (e *Element) unLink() {
	e.next.prev, e.prev.next = e.prev, e.next
	e.list.len--
}

// reLink a temporarily unLinked element to it's list
func (e *Element) reLink() {
	e.list.len++
	e.next.prev, e.prev.next = e, e
}
