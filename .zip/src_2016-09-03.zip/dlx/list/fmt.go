﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
fmt.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- e.PrintAways()
	- l.PrintValues()
	- e.PrintValue()

*/
package list

import (
	"fmt"
)
// ===========================================================================

func (e *Element) PrintAways( args... interface{} ) {
	if args != nil {
		fmt.Print(args)
	}
	if e == nil {
		fmt.Println( "Element is nil!" )
		return
	}
	if e.away == nil {
		fmt.Println( "Element's Away is nil!" )
		return
	}
	e.away.list.PrintValues()
}

func (l *List) Print( args... interface{} ) {
	if args != nil {
		fmt.Print(args)
	}
	if l == nil {
		fmt.Println( "List is nil!" )
		return
	}
	fmt.Print( "List=" )
	fmt.Print( l.root.Value )
	fmt.Print( " | " )
	fmt.Print( "Total=" )
	fmt.Println( l.len )
}

func (l *List) PrintValues( args... interface{} ) {
	if args != nil {
		fmt.Print(args)
	}
	if l == nil {
		fmt.Println( "List is nil!" )
		return
	}
	fmt.Print( "List=" )
	fmt.Println( l.root.Value )
	// Iterate through list and print its contents.
	for e := l.Front(); e != nil; e = e.Next() {
		fmt.Print( e.Value )
		fmt.Print( " | ")
	}
	fmt.Print( "Total=" )
	fmt.Println( l.len )
}

func (e *Element) PrintValue( args... interface{} ) {
	fmt.Println(args)
	if e == nil { return }
	fmt.Println(e.Value)
}

