﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
listaway.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- e.Away()		*Element
	- e.Junk (x *Element)	// cross-links Away's
	- e.unCover()
	- e.reCover()
	- e.unListAway()
	- e.reListAway()

	- l.AddBeam
	- l.AddList

*/
package list

// Away returns the away element (an element of the orthogonal fiber-list)
func (l *List) Away() *Element {
	return l.root.away
}

// Away returns the away element (an element of the orthogonal fiber-list)
func (e *Element) Away() *Element {
	return e.away
}

/* Is this needed by the outer world?
// SetAway sets the away (an element of the orthogonal fiber-list)
// If e == mark or e and mark are element of the same list, the element is not modified.
// NOTE: only any new List's list-Element points to itself!
func (e *Element) SetAway(away *Element) {
	if e == away || e.list == away.list {
		return
	}
	e.away = away
}
*/

// Junk is a Link as a Junc-tion of the elements
// Who needs such garbage? ;-)
func (e *Element) Junk (x *Element) {
	if e.away != nil {panic("away in e already set!")}
	if x.away != nil {panic("away in x already set!")}
	x.away = e
	e.away = x
}


func (l *List) AddBeam ( v interface{}, dots... interface{} ) *List {

	var list = NewList( v )
	list.ValuesPushBack( dots... )

	return l.AddList( v, list )
}

func (l *List) AddList ( v interface{}, list *List ) *List {

	var head = l.PushBack( v )
	list.root.Junk( head )
//	head.Junk( list.Root() )

	return list
}

func (e *Element) unCover() {
	e.away.unLink()
	for i := e.next; i != e && i != nil; i = i.next	{
		i.away.unListAway()
//		for j := i.away.next; j != i.away && j != nil; j = j.next	{
//			j.away.unLink()
//		}
	}
}

func (e *Element) reCover() {
	for i := e.prev; i != e && i != nil; i = i.prev	{
		i.away.reListAway()
//		for j := i.away.prev; j != i.away && j != nil; j = j.prev	{
//			j.away.reLink()
//		}
	}
	e.away.reLink()
}

// unList the away's along an element's list
func (e *Element) unListAway() {
	for i := e.next; i != e && i != nil; i = i.next	{
		i.away.unLink()
	}
}

// renList the away's along an element's list
func (e *Element) reListAway() {
	for i := e.prev; i != e && i != nil; i = i.prev	{
		i.away.unLink()
	}
}
