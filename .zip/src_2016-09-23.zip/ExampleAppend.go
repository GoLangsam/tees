﻿// Copyright 2013 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main

// package list_test

import (
	"dlx/list"
)

//func ExampleAppend() {
func main() {
	// Create a new list
	var atom = list.NewList( "Atom" )
	var dark = list.NewList( "Dark" )

	var ds = atom.AddBeam( "Zahlen", 1, 2, 3 )		// int
	var as = atom.AddBeam( "Staben", "A", "B", "C" )		// char
	var ws = atom.AddBeam( "Wörter", "foo", "bar" )		// string
	var bs = atom.AddBeam( "Boolen", true, false )		// bool
//	var vs = atom.AddBeam( "Verbos", list.Verbose )		// some data

// So far, we have 2 * 8 Atom's - and that's all we need.
// All else is going to be built from these atoms

	atom.Print( "Starting" )
//	atom.PrintAtomValues( "sky" )
//	atom.PrintAways()

	var plus = dark.AddBeam( "Append" )
	plus.AddList( ds.Append() )
	plus.AddList( ds.Append(as) )
	plus.AddList( ds.Append(as, bs) )

	var mult = dark.AddBeam( "Times" )
	mult.AddList( ds.Times() )
	mult.AddList( ds.Times( ws ) )
	mult.AddList( ds.Times( ws, bs ) )
	mult.AddList( bs.Times( ws, ds ) )

	dark.Print( "Dark" )
	dark.PrintAways()

	plus.Print( "Plus" )
	plus.PrintAways()

	mult.Print( "Mult" )
	mult.PrintAways()

}
