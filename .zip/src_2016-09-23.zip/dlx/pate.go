﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
Pate is german for GodFather. Thus, a Pate is a god - somehow.

What to do?

pray towards him (if You like): send a Prayer on chan 'pray'
hear from/to him (if You like): recv a Glimps on chan 'hear' (glimpse is what You do, Glimp is what You get ;-)

Prayer is a structure, and it talks about
- please timeout (I do not like to wait for eternity)
- please vanish (and leave no traces of what You've been busy with. Thus: Undo Your actions first)
- please change (I reconsidered applicable tactic)

- please abort (I do not like to keep waiting, I'd like to play myself. )
- please reset (Thus: Undo Your actions, and let me reconsider)
- please cease (and leave no traces of what You've been busy with)

- please freeze (I'd like to look myself. Unfreeze, if I pray a change)

- please oracle (I'd like to know "what's going on?" Gimme some statistics ...

Glimps is a structure, and it talks about
- Statistics about how I'm doing (Levels of play, size of current board, #-of-Eons ...
- Solutions - what has been found while playing

tactic is a structure, and it talks about
- wether to keep detailed stats
- wether to play verbose - printing some log to sys.stdout or another io.Writer ...)
- wether to talk Glimps (with (detailed?) stats) once-in-a-while
- wether to talk Glimps (with (detailed?) stats) upon certain events (e.g. Level-#)
- wether to keep going (or just reset & return)

- #-of-eons for freeze (timeout)
- #-of-eons for oracle (talk once-in-a-while)
- #-of-deep for oracle (talk upon Level-#-of-deep)

- Rules of the game - that is: func()'s to be used, such as
  - NextStep (how to find a column)
  	- i.e. if only "optionals" are left, let me hear a Glimps with this solution, and tack back ...
  - ReBase (how to adjust info's such as weights/penalties, which may be relevant for NextStep)

*/

package dlx