﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
listmore.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- e.List()		*List

	- NewList( v )	returns a list, the Root() of which carries v as Value

	- l.Root()		*Element

	- l.ValuesPushBack( v...)
	- l.ValuesPushFront( v...)

*/
package list

// ===========================================================================
// NewList( v ) returns a list, the Root() of which carries v, (and is Away to nil)
func NewList ( v interface{} ) *List {
	var list = New()
	list.root.Value = v
	return list
}

// ===========================================================================
// func (l *List) ...

// Clear removes all elements from the list l,
// but leaves it's root's away untouched (different from Init() ).
func (l *List) Clear() *List {
	l.root.next = &l.root
	l.root.prev = &l.root
//	l.root.away	// not touched
	l.root.list = l
	l.len = 0
	return l

}

// Move

// Root returns the root element of list l
func (l *List) Root() *Element {
	return &l.root
}

// Binary bool

// Equals reports whether the lists l and t have the same element-values.
func (l *List) Equals(t *List) bool {

	if l == t {
		return true
	}
	le := l.root.next
	te := t.root.next
	for {
		switch {
		case le == &l.root && te == &t.root:
			return true
		case le == &l.root || te == &t.root:
			return false
		case !le.Equals( te ):
			return false
		}

		le = le.next
		te = te.next
	}
}

// bool

// IsEmpty reports whether the list l is empty.
func (l *List) IsEmpty() bool {
	return l.root.next == &l.root
}

// IsSolo reports whether the list l has no Away()
func (l *List) IsSolo() bool {
	return l.root.away == nil
}


// ===========================================================================
// func (e *Element) ...
// Move

// List returns the list this element belongs to
func (e *Element) List() *List {
	return e.list
}

// Binary bool

// Equals reports whether the elements e and i have the same values.
func (e *Element) Equals(i *Element) bool {
	return e.Value == i.Value
}

// Junks reports whether the elements e and i are Junk'ed
func (e *Element) Junks(i *Element) bool {
	return ( e.away == i ) && ( i.away == e )
}

// bool

// IsRoot reports whether the element e is Root() of it's list
func (e *Element) IsRoot() bool {
	return ( e == &e.list.root )
}

// IsNode: an element which is not root can be seen as a node
func (e *Element) IsNode() bool {
	return ( e != &e.list.root )
}

// IsSolo reports whether the element e has no Away()
func (e *Element) IsSolo() bool {
	return e.away == nil
}

// IsJunk reports whether the element e has it's Away() Junk'ed
func (e *Element) IsJunk() bool {
	return ( e.away != nil ) && ( e == e.away.away )
}
