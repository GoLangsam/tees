﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
stack.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- push ( e )
	- top()		*List
	- pop()		*List

*/
package list

var stack []*List

// push List
func push(e *List) {
	stack = append(stack, e)
}

// top of stack
func top() *List {
	return stack[len(stack)-1]
}

// pop Element
func pop() *List {
	p := top()
	stack = stack[:len(stack)-1]
	return p
}

/*
func (s stack) len() int {
	return len(s)
}
*/

