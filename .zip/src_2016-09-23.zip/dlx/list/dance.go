﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dance.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- l.Dance( dance func() )
	- e.Dance( dance func() )

- on Cols:
	- l.fold()	l.unShow(col)			& unLink( Col-Head )
	- l.open()	l.reShow(col)			& reLink( Col-Head )

- on Rows - walking hori:
	- e.fold()	e's.away.list.fold(col)		except e.list.root (row head)
	- e.open()	e's.away.list.open(col)		except e.list.root (row head)

- on Cols - walking vert: (no need to skip root explicitly, as it's called for l.root)
	- l.unShow()	l's.away.unList(row)
	- l.reShow()	l's.away.reList(row)
	- e.unShow()	e's.away.unList(row)
	- e.reShow()	e's.away.reList(row)

- on Rows - walking hori:
	- e.unList()	e's.away.unLink(col)		except e.list.root (row head)
	- e.reList()	e's.away.reLink(col)		except e.list.root (row head)

	- e.unLink()
	- e.reLink()

*/
package list

// ========================================================
// Dance is where the dancing begins
func (l *List)     Dance( dance func() ) {
	l.fold()
	l.root.Dance( dance )
	l.open()
}

// Dance is where the dancing continues
func (e *Element)  Dance( dance func() ) {
	for i := e.next; i != e; i = i.next {
		push( i.away.list )
		i.away.fold()
		dance()		// recursive callback
		i.away.open()
		pop()
	}
}

// ========================================================
func (l *List)      fold() { 						l.root.away.unLink();	l.unList()		    }
func (l *List)      open() { 						l.root.away.reLink();	l.reList()		    }

func (e *Element)   fold() { for i := e.next; i != e; i = i.next { if i != &e.list.root {	i.away.list.fold()	} } }
func (e *Element)   open() { for i := e.prev; i != e; i = i.prev { if i != &e.list.root {	i.away.list.open()	} } }

func (l *List)    unList() { for i := l.root.next; i != &l.root; i = i.next { 			i.away.unList()		  } }
func (l *List)    reList() { for i := l.root.prev; i != &l.root; i = i.prev { 			i.away.reList()		  } }

func (e *Element) unList() { for i := e.next; i != e; i = i.next { if i != &e.list.root {	i.away.unLink()		} } }
func (e *Element) reList() { for i := e.prev; i != e; i = i.prev { if i != &e.list.root	{	i.away.reLink()		} } }

func (e *Element) unLink() {          e.next.prev, e.prev.next = e.prev, e.next;		e.list.len--		    }
func (e *Element) reLink() {          e.next.prev, e.prev.next = e, e;				e.list.len++		    }

// ========================================================
// forEachNext applies function f to each element of the list l in natural order.
// forEachPrev applies function f to each element of the list l in reverse order.
//
// f must not mutate l.
// Consequently, forEach is not safe to expose to clients.
// In any case, using "range l.AppendTo()" allows more
// natural control flow with continue/break/return.
//
func (l *List) forEachNext( f func(*Element) ) {
	for e := l.root.next; e != &l.root; e = e.next {	f( e ) }
}
func (l *List) forEachPrev( f func(*Element) ) {
	for e := l.root.prev; e != &l.root; e = e.prev {	f( e ) }
}


// forEachNext applies function f to each other element of e's list in natural order.
// forEachPrev applies function f to each other element of e's list in reverse order.
func (e *Element) forEachNext( f func(*Element) ) {
	for i := e.next; i != e; i = i.next { if i != &e.list.root {	f( i )	} }
}
func (e *Element) forEachPrev( f func(*Element) ) {
	for i := e.prev; i != e; i = i.prev { if i != &e.list.root {	f( i )	} }
}


func (l *List)    unListSlow() { l.forEachNext (func(e *Element) {e.away.unListSlow()} ) }
func (l *List)    reListSlow() { l.forEachPrev (func(e *Element) {e.away.reListSlow()} ) }

func (e *Element) unListSlow() { e.forEachNext (func(i *Element) {i.away.unLink()} ) }
func (e *Element) reListSlow() { e.forEachPrev (func(i *Element) {i.away.reLink()} ) }

