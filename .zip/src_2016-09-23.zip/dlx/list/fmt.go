﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
fmt.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- e.PrintAways()

	- l.Print()
	- l.PrintValues()
	- e.PrintValue()

*/
package list

import (
	"fmt"
)
// ===========================================================================
func (l *List) PrintAways( args ...interface{} ) {
	if l.print ( args... ) {
//		fmt.Print( "List=" )
		l.Print()
//		fmt.Print( "\t" )
		// Iterate through list and print its contents.
		for e := l.Front(); e != nil; e = e.Next() {
			e.PrintAways()
//			fmt.Print( " | ")
		}
//		fmt.Print( "Total=" )
//		fmt.Println( l.len )
	}
}

func (e *Element) PrintAways( args ...interface{} ) {
	if e.print ( args... ) {
		if e.away == nil {
			fmt.Println( "Element's Away is nil!" )
			return
		}
		e.away.list.PrintAtomValues("=> ")
	}
}

func (l *List) Print( args ...interface{} ) {
	if l.print ( args... ) {
		fmt.Print( "List=" )
		l.root.printAtomValues()
		fmt.Print( " | " )
		fmt.Print( "Total=" )
		fmt.Println( l.len )
	}
}

// ===========================================================================
func (l *List) PrintValue( args... interface{} ) {
	if l.print ( args... ) {
		l.Root().PrintValue()
	}
}

func (e *Element) PrintValue( args... interface{} ) {
	if e.print ( args... ) {
		e.printAtomValues()
	}
}

// ===========================================================================
func (l *List) PrintAtomValues( args... interface{} ) {
	if l.print ( args... ) {
		fmt.Print( "List=" )
		l.root.printAtomValues()
		fmt.Print( "\t" )
		// Iterate through list and print its contents.
		for e := l.Front(); e != nil; e = e.Next() {
			e.printAtomValues()
			fmt.Print( " | ")
		}
		fmt.Print( "Total=" )
		fmt.Println( l.len )
	}
}

func (e *Element) PrintAtomValues( args... interface{} ) {
	if e.print ( args... ) {
		fmt.Print( "Element=" )
		e.printAtomValues()
	}
	fmt.Println( "." )
}

// printAtomValues:
func (e *Element) printAtomValues() {
	switch ev := e.Value.(type) {
		case *compositeValue:
			for i, x := range *ev {
				x.printAtomValues()
				if i+1 < len( *ev ) {fmt.Print("|")}
			}
		default:
			fmt.Print( e.Value )
	}
}


// ===========================================================================
func (l *List) print( args... interface{} ) bool {
	printArgs( args... )
	if l == nil {
		fmt.Println( "List is nil!" )
		return false
	}
	return true
}

func (e *Element) print( args... interface{} ) bool {
	printArgs( args... )
	if e == nil {
		fmt.Println( "Element is nil!" )
		return false
	}
	return true
}

// ===========================================================================
func printArgs( args... interface{} ) {
	if args != nil {
		fmt.Print(args... )
		fmt.Print(": ")
	}
}
