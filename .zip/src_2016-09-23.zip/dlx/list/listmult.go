﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
listmult.go extends the (stolen and extended) list.go
with operations such as addition and multiplication
*/
package list

// Append returns a new list: the union of l with some lists...
// ( recursively as l [ * [ l * [ ... ]]] )
// Note: l.Append( nil ) returns a new copy of l
// the root of which carries the eVs of the original l.Root()
// and the elements carry the eVs of the original elements
// TODO: What is new title???
func (l *List) Append ( lists... *List ) *List {
	if len(lists) == 0 {	return l.append( nil ) }
	if len(lists) == 1 {	return l.append( lists[0] ) }
				return l.append( lists[0].Append( lists[1:]... ) )
}

// append returns a new list with len(l) + len(X) Elements
// representing the union of the list l plus X
// Note: l.append( nil ) returns a new list with no elements
func (l *List) append ( Y *List ) *List {
	newl := NewList( l.eVs() )
	for x := l.Front(); x != nil; x = x.Next() {
		newl.PushBack( x.eVs() )
	}
	if Y == nil { return newl }

	newl.root.Value = l.with(Y)
	for y := Y.Front(); y != nil; y = y.Next() {
		newl.PushBack( y.eVs() )
	}
	return newl
}

// ===========================================================================

// Times returns a new list: the cross product of l with some lists...
// ( recursively as [[[ l * l ] * l ] ... ] )
// Note: l.Times( nil ) returns a new empty list
// the root of which carries the eVs of the original l.Root()

func (l *List) Times ( lists ...*List ) *List {
	if len(lists) == 0 {	return NewList( l.eVs() )  }
	if lists[0] == nil {	return NewList( l.eVs() )  }
	if len(lists) == 1 {	return l.times( lists[0] ) }
	prod := l.times( lists[0] )
	return prod.Times( lists[1:]... )
}

// times returns a new list with len(l) * len(X) Elements
// representing the cross-product of the list l times X
// Note: l.times( nil ) returns a new list with no elements
func (l *List) times ( Y *List ) *List {
	prod := NewList( l.with(Y) )
	for x := l.Front(); x != nil; x = x.Next() {
		for y := Y.Front(); y != nil; y = y.Next() {
			prod.PushBack( x.with(y) )
		}
	}
	return prod
}

// ===========================================================================

// Xross returns a new list: the cross product of X with Y
// the returned list is a handle to the X-Dimension
// the elements are Junk'ed
// such Xross may be explored by Step Jump Walk Tour ...
func (l *List) Xross ( X, Y *List ) *List {

	cols := make([]*List,0,X.Len() )

	var xl = NewList( X.eVs() )
	for x := X.Front(); x != nil; x = x.Next() {
		cols = append( cols, xl.AddBeam( x.eVs() ) )
	}

	var yl = NewList( Y.eVs() )
	for y := Y.Front(); y != nil; y = y.Next() {
		yl.AddJunk( y.eVs(), cols... )		// use AddOnes to keep elements light (Value = <nil>)
	}
	xl.root.Junk( &yl.root )

	return xl
}

// ===========================================================================
// helpers(e *Element)

type compositeValue []*Element

// with returns a new slice of *Element to be used as new Value
func(l *List) with( x *List ) *compositeValue {
	return l.root.with( &x.root )
}

func(e *Element) with( x *Element ) *compositeValue {
	var r compositeValue = make ([]*Element, 0, e.vLen() + x.vLen() )
	r = append (r, *e.eVs()... )
	r = append (r, *x.eVs()... )
	return &r
}

func(e *Element) vLen() int {
	switch ev := e.Value.(type) {
		case *compositeValue:	return len( *ev )
		default:		return 1
	}
}

// eVs returns a slice of *Element to be used as new Value
func(l *List) eVs() *compositeValue {
	return l.root.eVs()
}

// eVs returns a slice of *Element to be used as new Value
// if e.IsAtom() the slice has length one and contains e
// else the existing slice of atoms is returned
func(e *Element) eVs() *compositeValue {
	switch ev := e.Value.(type) {
		case *compositeValue:	return ev
		default:		return &compositeValue{ e }
	}
}

// IsComposed: an element which is composed (and thus carries a Value.(type) []*Element)
func(l *List) IsComposed() bool {
	return l.root.IsComposed()
}

// IsComposed: an element which is composed (and thus carries a Value.(type) []*Element)
func(e *Element) IsComposed() bool {
	switch e.Value.(type) {
		case *compositeValue:	return true
		default:		return false
	}
}

// IsAtom: an element which is not composed
func (l *List) IsAtom() bool {
	return l.root.IsAtom()
}

// IsAtom: an element which is not composed
func (e *Element) IsAtom() bool {
	switch e.Value.(type) {
		case *compositeValue:	return false
		default:		return true
	}
}
/*
// AtomValues:
func (l *List) AtomValues() []interface{} {
	return l.root.AtomValues()
}

// AtomValues:
func (e *Element) AtomValues() []interface{} {
	switch ev := e.Value.(type) {
		case *compositeValue:
			r := make([]interface{}, 0, len( *ev ) )
			for _, x := range *ev {
				r = append( r, x.AtomValues()... )
			}
			return r

		default:
			return []interface{}{ e.Value }
	}
}
*/