﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
listmany.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- e.Values()		[]interface {}

	- l.Elements()		[]*Element
	- l.Values()		[]interface {}

	- l.ValuesPushBack( v...)
	- l.ValuesPushFront( v...)

*/
package list

// ===========================================================================
// func (e *Element) ...

// Elements returns the Elements as a slice
// of the list of the element (syntactic sugar)
func (e *Element) Elements() []*Element {
	return e.List().Elements()
}

// Values returns the Values as a slice
// of the list of the element (syntactic sugar)
func (e *Element) Values() []interface {} {
	return e.List().Values()
}

// ===========================================================================
// func (l *List) ...

// Elements returns the elements of list l as a slice
func (l *List) Elements() []*Element {
	var data = make( []*Element, 0, l.Len() )
	for e := l.Front(); e != nil; e = e.Next() {
		data = append( data, e )
	}
	return data
}

// Values returns the Values as a slice
func (l *List) Values() []interface{} {
	var data = make( []interface{}, 0, l.Len() )
	for e := l.Front(); e != nil; e = e.Next() {
		data = append( data, e.Value )
	}
	return data
}

// ValuesPushBack appends a slice of Values
func (l *List) ValuesPushBack (values... interface{} ) {
	valuesDo( l.PushBack, values... )
}

// ValuesPushFront prepends a slice of Values
func (l *List) ValuesPushFront (values... interface{} ) {
	valuesDo( l.PushFront, values... )
}

// valuesDo executes the given function on a slice of Values
func valuesDo (do func( v interface{} ) *Element, values... interface{} ) {
	for _, value := range values {
		do( value )
	}
}

