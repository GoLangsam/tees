﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*

// GoTo is an alias for a kind of function to reach another existing element (or nil) from some element e

// From returns the *list.Element (or nil) reached from e by applying some Kata's (=[]GoTo)

// Grab returns the slice of *list.Element reached from e
// Haul returns the slice of *list.Element reached from e keeping going until same or nil

// JumpXyz returns a predefined Kata
// ChessXyz returns a predefined Akas (e.g. of a chess figure)
*/
package walk

import (
	"dlx/list"
)

// GoTo's represent basic functions to Step from some element to another existing element (or nil)
type GoTo uint8	// func( *list.Element ) *list.Element

// Distance represents the 'length' of some movement
type Distance uint

/*
type Journey []*list.Element

type Walker interface {
	From (*list.Element ) (*list.Element, Distance)
	Grab (*list.Element ) ([]*list.Element, Distance)
	Haul (*list.Element ) ([]*list.Element, Distance)
}
*/

const (
	Next	GoTo = iota
	Prev
	Away
	Root
	Head
	Tail
	Home
)

// Kata (Japanese) is a form of movement (in martial arts)
type Kata []GoTo // Japanese

// Akas (Burmese) is a slice of forms of movement (in martial arts, and dances :-) )
type Akas []Kata // Burmese


// from returns the Element (or nil) reached from e by applying GoTo
func ( g GoTo ) from (e *list.Element) (*list.Element, Distance) {

	var dist Distance
	var next *list.Element	= e

	if e != nil {
		switch g {
		case Next:	next = e.Next(); if next != nil { dist = 1 }
		case Prev:	next = e.Prev(); if next != nil { dist = 1 }
		case Away:	next = e.Away()
		case Root:	next = e.List().Root()
		case Head:	next = e.List().Front()
		case Tail:	next = e.List().Back()
		case Home:	next = e				// Homerun is long, but free :-)
				for i := next.List().Root().Away(); i != nil && i != e && i != next; i = i.List().Root().Away() {
					next = i
				}

		default:	panic( "Undefined value for GoTo" )
		}
	}
	return next, dist
}

// ========================================================

// From returns the Element (or nil) reached from e by steps
func (steps Kata) From ( e *list.Element ) (*list.Element, Distance) {
	var dist, dnow Distance
	goal := e
	for _, step := range steps {
		if goal == nil { return nil, dist }
		goal, dnow = step.from( goal )
		dist+=dnow
	}
	return goal, dist
}

// From returns the non-nil Elements reached from e by jumps
func (jumps Akas) From ( e *list.Element ) ([]*list.Element, Distance) {
	var dist, dnow Distance
	goal := e
	goals := make([]*list.Element,  0, len(jumps) )
	for _, steps := range jumps {
		goal, dnow = steps.From( e )
		if goal == nil { continue }
		goals = append(goals, goal)
		dist+=dnow
	}
	return goals, dist
}

// ========================================================

// Grab returns all Elements reached from e by steps
// until nil or same is found
// Note: Grab may be useful in debugging, as it returns a full trace
// To Grab is not intended for regular use - Don't be greedy :-)
func (steps Kata) Grab (e *list.Element) ([]*list.Element, Distance) {
	var dist, dnow Distance
	goal := e
	last := goal
	goals := make([]*list.Element,  0, len(steps) )
	for _, step := range steps {
		last = goal
		goal, dnow = step.from( goal )
		if goal == nil || goal == last { continue }
		goals = append(goals, goal)
		dist+=dnow
	}
	return goals, dist
}

// Grab returns all Elements reached from e by jumps
// Note: Grab may be useful in debugging, as it returns a full trace
// To Grab is not intended for regular use - Don't be greedy :-)
func (jumps Akas) Grab (e *list.Element) ([]*list.Element, Distance) {
	var dist Distance
	goals := make([]*list.Element,  0, len(jumps)*len(jumps) )
	for _, steps := range jumps {
		goal, dnow := steps.Grab( e )
		if goal == nil || len(goal) == 0 { continue }
		goals = append(goals, goal...)
		dist+=dnow
	}
	return goals, dist
}

// ========================================================

// Haul returns the Elements (or nil) From e by repeating steps
// until nil or same is found
func (steps Kata) Haul ( e *list.Element ) ([]*list.Element, Distance) {
	var dist, dnow Distance
	goal := e
	last := goal
	goals := make([]*list.Element, 0, len(steps)*8 )
	for {
		last = goal
		goal, dnow = steps.From( goal )
		if goal == nil || goal == last { return goals, dist }
		goals = append(goals, goal)
		dist+=dnow
	}
}

// Haul returns the Elements (or nil) From e by repeating jumps
// until nil or same is found
func (jumps Akas) Haul ( e *list.Element ) ([]*list.Element, Distance) {
	var dist Distance
	goals := make([]*list.Element, 0, len(jumps)*len(jumps)*8 )
	for _, steps := range jumps {
		goal, dnow := steps.Haul( e )
		if goal == nil || len(goal) == 0 { continue }
		goals = append(goals, goal...)
		dist+=dnow
	}
	return goals, dist
}

// For Your convenience: Some predefined Jump's:
// for the basic GoTo's
	var JumpPrev	Kata = []GoTo{ Prev }
	var JumpNext	Kata = []GoTo{ Next }
	var JumpAway	Kata = []GoTo{ Away }
	var JumpRoot	Kata = []GoTo{ Root }
	var JumpHead	Kata = []GoTo{ Head }
	var JumpTail	Kata = []GoTo{ Tail }

// for composed movement
// Orthogonal
// Hint: Think of a right-hand matrix (or chessboard), look at a horizontal element
// Note: A Spreadsheet or Matrix is usually left(!)-handed, Rows go down!!!
	var JumpAwayPrev	Kata = []GoTo{ Away, Prev, Away }		//	= Up
	var JumpAwayNext	Kata = []GoTo{ Away, Next, Away }		//	= Down
	var JumpUp		Kata = JumpAwayPrev
	var JumpDown		Kata = JumpAwayNext

// next/prev orthogonal fiber
	var JumpNextHead	Kata = []GoTo{ Root, Away, Next, Away, Head }
	var JumpNextTail	Kata = []GoTo{ Root, Away, Next, Away, Tail }
	var JumpPrevHead	Kata = []GoTo{ Root, Away, Prev, Away, Head }
	var JumpPrevTail	Kata = []GoTo{ Root, Away, Prev, Away, Tail }

// Diagonal
	var JumpDiagonalNU	Kata = []GoTo{ Next, Away, Prev, Away }		//	= Next, AwayPrev
	var JumpDiagonalND	Kata = []GoTo{ Next, Away, Next, Away }		//	= Next, AwayNext
	var JumpDiagonalPU	Kata = []GoTo{ Prev, Away, Prev, Away }		//	= Prev, AwayPrev
	var JumpDiagonalPD	Kata = []GoTo{ Prev, Away, Next, Away }		//	= Prev, AwayPrev

// Diagonal - chess: King:Jump, Bishop:Tour, Queen:Tour
	var JumpRightUp		Kata = JumpDiagonalNU
	var JumpRightDown	Kata = JumpDiagonalND
	var JumpLeftUp		Kata = JumpDiagonalPU
	var JumpLeftDown	Kata = JumpDiagonalPD

// Knight's
	var JumpKnight_NNU	Kata = []GoTo{ Next, Next, Away, Prev, Away }	//	= Next, RightUp
	var JumpKnight_NND	Kata = []GoTo{ Next, Next, Away, Next, Away }	//	= Next, RightDown
	var JumpKnight_PPU	Kata = []GoTo{ Prev, Prev, Away, Prev, Away }	//	= Prev, RightUp
	var JumpKnight_PPD	Kata = []GoTo{ Prev, Prev, Away, Next, Away }	//	= Prev, RightDown
	var JumpKnight_UUP	Kata = []GoTo{ Away, Prev, Prev, Away, Prev }	//
	var JumpKnight_UUN	Kata = []GoTo{ Away, Prev, Prev, Away, Next }	//
	var JumpKnight_DDP	Kata = []GoTo{ Away, Next, Next, Away, Prev }	//
	var JumpKnight_DDN	Kata = []GoTo{ Away, Next, Next, Away, Next }	//

// Chess
	var ChessKing		Akas = []Kata{ JumpPrev, JumpNext, JumpUp, JumpDown, JumpRightUp, JumpRightDown, JumpLeftUp, JumpLeftDown }
// Note: King Grab's only, others Haul!

	var ChessRook		Akas = []Kata{ JumpPrev, JumpNext, JumpUp, JumpDown }
	var ChessBishop		Akas = []Kata{                                       JumpRightUp, JumpRightDown, JumpLeftUp, JumpLeftDown }
	var ChessQueen		Akas = []Kata{ JumpPrev, JumpNext, JumpUp, JumpDown, JumpRightUp, JumpRightDown, JumpLeftUp, JumpLeftDown }

	var ChessKnight		Akas = []Kata{
		JumpKnight_NNU,
		JumpKnight_NND,
		JumpKnight_PPU,
		JumpKnight_PPD,
		JumpKnight_UUP,
		JumpKnight_UUN,
		JumpKnight_DDP,
		JumpKnight_DDN }