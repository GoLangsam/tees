﻿// Copyright 2013 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main

// package list_test

import (
	"dlx/list"
	"dlx/walk"
	"fmt"
)

//func ExampleWalk() {
func main() {
	// Create a new list
	var chess = list.NewList( "Chess" )

	// Create new lists
	var rows = chess.AddBeam( "Zeilen", 1, 2, 3, 4 )
	var cols = chess.AddBeam( "Spalten", "A", "B", "C", "D" )
	if false {
		chess.Print( "Starting" )
		chess.PrintAways()
	}

//	rows.PrintAtomValues()
//	cols.PrintAtomValues()

	var board = chess.Xross( cols, rows )

	if false {
	board.Print( ".Xross( cols, rows )" )
//	board.PrintValues()
	board.PrintAtomValues( "Columns" )
//	board.Print()
	board.PrintAways()
//	board.Root().Away().List().Print()
	board.Root().Away().List().PrintAways()

	board.PrintAtomValues( "board \t")
	board.Root().Away().List().PrintAtomValues( "board.Root().Away().List().Root().Away() \t")
	board.Front().PrintAtomValues("board.Front() \t")
	board.Front().Away().PrintAtomValues("board.Front().Away() \t")
	board.Front().Away().List().PrintAtomValues("board.Front().Away().List() \t")
	board.Front().Away().Next().PrintAtomValues("board.Front().Away().Next() \t")
	board.Front().Away().List().Front().PrintAtomValues("board.Front().Away().List().Front() \t")
	board.Front().Away().List().Front().Away().PrintAtomValues("board.Front().Away().List().Front().Away() \t")
	}

	s := board.Front().Away().List().Front()	// A|1
	m := s.Next().Away().Next().Away()		// B|2
	e := board.Back().Away().List().Back()		// D|4
//	walk := walk.ChessRook
//	walk := walk.JumpNext
//	walk := walk.JumpRightDown
//	walk := walk.JumpDown
//	walk := walk.JumpAway


	if false {
	fmt.Println( "\nJumpNext" )
	walk.JumpNext.PrintFullWalk( s )
	walk.JumpNext.PrintFullWalk( m )
	walk.JumpNext.PrintFullWalk( e )

	fmt.Println( "\nJumpDown" )
	walk.JumpDown.PrintFullWalk( s )
	walk.JumpDown.PrintFullWalk( m )
	walk.JumpDown.PrintFullWalk( e )

	fmt.Println( "\nJumpRightDown" )
	walk.JumpRightDown.PrintFullWalk( s )
	walk.JumpRightDown.PrintFullWalk( m )
	walk.JumpRightDown.PrintFullWalk( e )
}
	fmt.Println( "\nChessRook" )
//	walk.ChessRook.PrintFullWalk( s )
	walk.ChessRook.PrintFullWalk( m )
//	walk.ChessRook.PrintFullWalk( e )

/* Now, we have:
- the cols
- the rows
- the "Board" (=rows.Times( cols ) - at length
- the board (=.Xross( rows, cols )

We need to Tour the board.
the Elements carry their [x,y] coordinate-Elements.
And wait: these could/should be coordinate-Elements as well.
These we like to drop into some
a NewDots - frame (to become the sparse matrix for Search)
shall be initialzied from "Board", (or from serialized board.Elements())
But then, how to find the new Column given the 'original'?

We need to remember, what we already have!
Two maps[ original*Element ] new*Element might help, one for each axis
Thus: We need a typ Matrix struct. And this might be carried by the root.
or even: each root carries it's map of members?!
or better: each root carries it's memo of members?! Concurrency-Safe!
Then, for each cell (which becomes a row) we 'only' need to drop the tuple of the underlying atoms

This 'Root.Element' carries map can be applied to constructors such as AddBeam as well!!!
And AddList 'remembers'; AddOnes ???

Idea: Walk & Tour could report their "length"
Well, it's the len of the result, anyway?
No! Different GoTo have different length! Next=1, Away=0, Home=many
*/

/*
Kata - a form in martial arts
Gayo (Indonesia) = Nice people

*/

}
