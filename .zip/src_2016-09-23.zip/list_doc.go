
f:\!!_Projects\go\src>go doc dlx/list         | D:\Apps\$Console\List.Com /S 
package list // import "dlx/list"

dance.go extends the (stolen and extended) list.go with stuff, which is
considered useful and helpfull, such as:

    - l.Dance( dance func() )
    - e.Dance( dance func() )

- on Cols:

    - l.fold()	l.unShow(col)			& unLink( Col-Head )
    - l.open()	l.reShow(col)			& reLink( Col-Head )

- on Rows - walking hori:

    - e.fold()	e's.away.list.fold(col)		except e.list.root (row head)
    - e.open()	e's.away.list.open(col)		except e.list.root (row head)

- on Cols - walking vert: (no need to skip root explicitly, as it's called
for l.root)

    - l.unShow()	l's.away.unList(row)
    - l.reShow()	l's.away.reList(row)
    - e.unShow()	e's.away.unList(row)
    - e.reShow()	e's.away.reList(row)

- on Rows - walking hori:

    - e.unList()	e's.away.unLink(col)		except e.list.root (row head)
    - e.reList()	e's.away.reLink(col)		except e.list.root (row head)

    - e.unLink()
    - e.reLink()

fmt.go extends the (stolen and extended) list.go with stuff, which is
considered useful and helpfull, such as:

    - e.PrintAways()

    - l.Print()
    - l.PrintValues()
    - e.PrintValue()

Package list implements a doubly linked list.

To iterate over a list (where l is a *List):

    for e := l.Front(); e != nil; e = e.Next() {
    	// do something with e.Value
    }

listaway.go extends the (stolen and extended) list.go with stuff, which is
considered useful and helpfull, such as:

    - e.Away()		*Element
    - e.Junk (x *Element)	// cross-links Away's

    - l.Away()		*Element
    - l.AddBeam
    - l.AddList
    - l.AddOnes

listmany.go extends the (stolen and extended) list.go with stuff, which is
considered useful and helpfull, such as:

    - e.Values()		[]interface {}

    - l.Elements()		[]*Element
    - l.Values()		[]interface {}

    - l.ValuesPushBack( v...)
    - l.ValuesPushFront( v...)

listmore.go extends the (stolen and extended) list.go with stuff, which is
considered useful and helpfull, such as:

    - e.List()		*List

    - NewList( v )	returns a list, the Root() of which carries v as Value

    - l.Root()		*Element

    - l.ValuesPushBack( v...)
    - l.ValuesPushFront( v...)

listmult.go extends the (stolen and extended) list.go with operations such
as addition and multiplication

search.go extends the (stolen and extended) list.go with stuff, which is
considered useful and helpfull, such as:

stack.go extends the (stolen and extended) list.go with stuff, which is
considered useful and helpfull, such as:

    - push ( e )
    - top()		*List
    - pop()		*List

var Levelcount = make(map[int]int)
var Verbose VerboseType
func PrintSolution()
type Element struct { ... }
type List struct { ... }
    func New() *List
    func NewList(v interface{}) *List
type VerboseType bool
