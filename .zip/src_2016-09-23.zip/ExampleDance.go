﻿// Copyright 2013 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main

// package list_test

import (
	"dlx/list"
)

//func ExampleDance() {
func main() {
	// Create a new list
	var chess = list.NewList( "Chess" )

	var rows = chess.AddBeam( "Zeilen", 1, 2, 3, 4, 5, 6, 7, 8 )
	var cols = chess.AddBeam( "Spalten", "A", "B", "C", "D", "E", "F", "G", "H" )
// So far, we have 2 * 8 Atom's - and that's all we need.
// All else is going to be built from these atoms

	chess.Print( "Starting" )
	chess.PrintAtomValues( "chess" )
	chess.PrintAways()

	chess.AddList( rows.Times( cols ) )
	chess.Print( "Growing" )
	chess.PrintAtomValues()
	chess.PrintAways()

// Note: now we use 'illegal' constructors, omitting the "chess.AddBeam( v, eVs... )"

	l := rows.Append()
	l.Print( "rows.Append()" )
//	l.PrintValues()
//	l.PrintAtomValues()

	l = rows.Append( cols )
	l.Print( "rows.Append( cols )" )
//	l.PrintValues()
//	l.PrintAtomValues()

	l = rows.Times()
	l.Print( "rows.Times()" )
//	l.PrintValues()
//	l.PrintAtomValues()

	l = rows.Times( cols )
	l.Print( "rows.Times( cols )" )
//	l.PrintValues()
//	l.PrintAtomValues()

	l = cols.Times( rows )
	l.Print( "rows.Times( cols )" )
//	l.PrintValues()
//	l.PrintAtomValues()

	l = chess.Xross( cols, rows )
	l.Print( ".Xross( cols, rows )" )
//	l.PrintValues()
	l.PrintAtomValues()
/*
*/
/*
	board := chess.Xross( rows, cols )
	board.Print( ".Xross( rows, cols )" )
//	board.PrintValues()
//	board.PrintAtomValues()
	board.PrintAways()
	board.Away().List().PrintAways()
	board.Away().List().PrintAtomValues( "l.Away().List()")
*/
/* Now, we have:
- the cols
- the rows
- the "Board" (=rows.Times( cols ) - at length
- the board (=.Xross( rows, cols )

We need to Tour the board.
the Elements carry their [x,y] coordinate-Elements.
And wait: these could/should be coordinate-Elements as well.
These we like to drop into some
a NewDots - frame (to become the sparse matrix for Search)
shall be initialzied from "Board", (or from serialized board.Elements())
But then, how to find the new Column given the 'original'?

We need to remember, what we already have!
Two maps[ original*Element ] new*Element might help, one for each axis
Thus: We need a typ Matrix struct. And this might be carried by the root.
or even: each root carries it's map of members?!
or better: each root carries it's memo of members?! Concurrency-Safe!
Then, for each cell (which becomes a row) we 'only' need to drop the tuple of the underlying atoms

This 'Root.Element' carries map can be applied to constructors such as AddBeam as well!!!
And AddList 'remembers'; AddOnes ???

Idea: Walk & Tour could report their "length"
Well, it's the len of the result, anyway?
No! Different GoTo have different length! Next=1, Away=0, Home=many
*/

/*
Kata - a form in martial arts
Gayo (Indonesia) = Nice people

*/

}
