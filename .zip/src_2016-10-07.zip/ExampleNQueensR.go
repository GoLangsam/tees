﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//package dance_test
package main

import (
	"dlx/anything/normal/stack"

	"dlx/dance/chooser"
	"dlx/dance/dance"
	"dlx/dance/dancer"
	"dlx/dance/dancing"

	"dlx/list/test"

//	dANCE "dlx/list/dancef"

	"fmt"
	"os"
	"sync"

	"testing"
	"time"
)

// ========================================================

var done = make(chan struct{})
var curr *dancer.Dancer
func PrepareCancelOnKeyPressed() {
	go func() {
		os.Stdin.Read(make([]byte, 1)) // read a single byte
		close(done)
	}()
}

func CancelOnKeyPressed(d *dancer.Dancer) {
	curr = d
	select {
		case <-done:	Abort(curr)
		default:	time.AfterFunc( 100 * time.Millisecond, func(){ CancelOnKeyPressed(curr) })
	}
}

func Abort (d *dancer.Dancer) {
	fmt.Println("Key pressed: Aborting..." )
	if d != nil {
		d.CallOnAsk = func(interface{}) bool {return false}	// do not accept any further partial solutions
//		d.CallBack = func() {return} 				// this leaves matrix inconsistent!
//		dance.D =						// we keep calling the spot.Dance in order to unwind
		d.Dancing.Choose = chooser.ChooseNil			// do not choose anything to dance on
	}
}

// ========================================================
var	Verbose		bool

var	C		chooser.Chooser = chooser.ChooseShort	// default

// ========================================================

func SetCallBackNQueens( d *dancer.Dancer, anz int ) *dancer.Dancer {
	var cols = test.NQueensR( anz )
	if Verbose {
//		cols.PrintAways()
		fmt.Printf("%s\t% 9d\t"+"\n", "Size: ", cols.Size() ) // this just gives cols * rows (ignoring secondary)
		fmt.Printf("%s\t% 9d\t"+"\n", "Trix: ", cols.AwayList().Size() ) // this gives ??? TODO: this is NOT correct!!!
	}
	d.CallBack = func(){ dance.Dance(cols, d) }
	d.CallBack = func(){ dance.DanceFast(cols, d) }
	return d
}

// ========================================================
func Prepare( anz int ) *dancer.Dancer {

	var howToDance = dancing.New()
	howToDance.SetVerbose(false, true, false, false )
	howToDance.SetRhythm(stack.New())
	howToDance.SetChoose(C)

	var d = dancer.New()
	d.SetDancing ( howToDance )
	d.CallOnAsk = func(interface{}) bool {return true}	// TODO: more ...
	return d
}

// ========================================================

func NQueensR( anz int ) {

	d := Prepare( anz )
	d = SetCallBackNQueens( d, anz )
	t := time.Now()
	CancelOnKeyPressed(d)
	var n sync.WaitGroup
	n.Add(1)
	go func() {defer n.Done(); d.CallBack()}()
	n.Wait()
	d.Dancing.Print()
	fmt.Println("Time =", time.Since(t) )
}

// ========================================================

func NQueensRTest(beg, end int) {
	for i := beg; i <= end; i++ {
		fmt.Println()
		fmt.Println( "Queens on a", i, "Board" )
		NQueensR( i )
	}
}

func NQueensRDanceTest(beg, end int) {
	for i := beg; i <= end; i++ {
		fmt.Println()
		fmt.Println( "Queens on a", i, "Board" )
		DanceTest( i )
	}
}

func NQueensRChooserTest(beg, end int) {
	for i := beg; i <= end; i++ {
		fmt.Println()
		fmt.Println( "Queens on a", i, "Board" )
		ChooserTest( i )
	}
}

func ChooserNQueensRTest(beg, end int) {
	for i, c := range chooser.GetChoosers() {
		C = c
		fmt.Println("Chooser No", i+1, "=", chooser.ChooserName(i) )
		NQueensRTest( beg, end )
	}
}

func ChooserTest(anz int) {
	for i, c := range chooser.GetChoosers() {
		C = c
		fmt.Println("Chooser No", i+1, "=", chooser.ChooserName(i) )
		NQueensR( anz )
	}
}


func DanceTest(anz int) {
	for i, d := range dance.GetDances() {
		dance.D = d
		fmt.Println("Dance No", i+1, "=", dance.DanceName(i) )
		NQueensR( anz )
	}
}


// ========================================================

// func ExampleTestChoosers(t *testing.T) {
func main() {
	PrepareCancelOnKeyPressed()

	beg := 8
	end := 13

//	NQueensRDanceTest(beg, end)
//	NQueensRChooserTest(beg, end)
//	ChooserNQueensRTest(beg, end)
	NQueensRTest(beg, end)
}

// ========================================================

func BenchmarkChooserTest(b *testing.B) {
	b.ReportAllocs()
	for i := 1; i < b.N; i++ {
		fmt.Println()
		fmt.Println( "Queens on a", i, "Board" )
//		NQueensR( i )
		ChooserTest( i )
	}
}

func BenchmarkTestNQueensR(b *testing.B) {
	b.ReportAllocs()
	for i := 1; i < b.N; i++ {
		fmt.Println()
		fmt.Println( "Queens on a", i, "Board" )
		NQueensR( i )
//		ChooserTest( i )
	}
}

// var br = Benchmark(f func(b *B)) BenchmarkResult

// ========================================================

/*
TODO: Where put? listtrix?
// Print prints the current stack (= the solution)
func Print(r Rhythm) {
	fmt.Print( "Solution: ")
	fmt.Println( r.Len() )
	var s = r.Get().([]*list.List)
	for _, l := range s {
		l.PrintValue()
		fmt.Print( ": " )
		for e := l.Front(); e != nil; e = e.Next() {
			e.Away().List().Root().PrintValue()
			fmt.Print( " " )
		}
		fmt.Println( "." )
	}
}
*/

