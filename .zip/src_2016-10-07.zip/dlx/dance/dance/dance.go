﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dance

import (
	"dlx/dance/dancer"

	"fmt"

	"dlx/yingyang/spot"
)

var	Level		int
var	Verbose		bool
var	VerboseLevel	bool

type dancefunc func(spot.Spot, *dancer.Dancer)

var	D dancefunc = func(dance spot.Spot, dancer *dancer.Dancer ){dance.DanceFast( dancer )}	// default

func GetDances() []dancefunc {
	var c = make([]dancefunc, 0, 5)
	c = append(c, func(dance spot.Spot, dancer *dancer.Dancer ){dance.Dance( dancer )}	)
	c = append(c, func(dance spot.Spot, dancer *dancer.Dancer ){dance.DanceSlow( dancer )}	)
	c = append(c, func(dance spot.Spot, dancer *dancer.Dancer ){dance.DanceFast( dancer )}	)
//		dANCE.Dance( dance, dancer )
	return c
}
// DanceName returns the name of the dance at index i of the result of GetDances
func DanceName(i int) string {
	switch {
		case i == 0:	return "list.Dance"
		case i == 1:	return "list.DanceSlow"
		case i == 2:	return "list.DanceFast"
		default:	return "<unknown>"
	}
}

// ========================================================

// Dance - standard dancer-callback (incl. Level)
func Dance(l spot.Spot, dancer *dancer.Dancer) {
	if dance :=  dancer.Dancing.Dance(l); dance != nil {	// Say Hello to Dancer, and if dancing ain't finished:
		if VerboseLevel {Level++ ; if Verbose {fmt.Println( "Level: ", Level)}		}
		D(dance, dancer)
		if VerboseLevel {Level--}
	}
}

// ========================================================

// DanceFast - standard dancer-callback, without Level, and with direct call of spot.DanceFast
func DanceFast(l spot.Spot, dancer *dancer.Dancer) {
	if dance :=  dancer.Dancing.Dance(l); dance != nil {	// Say Hello to Dancer, and if dancing ain't finished:
		dance.DanceFast( dancer )
	}
}

