﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package rhythm

import (
	"dlx/dance/rhythm/drummer"

	"dlx/yingyang/call"
	"dlx/yingyang/stack"
)

type Rhythm struct {
	stack.AnyDanceStack
	*drummer.Drummer
}

func New(stack stack.AnyDanceStack, INI_Depth int, verbosedrums bool, verbosebeats bool) Rhythm {

	var drums = drummer.New( INI_Depth, verbosebeats )

	if verbosedrums {
		drummer.Verbose = true
	} else {
		drummer.Verbose = false
	}

	return Rhythm{stack, drums}
}

func (r Rhythm)OnGoal() call.Callback     { return func()		{        r.Goal.Beat(r.Len())}	}
func (r Rhythm)OnDead() call.Callback     { return func()		{        r.Dead.Beat(r.Len())}	}
func (r Rhythm)OnCall() call.CallWithAny  { return func(interface{})	{        r.Call.Beat(r.Len())}	}
func (r Rhythm)OnLeaf() call.CallWithAny  { return func(interface{})	{        r.Leaf.Beat(r.Len())}	}
func (r Rhythm)OnPush() call.CallWithAny  { return func(l interface{})	{        r.Push(l)		}	}
func (r Rhythm)OnPop () call.CallForAny   { return func() interface{}	{ return r.Pop()		}	}

// Note: No drum for Push & Pop, as these occur in sync with Call