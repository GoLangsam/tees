﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go defines a dancer and a tryer
*/
package dancer

import (
	"dlx/dance/dancing"

	"dlx/yingyang/call"
	"dlx/yingyang/dancer"
)

type Dancer struct {

	CallBack   call.Callback

	CallOnPush call.CallWithAny
	CallOnAsk  call.CallWithAnyForBool
	CallOnPop  call.CallForAny
	CallOnLeaf call.CallWithAny

	Dancing    *dancing.Dancing
}

func New() *Dancer {			// cannot pass CallBack upon New, as it is a method of himself
	return new( Dancer ).Init()
}

func (d *Dancer) Init() *Dancer {

	d.CallBack   = call.NoOp

	d.CallOnPush = call.NoOpWithAny
	d.CallOnAsk  = call.NoOpWithAnyForBool
	d.CallOnPop  = call.NoOpForAny
	d.CallOnLeaf = call.NoOpWithAny

	return d
}

func (d *Dancer) SetDancing(dancing *dancing.Dancing) {

	d.Dancing = dancing
	d.setDrumming(d.Dancing.Rhythm)
}

func (d *Dancer) setDrumming(R dancer.DancerRhythm) *Dancer {

	d.CallOnPush = R.OnPush()
	d.CallOnPop  = R.OnPop()
	d.CallOnLeaf = R.OnLeaf()

	return d
}

// ========================================================

// Dance (for interface list.Dancer) is the callback
func (d *Dancer) Dance() {							d.CallBack()	}
// Ask (for interface list.Dancer) is a Push of the current stack
// and determination, if list is acceptable
func (d *Dancer) Ask( l interface{} ) bool {	d.CallOnPush(l);	return	d.CallOnAsk(l)	}	// Note: If e.g. resources are consumed, l may not qualify for a (temporary) solution
// Get (for interface list.Dancer) is a Pop of the current stack
func (d *Dancer) Get()  interface{} {					return	d.CallOnPop()	}
// OnLeaf (for extended interface list.Dancer & list.Tryer)
func (d *Dancer) OnLeaf( e interface{} ) {					d.CallOnLeaf(e)	}
