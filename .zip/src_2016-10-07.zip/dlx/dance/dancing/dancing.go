﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dancing

import (
	"dlx/dance/chooser"
	"dlx/dance/rhythm"

	"dlx/yingyang/spot"
	"dlx/yingyang/stack"
)

type Dancing struct {
	Choose		chooser.Chooser
	Rhythm		rhythm.Rhythm

	Verbose		bool
	VerboseDrums	bool
	VerboseBeats	bool

	PrintSolutions	bool
}

var INI_Depth = 100

func New() *Dancing {
	var d = new(Dancing)
	d.Choose = chooser.ChooseShort
	return d
}

// ========================================================

// Dance returns sth to dance on, or nil
func (d *Dancing) Dance(l spot.Spot) spot.Spot {
	if d.Verbose {
		l.PrintValue()
		l.PrintAways()
	}

	if l.Len() == 0 || l.Size() == 0 {
		if rhythm.Verbose {d.Rhythm.OnGoal()()} // Drummer.Grooves.Beat(Stacker.Len())
	//	if PrintSolutions { R.Print() }
		_ = d.Rhythm.Get()
		return nil
	}

	next, look := d.Choose(l)
	if !look {
		if rhythm.Verbose {d.Rhythm.OnDead()()}
//		if next != nil { panic("Confusing reply from Chooser: Shall NOT look into non-nil!?!")} // next could be 0-Len
		return nil
	} else {
		if rhythm.Verbose {d.Rhythm.OnCall()(next)}
		if next == nil { panic("Confusing reply from Chooser: Cannot look into nil!")} // next could be 0-Len
		return next
	}

}

// ========================================================
func (d *Dancing) SetVerbose(v, rh, dr, b bool) {

	d.Verbose	= v
	if rh {
		rhythm.Verbose	= true
	} else {
		rhythm.Verbose	= false
	}
	d.VerboseDrums	= dr
	d.VerboseBeats	= b
}

func (d *Dancing) SetRhythm(stack stack.AnyDanceStack) {
	d.Rhythm = rhythm.New(stack, INI_Depth, d.VerboseDrums, d.VerboseBeats )
}

func (d *Dancing) SetChoose(chooser chooser.Chooser) {
	d.Choose = chooser
}


func (d *Dancing) Print() {
	d.Rhythm.Print()
}