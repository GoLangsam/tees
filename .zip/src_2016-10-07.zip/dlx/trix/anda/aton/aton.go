﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
Aton (or Aten) <=> Sun-Disk / Sun-Globe

	- New(v, vals...)

*/
package aton

import (
	"dlx/list"
)

// AndaAton represents the good stuff
type AndaAton	struct{
	*list.List
}

// New returns an initialized aton.
func New(v interface{}, vals ...interface{}) *AndaAton {
	var atom = new(AndaAton)
	atom.List = list.NewList( v, vals... )
	return atom
}
