﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- dancer interface: Ask, Get, Dance, OnLeaf

*/
package list

type Dancer interface {
	Ask( interface{} ) bool
	Get() interface{}

	Dance()

	OnLeaf( interface{} )

//	...
}
