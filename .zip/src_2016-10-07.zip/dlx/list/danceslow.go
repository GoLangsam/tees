﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
danceslow.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- l.DanceSlow( d Dancer )
	- e.DanceSlow( d Dancer )

*/
package list

// ========================================================

// DanceSlow l is where the dancing begins
func (l *List)     DanceSlow( d Dancer ) {
	l.foldSlow(d)
	l.Root().DanceSlow( d )
	l.openSlow(d)
}

// DanceSlow e is where the dancing continues
func (e *Element)  DanceSlow( d Dancer ) {
	e.ForEachNext( func(i *Element){
		if d.Ask( i ) {			// Push
			i.Away().foldSlow(d)
			d.Dance()		// Dance d is where the dancing recurs to
			i.Away().openSlow(d)
		_ =d.Get().(*Element)		// Pop
		}
	} )
}

// ========================================================
func (l *List)      foldSlow( d Dancer ) { 					l.Root().Away().unLinkSlow(d);	l.unListSlow(d)		}
func (l *List)      openSlow( d Dancer ) { 					l.Root().Away().reLinkSlow(d);	l.reListSlow(d)		}

func (e *Element)   foldSlow( d Dancer ) { e.ForEachNext (func(i *Element) {	i.Away().List().foldSlow(d)	} ) }
func (e *Element)   openSlow( d Dancer ) { e.ForEachPrev (func(i *Element) {	i.Away().List().openSlow(d)	} ) }

func (l *List)    unListSlow( d Dancer ) { l.ForEachNext (func(i *Element) {	i.Away().unListSlow(d)		} ) }
func (l *List)    reListSlow( d Dancer ) { l.ForEachPrev (func(i *Element) {	i.Away().reListSlow(d)		} ) }

func (e *Element) unListSlow( d Dancer ) { e.ForEachNext (func(i *Element) {	i.Away().unLinkSlow(d)		} ) }
func (e *Element) reListSlow( d Dancer ) { e.ForEachPrev (func(i *Element) {	i.Away().reLinkSlow(d)		} ) }

func (e *Element) unLinkSlow( d Dancer ) { e.next.prev, e.prev.next = e.prev, e.next;	e.list.len--;	d.OnLeaf(e)	}
func (e *Element) reLinkSlow( d Dancer ) { e.next.prev, e.prev.next = e, e;		e.list.len++			}
