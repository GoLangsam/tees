﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go implements the callback-interfaces for list.Dancer & Tryer
(and further access to d.Stacker).
For performance reasons, calls on these functions is intentionally not monitored here.
See package dance
*/
package dancer

import (
	"dlx/list"
	"dlx/yingyang/call"
)

type Dance interface {
	Dancing
	Stacker
	Rhythm
	Scorer
}

type Dancing interface {
	Dancing(*list.List) (*list.List, bool)
}

type Stacker interface {
	ForDancer
	ForStack
}
type ForDancer interface {
	Ask( interface{} ) bool
	Get() interface{}

	Dance()
}
type ForStack interface {
	Top() interface{}
	Len() int
	Solution() []interface{}
}

type Scorer interface {
//	OnGoal([]*list.List)
}

type Rhythm interface {
	DancerRhythm
	OnCall() call.CallWithAny
	OnGoal() call.Callback
	OnDead() call.Callback
	OnAsk()  call.CallWithAnyForBool
}

type DancerRhythm interface {
	OnLeaf() call.CallWithAny
	OnPush() call.CallWithAny
	OnPop()  call.CallForAny
}
