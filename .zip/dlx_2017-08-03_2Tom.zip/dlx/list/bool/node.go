// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package bool

import (
	"dlx/list"
)

// Node describes informally
// what this package uses/needs
type Node interface {
	List() *list.List
	Root() *list.Element
	Away() *list.Element
	AwayList() *list.List
	Equals(e Node) bool
	IsRoot() bool
	IsNode() bool
	IsSolo() bool
}

var _ Node = new(list.Element)
