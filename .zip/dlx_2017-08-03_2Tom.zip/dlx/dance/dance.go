﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dance

import (
	"dlx/list"

	"dlx/list/normal/element/stack"

	"dlx/dance/chooser"
	"dlx/dance/dancing"
	"dlx/dance/drummer"
	"dlx/dance/spinner"	// to be supplied by client; carries problem list transparently. See also DefaultDance below
)

type Dance struct {
	Dancer		*dancing.Dancing

	Stacker		*stack.Stack
	Drummer		*drummer.Drums

	VerboseGoals	bool

}

// ========================================================

var INI_Depth = 100

func NewDance(v, vg, rh, vd, vb, vc bool) *Dance {
	var d = new(Dance)
	Verbose = VerboseType(v)
	d.VerboseGoals = vg
	chooser.Verbose = chooser.VerboseType ( vc )

	d.Dancer = dancing.New(vb, rh, false)	// TODO: ??? arg for turn.Verbose

	d.Stacker = stack.New(INI_Depth)
	d.Drummer = drummer.NewDrums( INI_Depth, vd )

	d = d.setBeating()
	d = d.setDancing()
	d = d.setTurning()

	return d
}

// ========================================================

func (d *Dance) setBeating() *Dance {
	d.Dancer.Beating.Dance	= func(l *list.List)	{	d.Drummer.Goal.Beat(d.Dancer.Level)	}
	d.Dancer.Beating.OnGoal	= func(e *list.Element)	{	d.Drummer.Call.Beat(d.Dancer.Level)	}
	d.Dancer.Beating.OnFail	= func()		{	d.Drummer.Fail.Beat(d.Dancer.Level)	}
	d.Dancer.Beating.OnLeaf	= func(e *list.Element)	{	d.Drummer.Leaf.Beat(d.Dancer.Level)	}
	return d
}

func (d *Dance) setDancing() *Dance {
	d.Dancer.Dancing.Dance	= func()		{	return }	// Client overrides: func(){ spinner.Dance(Dance.Dancing, cols) }
	d.Dancer.Dancing.OnGoal	= d.Stacker.Push
	d.Dancer.Dancing.OnFail	= d.Stacker.Pop
	d.Dancer.Dancing.OnLeaf	= d.Dancer.Beating.OnLeaf	// Note: defined in SetBeating above
	return d
}

func (d *Dance) setTurning() *Dance {
	d.Dancer.Turning.Dance	= func(l *list.List) 	{	l.Dance(d.Dancer.Dancing)}
	d.Dancer.Turning.OnGoal	= d.onGoal			// YES We have a solution
	d.Dancer.Turning.OnFail	= chooser.ChooseShort		// YES We have to go on dancing & goaling
	d.Dancer.Turning.OnLeaf	= d.onLeaf			// YES We have to abort
	return d
}

// ========================================================

func (d *Dance) onLeaf (l *list.List) bool {			// Do we have to abort?
	if Verbose {
		d.Stacker.Top().PrintValue("Stack-Top")
		l.PrintValue()
		l.PrintAways()
	}
	return false
}

func (d *Dance) onGoal (l *list.List) bool {			// Do we have a solution
	if l.IsEmpty() { // l.Len() == 0 // l.Size() == 0	// YES We have a solution
		if d.VerboseGoals {d.PrintGoal()}	// ... we may show it
		return true
	} else {
		return false
	}
}

// ========================================================

func (d *Dance) DefaultDance(dancing *dancing.Dancing, list *list.List) func() {
	return func() {spinner.Dance(dancing, list)}
}
