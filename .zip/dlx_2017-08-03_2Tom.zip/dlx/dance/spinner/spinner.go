// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
spinner.go provides some Dance- and Turn-functions which
keep a dancer busy dancing a dance on sth in search for goals, or turning back
*/

package spinner

import (
	"dlx/list"

	"dlx/dance/dancing"
	"dlx/dance/turn"
)

// ========================================================

// Spinner is the signature of a dance function
type Spinner func(d *dancing.Dancing, l *list.List)

// Turner is the signature of a turn function
type Turner func(d *turn.Dancing, l *list.List)
