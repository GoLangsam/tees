﻿// Copyright 2013 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//package trix
package main

import (
	"dlx/list"
	"dlx/trix/spot"
//	"fmt"
)




type Dots []*list.Element // not to be confused with list.ComposedValue

type Line *list.List
type Dust *list.Element


func test(s spot.Spot) {}


func main() {
	var l = list.NewList( "Test", 1, "2", "drei", false)
	test(l)
	var e = l.PushBack( l )
	test(e)

}