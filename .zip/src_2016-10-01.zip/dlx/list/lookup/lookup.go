﻿// Lookup provides a thread-safe mutex-guarded cache of *list.Element by some identifying string
package lookup

import (
	"dlx/list"

	"sync"
)

var (
	mu sync.Mutex // guards mapping
	mapping = make(map[string]*list.Element)
)

// Lookup an Element given an identifying string
func Lookup(key string) *list.Element {
	mu.Lock()
	v := mapping[key]
	mu.Unlock()
	return v
}
