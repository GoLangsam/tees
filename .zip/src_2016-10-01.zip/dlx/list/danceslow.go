﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
danceslow.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- l.DanceSlow( d slowDancer )
	- e.DanceSlow( d slowDancer )

*/
package list

type slowDancer interface {
	Dancer

//	...
}

// ========================================================

// DanceSlow l is where the dancing begins
func (l *List)     DanceSlow( d slowDancer ) {
	l.foldSlow(d)
	l.Root().DanceSlow( d )
	l.openSlow(d)
}

// DanceSlow e is where the dancing continues
func (e *Element)  DanceSlow( d slowDancer ) {
	e.ForEachNext( func(i *Element){
		d.Fold( i.Away().List() )	// Push
		i.Away().foldSlow(d)
		d.Dance()			// Dance d is where the dancing recurs to
		i.Away().openSlow(d)
		d.Open()			// Pop
	} )
}

// ========================================================
func (l *List)      foldSlow( d slowDancer ) { 						l.Root().Away().unLinkSlow(d);	l.unListSlow(d)		}
func (l *List)      openSlow( d slowDancer ) { 						l.Root().Away().reLinkSlow(d);	l.reListSlow(d)		}

func (e *Element)   foldSlow( d slowDancer ) { e.ForEachNext (func(i *Element) {	i.Away().List().foldSlow(d)} ) }
func (e *Element)   openSlow( d slowDancer ) { e.ForEachPrev (func(i *Element) {	i.Away().List().openSlow(d)} ) }

func (l *List)    unListSlow( d slowDancer ) { l.ForEachNext (func(i *Element) {	i.Away().unListSlow(d)} ) }
func (l *List)    reListSlow( d slowDancer ) { l.ForEachPrev (func(i *Element) {	i.Away().reListSlow(d)} ) }

func (e *Element) unListSlow( d slowDancer ) { e.ForEachNext (func(i *Element) {	i.Away().unLinkSlow(d)} ) }
func (e *Element) reListSlow( d slowDancer ) { e.ForEachPrev (func(i *Element) {	i.Away().reLinkSlow(d)} ) }

func (e *Element) unLinkSlow( d slowDancer ) { e.next.prev, e.prev.next = e.prev, e.next;	e.list.len--;	d.UpDate()	}
func (e *Element) reLinkSlow( d slowDancer ) { e.next.prev, e.prev.next = e, e;			e.list.len++;	d.UnDate()	}
