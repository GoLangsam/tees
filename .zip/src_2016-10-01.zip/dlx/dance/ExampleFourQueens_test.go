﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dance_test

import (
	"dlx/dance"
//	"dlx/dance/chooser"
	"dlx/dance/dancer"
	"dlx/dance/test"
)

func ExampleFourQueens() {

	var cols = test.FourQueens()

	d := dancer.New()
//	chooser.Verbose = true
//	dancer.Verbose = true
//	d.Chooser = chooser.ChooseShortNonEmpty
//	d.Chooser = chooser.ChooseShort
//	d.Chooser = chooser.ChooseFront

	d.CallBack = func(){ dance.Dance(cols, d) }
	d.CallBack()

	d.PrintCounters()

}
	// Output:
	// Solution: 4
	// R-01: R0 F1 A1 B4 .
	// R-13: R1 F3 A4 B5 .
	// R-20: R2 F0 A2 B1 .
	// R-32: R3 F2 A5 B2 .
	// Solution: 4
	// R-02: R0 F2 A2 B5 .
	// R-10: R1 F0 A1 B2 .
	// R-23: R2 F3 A5 B4 .
	// R-31: R3 F1 A4 B1 .

	// Levels:
	//       1       1
	//       2       4
	//       3       6
	//       4       4
	// Updates     237
	//       1      97
	//       2      82
	//       3      42
	//       4      16
	// Undates     237
	//       1      97
	//       2      82
	//       3      42
	//       4      16
