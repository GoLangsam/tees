﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go defines a dancer

*/
package dancer

import (
	"dlx/list"
	"dlx/dance/chooser"

	"fmt"
)

import "sort"

type callback func()
var noop callback = func(){return}

type counter map[int]int
func newCounter() counter {
	return make( counter, INI_Depth )
}

type Dancer struct {
	stack []*list.List

	CallBack callback
	Chooser	chooser.Chooser

	UpDates int
	UpDateCount counter	// UpDate counts unLink per Level
	UnDates int
	UnDateCount counter	// UnDate counts reLink per Level

	Level int
	LevelCount counter
}

var INI_Depth = 100

type dance func()

func New() *Dancer {			// cannot pass CallBack upon New, as it is a method of himself
	return new( Dancer ).Init()
}

func (d *Dancer) Init() *Dancer {
	d.stack = make([]*list.List, 0, INI_Depth)

	d.CallBack = noop
	d.Chooser = chooser.ChooseFront

	d.UpDates = 0
	d.UpDateCount = newCounter()
	d.UnDates = 0
	d.UnDateCount = newCounter()
	d.Level = 0
	d.LevelCount = newCounter()

	return d
}

// ========================================================

// UpDate (for extended interface list.Dancer)
func (d *Dancer) UpDate() {
	d.UpDates++
	d.UpDateCount[d.Level]++
}
// UnDate (for extended interface list.Dancer)
func (d *Dancer) UnDate() {
	d.UnDates++
	d.UnDateCount[d.Level]++
}

// NewLevel (for extended interface list.Dancer)
func (d *Dancer) NewLevel() {
	d.LevelCount[d.Level]++
}

// Fold (for interface list.Dancer) is a Push of the current stack
func (d *Dancer) Fold( l *list.List ){
	d.stack = append(d.stack, l)
}
// Open (for interface list.Dancer) is a Pop of the current stack
func (d *Dancer) Open() *list.List {
	p := d.stack[len(d.stack)-1]
	d.stack = d.stack[:len(d.stack)-1]
	return p
}

// Dance (for interface list.Dancer) is a callback
func (d *Dancer) Dance() {
	d.CallBack()
}

// Solution returns a copy of the current stack
func (d *Dancer) Solution() []*list.List {
	var s = make([]*list.List, len(d.stack) )
	copy (s, d.stack)
	return s
}

// Len returns the length of the current stack
func (d *Dancer) Len() int {
	return len(d.stack)
}
// Top returns the top of the current stack
func (d *Dancer) Top() *list.List {
	return d.stack[len(d.stack)-1]
}
// ========================================================


func (d *Dancer) Dancing(l *list.List) (*list.List, bool) {
	if Verbose {
		l.PrintValue()
		l.PrintAways()
		d.Print()
		fmt.Println( "Level: ", d.Level)
	}

	if l.Len() == 0 {
		d.Print()
		return nil, false
	} else {
		return d.Chooser(l)
	}
}

// ========================================================

// Print prints the current stack (= the solution)
func (d *Dancer) Print() {
	fmt.Print( "Solution: ")
	fmt.Println( d.Len() )
	for _, l := range d.stack {
		l.PrintValue()
		fmt.Print( ": " )
		for e := l.Front(); e != nil; e = e.Next() {
			e.Away().List().Root().PrintValue()
			fmt.Print( " " )
		}
		fmt.Println( "." )
	}
}

func (d *Dancer) PrintCounters() {
	fmt.Println("Levels:")
	d.LevelCount.Print()

	fmt.Printf("%s\t%7d\n", "Updates", d.UpDates)
	d.UpDateCount.Print()

	fmt.Printf("%s\t%7d\n", "Undates", d.UnDates)
	d.UnDateCount.Print()
}

func (c counter) Print() {
	printCounter(c)
}

func printCounter(counter map[int]int) {
// import "sort"
	var names sort.IntSlice
	for name := range counter {
		names = append(names, name )
	}
	names.Sort()
	for _, name := range names {
		fmt.Printf("%7d\t%7d\t\n", name, counter[name])
	}
}