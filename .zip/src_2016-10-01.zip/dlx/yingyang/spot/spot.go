﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package spot

import (
	"dlx/list"
)

// Spot abstracts the common behaviour of *list.Element & *list.List
type Spot interface {
// New() *List
// NewList(v interface{}, vals ...interface{}) *List
// (l *List) AddBeam(v interface{}, vals ...interface{}) *List			=> trix
// (l *List) AddJunk(v interface{}, lists ...*List) *List			=> trix
// (l *List) AddList(list *List) *List						=> trix
// (l *List) AddOnes(v interface{}, lists ...*List) *List			=> trix
// (l *List) AddRays(lists ...*List) *List					=> trix
// (l *List) NewCalc() *List							=> trix

	Away() *list.Element
	AwayNext() *list.Element
	AwayPrev() *list.Element
	Back() *list.Element
	CVs() *list.ComposedValue
// (l *List) Clear() *List							=> trix ?

	Dance(d list.Dancer)
// 	fold()
// 	open()

//	DanceFast(d list.fastDancer)
// fast	foldFast(d list.fastDancer)
// fast	openFast(d list.fastDancer)
// fast	unListFast(d list.fastDancer)
// fast	reListFast(d list.fastDancer)

//	DanceSlow(d list.slowDancer)
// slow	foldSlow(d list.slowDancer)
// slow	openSlow(d list.slowDancer)
// slow	unListSlow(d list.slowDancer)
// slow	reListSlow(d list.slowDancer)

	ForEachNext( f func(*list.Element) )
	ForEachPrev( f func(*list.Element) )

	Elements() []*list.Element		// => list.Dots

//	Equals(i Spot) bool			// pair!

	Front() *list.Element
	Home() *list.Element
// (l *List) Init() *List
// (l *List) InsertAfter(v interface{}, mark *Element) *Element
// (l *List) InsertBefore(v interface{}, mark *Element) *Element

	IsAtom() bool
	IsComposed() bool
// (l *List) IsEmpty() bool		// TODO? ???

	IsJunk() bool
// (e *Element) IsNode() bool		// TODO? l.IsNode == false
// (e *Element) IsRoot() bool		// TODO? l.IsRoot == true

	IsSolo() bool
// (e *Element) Junk(x *Element)	// TODO? Junk Roots - no way, compile errors
//	Junks(i Spot) bool			// pair!

	Len() int
// (l *List) MoveAfter(e, mark *Element)
// (l *List) MoveBefore(e, mark *Element)
// (l *List) MoveToBack(e *Element)
// (l *List) MoveToFront(e *Element)

// (e *Element) Next() *Element		// TODO?
// (e *Element) Prev() *Element		// TODO?

// (l *List) Print(args ...interface{})	// TODO!
	PrintAtomValues(args ...interface{})
	PrintAways(args ...interface{})
	PrintValue(args ...interface{})

// (l *List) PushBack(v interface{}) *Element		==> Beam
// (l *List) PushBackList(other *List)
// (l *List) PushFront(v interface{}) *Elemen		==> Beamt
// (l *List) PushFrontList(other *List)

// (l *List) Remove(e *Element) interface{}

	Root() *list.Element
	Values() list.Values

// (l *List) ValuesPushBack(values ...interface{})	==> Beam
// (l *List) ValuesPushFront(values ...interface{})	==> Beam

//	With( Spot ) *list.ComposedValue	// pair!
}
