// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// RCPSP - Resource-Constrained Project Scheduling Problem
package main

import (
	//	"dlx/rcpsp"
	"dlx/rcpsp/sample"

	"flag"
	"fmt"
)

var (
	foodAvail = flag.Bool("FoodAvail", false, "FoodAvail")
	todoTakes = flag.Bool("TodoTakes", false, "TodoTakes")
	todoNeeds = flag.Bool("TodoNeeds", false, "TodoNeeds")
	todoTodos = flag.Bool("TodoTodos", false, "TodoTodos")

	foodTotal = flag.Bool("FoodTotal", false, "FoodTotal")
	timeTotal = flag.Bool("TimeTotal", false, "TimeTotal")

	todoPreds = flag.Bool("TodoPreds", false, "TodoPreds")
	predPreds = flag.Bool("PredPreds", false, "PredPreds")

	timesTodo = flag.Bool("TimesTodo", false, "TimesTodo")
	availFood = flag.Bool("AvailFood", false, "AvailFood")
)

func flagParse() {
	flag.Parse()
}

func main() {
	flagParse()

	var p = sample.GetSample()
	var r = p.Enrich()

	if *todoTakes {
		r.TodoTakes.Print()
	}
	if *todoNeeds {
		r.TodoNeeds.Print()
	}
	if *todoTodos {
		r.TodoTodos.Print()
	}
	if *foodAvail {
		r.FoodAvail.Print()
	}

	if *foodTotal {
		fmt.Printf("%s:\t%d\n", "Sum ", r.FoodTotal)
	}

	if *timeTotal {
		fmt.Printf("%s:\t%d\n", "Sum ", r.TimeTotal)
	}

	if *todoPreds {
		for todoID, pred := range r.TodoPreds {
			fmt.Printf("%s:\t%s\n", todoID, pred)
		}
	}

	if *predPreds {
		for todoID, pred := range r.PredPreds {
			fmt.Printf("%s:\t", todoID)
			for p := range pred {
				fmt.Printf("%s\t", p)
			}
			fmt.Printf("\n")
		}
	}

	//	for i, todoID := range rcpsp.TopoSort(p.TodoTodos) {
	//		fmt.Printf("%d:\t%s\n", i+1, todoID)
	//	}

	//	for i, todoID := range rcpsp.TopoSort(r.TodoPreds) {
	//		fmt.Printf("%d:\t%s\n", i+1, todoID)
	//	}

	if *timesTodo {
		r.TimesTodo.Print()
	}
	if *availFood {
		r.AvailFood.Print()
	}

}
