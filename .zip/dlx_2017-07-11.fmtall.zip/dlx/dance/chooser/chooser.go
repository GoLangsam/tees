// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
choose.go defines the signature of a choosing function

*/
package chooser

import (
	"dlx/list"
)

// ========================================================

// Chooser is the signature of a choosing function
type Chooser func(*list.List) (*list.List, bool)
