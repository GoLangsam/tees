// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package trixmove

//	"dlx/list"
//	"dlx/trix/walk"

// Move abstracts common behaviour of walk.kata and walk.akas
type Move interface {

	//	Walker(*list.Element)	walk.Walk

}
