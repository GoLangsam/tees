// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stack_test

import (
	stackccsafe "dlx/anything/ccsafe/stack"
	stacknormal "dlx/anything/normal/stack"
)

func ExampleAnyStack() {
	var ns = stacknormal.New(7)
	testIsAnyStack(ns)
	testAnyStack(ns)
	testCanDrop(ns)
	testHasLen(ns)

	var cs = stackccsafe.New(7)
	testIsAnyStack(cs)
	testAnyStack(cs)
	testCanDrop(cs)
	testHasLen(cs)
}
