// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// package main
package test

import (
	"fmt"
)

func width(anz int64) int {
	// too lazy to use log ;-)
	if anz > 99999999999 {
		return 12
	}
	if anz > 9999999999 {
		return 11
	}
	if anz > 999999999 {
		return 10
	}
	if anz > 99999999 {
		return 9
	}
	if anz > 9999999 {
		return 8
	}
	if anz > 999999 {
		return 7
	}
	if anz > 99999 {
		return 6
	}
	if anz > 9999 {
		return 5
	}
	if anz > 999 {
		return 4
	}
	if anz > 99 {
		return 3
	}
	if anz > 9 {
		return 2
	}
	return 1
}

func GetFormatWidthPaddingZeros(anz int64) string {
	return "%0" + fmt.Sprintf("%d", width(anz)) + "d"
}

func GetFormatWidthPaddingSpaces(anz int64) string {
	return "% " + fmt.Sprintf("%d", width(anz)) + "d"
}

func IDs(prefix string, anz int) []string {

	var s = make([]string, 0, anz)
	var f = "%s" + GetFormatWidthPaddingZeros(int64(anz))

	for i := 0; i < anz; i++ {
		id := fmt.Sprintf(f, prefix, i+1)
		s = append(s, id)
	}

	return s
}
