﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dancing

import (
	"dlx/dance/dancing/chooser"
	"dlx/dance/dancing/drummer"	// Note: No drum for Push & Pop, as these occur in sync with Call

	"dlx/list"
	"dlx/list/normal/element/stack"

	"fmt"
)

type Dancing struct {
	Chooser		chooser.Chooser
	Drummer		*drummer.Drums
	Stacker		*stack.Stack
	Dancing		*list.Dancing

	Level		int

	Verbose		bool
	VerboseDrums	bool
	VerboseBeats	bool
	VerboseGoals	bool
}

var INI_Depth = 100

func New(v, vg, rh, vd, vb, vc bool) *Dancing {
	var d = new(Dancing)
	d = d.SetVerbose(v, vg, rh, vd, vb, vc)
	d = d.Init()
	return d
}

func (d *Dancing) Init() *Dancing {
	d.Chooser = chooser.ChooseShort		// Set d.Dancing.Choose = chooser.ChooseNil to abort gracefully
	d.Drummer = drummer.New( INI_Depth, d.VerboseBeats )
	d.Stacker = stack.New()

	d.Dancing = list.NewDancing()
	d.Dancing.Dance		= func(){ return }	// Client overrides
	d.Dancing.Push		= d.Stacker.Push
	d.Dancing.Pop		= d.Stacker.Pop
	d.Dancing.OnLeaf	= d.OnLeaf

	return d
}

func (d *Dancing) SetVerbose(v, vg, rh, vd, vb, vc bool) *Dancing {

	d.Verbose	= v
	d.VerboseGoals	= vg
	if rh {	drummer.Verbose	= true
	} else {drummer.Verbose	= false }
	d.VerboseDrums	= vd
	d.VerboseBeats	= vb
	if vc {	chooser.Verbose	= true
	} else {chooser.Verbose	= false }

	return d
}

// ========================================================

// Find returns sth to dance on, or nil
func (d *Dancing) Find(l *list.List) *list.List {
	if d.Verbose {
		l.PrintValue()
		l.PrintAways()
	}

//	if e := d.Stacker.Top() ... we may inspect last pushed element!

	if l.Len() == 0 { // || l.Size() == 0 {
		if drummer.Verbose {d.OnGoal()}
		if d.VerboseGoals { d.PrintGoal() }
//		_ = d.Stacker.Get()
		return nil
	}

	next, look := d.Chooser(l)
	if !look {
		if drummer.Verbose {d.OnDead()}
//		if next != nil { panic("Confusing reply from Chooser: Shall NOT look into non-nil!?!")} // next could be 0-Len
		return nil
	} else {
		if drummer.Verbose {d.OnCall(next)}
		if next == nil { panic("Confusing reply from Chooser: Cannot look into nil!")}
		return next
	}
}

// ========================================================

// Dance - standard dancer-callback (incl. Level)
func (d *Dancing) Dance(l *list.List) {
	if dance :=  d.Find(l); dance != nil {	// Say Hello to Dancer, and if dancing ain't finished:
		d.Level++
		dance.Dance(d.Dancing)
		d.Level--
	}
}
func (d *Dancing) DanceFast(l *list.List) {
	if dance :=  d.Find(l); dance != nil {	// Say Hello to Dancer, and if dancing ain't finished:
		d.Level++
		dance.DanceFast(d.Dancing)
		d.Level--
	}
}
func (d *Dancing) DanceSlow(l *list.List) {
	if dance :=  d.Find(l); dance != nil {	// Say Hello to Dancer, and if dancing ain't finished:
		d.Level++
		dance.DanceSlow(d.Dancing)
		d.Level--
	}
}

// ========================================================

func (d *Dancing)OnGoal()			{	if d.VerboseDrums {	d.Drummer.Goal.Beat(d.Level)	}	}
func (d *Dancing)OnDead()			{	if d.VerboseDrums {	d.Drummer.Dead.Beat(d.Level)	}	}
func (d *Dancing)OnCall(l *list.List)		{	if d.VerboseDrums {	d.Drummer.Call.Beat(d.Level)	}	}
func (d *Dancing)OnLeaf(e *list.Element)	{	if d.VerboseDrums {	d.Drummer.Leaf.Beat(d.Level)	}	}

// ========================================================

func (d *Dancing) Print() {
	d.Drummer.Print()
}

// ========================================================

// Print prints the current stack (= the solution)
func (d *Dancing) PrintGoal() {
	fmt.Print( "Solution: ")
	fmt.Println( d.Stacker.Len() )
	for _, l := range d.Stacker.Get() {
		l.List().PrintValue()
		fmt.Print( ": " )
		for e :=l.AwayList().Front(); e != nil; e = e.Next() {
			e.AwayList().PrintValue()
			fmt.Print( " " )
		}
		fmt.Println( "." )
	}
}
