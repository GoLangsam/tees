﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package math

import (
	"dlx/list"
)

// Times returns a new list: the cross product of l with some lists...
// ( recursively as [[[ l * l ] * l ] ... ] )
// Note: Times( l, nil ) returns a new empty list
// the root of which carries the CVs of the original l.Root()
// and the elements carry the CVs of the original elements
func Times (l *list.List, lists ...*list.List ) *list.List {
	if len(lists) == 0 {	return times(l, nil )  }
	if len(lists) == 1 {	return times(l, lists[0] ) }
				return times(l, Times( lists[0] , lists[1:]... ) )
}

// ===========================================================================

// times returns a new list with len(X) * len(Y) Elements
// representing the cross-product of the list X * Y
// Note: l.times( nil ) returns a new list with no elements
func times ( X, Y *list.List ) *list.List {
	if X == nil{ return list.NewList( nil ) }
	newl := X.NewCalc()
	if Y != nil {
		for x := X.Front(); x != nil; x = x.Next() {
			for y := Y.Front(); y != nil; y = y.Next() {
				newl.PushBack( x.With(y) )
			}
		}
		newl.Root().Value = X.With(Y)
	}
	return newl
}
