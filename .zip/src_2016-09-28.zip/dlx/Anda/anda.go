﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
Anda - Sanskrit: Cosmic Egg

	- NewAnda

	- l.AddBeam
	- l.AddRays
	- l.AddList
	- l.AddJunk
	- l.AddOnes

	- l.NewCalc

*/
package anda

import (
	"dlx/list"
)

// Aten/Aton (Sun-Disk/Sun-Globe) <=> Apep (darkness&chaos) => Duat (Underworld) / Luna (moon)

type Anda	struct{*list.List}		// ListOfListsOfLists...
type AndaAton	struct{*list.List}		// The good stuff
type AndaApep	struct{*list.List}		// The dark stuff
type Duat	struct{*list.List}		// The trix stuff

/*
type Anda list.List	// ListOfListsOfLists...
type AndaAton list.List	// The good stuff
type AndaApep list.List	// The dark stuff
type Duat list.List	// The trix stuff
*/

/*
Maat

*/

// ===========================================================================
func NewAnda(v interface{}, vals ...interface{}) *AndaAton {
	var aton = new(AndaAton)
	aton.List = list.NewList( v, vals... )
	var apep = new(AndaApep)
	apep.List = list.NewList( aton.CVs() )	// TODO: bessere Lösung
	aton.Root().Junk( apep.Root() )
	return aton
}


func (l *Anda)NewCalc() *AndaApep {
	var apep = new(AndaApep)
	apep.List = list.NewList( l.CVs() )
	return apep
}

/* TODO:
AddBeam => AddAton
AddRays => AddApep
*/

// ===========================================================================
// AddAton returns a new list with root-value v and new elements with values dots,
// the root of which is Junk'ed to a new PushBack-Element (with same value v) of l
func (l *AndaAton) AddAton ( v interface{}, vals ...interface{} ) *AndaAton {
	var aton = new(AndaAton)
	aton.List = list.NewList( v, vals... )
	var head = l.PushBack( l.List.With(aton.List) )
	aton.Root().Junk( head )
	return aton
}

// AddApep Add's lists to l
// and returns l
func (l *AndaAton) AddApep ( lists ...AndaApep ) *AndaAton {
	for _, apep := range lists {
		l.AddList( list )
		var head = l.Apep().PushBack( l.With(apep) )
		apep.root.Junk( head )
	}
	return l
}

// AddList adds a new element with value v to list l
// Junk'es it with the list's root
// and returns list (not l) - useful for calculated lists
func (l *AndaAton) AddList ( list *AndaApep ) *AndaApep {
	var head = l.PushBack( l.With(list) )
	list.root.Junk( head )	//	:SameAs head.Junk( list.Root() )

	return list
}

func (l *Anda) addList ( list *Anda ) *Anda {
	var head = l.PushBack( l.With(list) )
	list.root.Junk( head )	//	:SameAs head.Junk( list.Root() )
	return list
}


// ===========================================================================
// AddJunk adds Junk'ed pairs of new elements to list l across respective lists
// The new elements carry pointers to both Roots() as Values.
// Thus, they carry their coordinates, so to say.
func (l AndaApep) AddJunk ( v interface{}, lists ...AndaApep) AndaApep {

	var list = NewList( v )

	for _, head := range lists {
		vert := head.PushBack( head.With(list) )
		hori := list.PushBack( list.With(head) )
		vert.Junk( hori )
	}
	return l.addList( list )
}

// AddOnes adds Junk'ed pairs of new elements to list l across respective lists
// The new elements carry no Values. They are light, so to say.
func (l AndaApep) AddOnes ( v interface{}, lists ...AndaApep) AndaApep {

	var list = NewList( v )

	for _, head := range lists {
		vert := head.PushBack( nil )
		hori := list.PushBack( nil )
		vert.Junk( hori )
	}
	return l.addList( list )
}
