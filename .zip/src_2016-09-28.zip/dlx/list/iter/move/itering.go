﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package move

import (
	"dlx/list"
	"dlx/list/iter"
)

// For Your convenience: Some predefined Moves:

// for the basic GoTo's
	var Next iter.GoTo = (*list.Element).Next
	var Prev iter.GoTo = (*list.Element).Prev
	var Away iter.GoTo = (*list.Element).Away
	var Root iter.GoTo = (*list.Element).Root
	var Front iter.GoTo = (*list.Element).Front
	var Back iter.GoTo = (*list.Element).Back
	var Home iter.GoTo = (*list.Element).Home

// the basic GoTo's
	var GotoNext		= iter.NewKata( "Goto Next" , Next )
	var GotoPrev		= iter.NewKata( "Goto Prev" , Prev )
	var GotoAway		= iter.NewKata( "Goto Away" , Away )
	var GotoRoot		= iter.NewKata( "Goto Root" , Root )
	var GotoFront		= iter.NewKata( "Goto Front", Front )
	var GotoBack		= iter.NewKata( "Goto Back" , Back )
	var GotoHome		= iter.NewKata( "Goto Home" , Home )

// for composed movement
// Orthogonal
// Hint: Think of a right-hand matrix (or chessboard), look at a horizontal element
// Note: A Spreadsheet or Matrix is usually left(!)-handed, Rows go down!!!
	var MoveAwayPrev	= iter.NewKata( "AwayPrev", Away, Prev, Away )	//	= Up
	var MoveAwayNext	= iter.NewKata( "AwayNext", Away, Next, Away )	//	= Down
	var MoveUp		= iter.NewKata( "Up",       Away, Prev, Away )	//	= MoveAwayPrev
	var MoveDown		= iter.NewKata( "Down",     Away, Next, Away )	//	= MoveAwayNext

// next/prev orthogonal fiber
	var TrixNextFront	= iter.NewKata( "NextFront", Root, Away, Next, Away, Front )
	var TrixNextBack	= iter.NewKata( "NextBack",  Root, Away, Next, Away, Back )
	var TrixPrevFront	= iter.NewKata( "PrevFront", Root, Away, Prev, Away, Front )
	var TrixPrevBack	= iter.NewKata( "PrevBack" , Root, Away, Prev, Away, Back )

// Diagonal
	var JumpDiagonalNU      = iter.NewKata( "DiagNU"   , Next, Away, Prev, Away )//	= Next, AwayPrev
	var JumpDiagonalND      = iter.NewKata( "DiagND"   , Next, Away, Next, Away )//	= Next, AwayNext
	var JumpDiagonalPU      = iter.NewKata( "DiagPU"   , Prev, Away, Prev, Away )//	= Prev, AwayPrev
	var JumpDiagonalPD      = iter.NewKata( "DiagPD"   , Prev, Away, Next, Away )//	= Prev, AwayPrev
