﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
danceslow.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- l.DanceSlow( d slowDancer )
	- e.DanceSlow( d slowDancer )

*/
package list

type slowDancer interface {
	Dancer
//	...
}

// ========================================================

// DanceSlow l is where the dancing begins
func (l *List)     DanceSlow( d slowDancer ) {
	l.FoldSlow(d)
	l.Root().DanceSlow( d )
	l.OpenSlow(d)
}

// DanceSlow e is where the dancing continues
func (e *Element)  DanceSlow( d slowDancer ) {
	e.ForEachNext( func(i *Element){
		d.Fold( i.Away().List() )	// Push
		i.Away().FoldSlow(d)
		d.Dance()			// Dance d is where the dancing recurs to
		i.Away().OpenSlow(d)
		d.Open()			// Pop
	} )
}

// ========================================================
func (l *List)      FoldSlow( d slowDancer ) { 						l.Root().Away().unLinkSlow(d);	l.UnListSlow(d)		}
func (l *List)      OpenSlow( d slowDancer ) { 						l.Root().Away().reLinkSlow(d);	l.ReListSlow(d)		}

func (e *Element)   FoldSlow( d slowDancer ) { e.ForEachNext (func(i *Element) {	i.Away().List().FoldSlow(d)} ) }
func (e *Element)   OpenSlow( d slowDancer ) { e.ForEachPrev (func(i *Element) {	i.Away().List().OpenSlow(d)} ) }

func (l *List)    UnListSlow( d slowDancer ) { l.ForEachNext (func(i *Element) {	i.Away().UnListSlow(d)} ) }
func (l *List)    ReListSlow( d slowDancer ) { l.ForEachPrev (func(i *Element) {	i.Away().ReListSlow(d)} ) }

func (e *Element) UnListSlow( d slowDancer ) { e.ForEachNext (func(i *Element) {	i.Away().unLinkSlow(d)} ) }
func (e *Element) ReListSlow( d slowDancer ) { e.ForEachPrev (func(i *Element) {	i.Away().reLinkSlow(d)} ) }

func (e *Element) unLinkSlow( d slowDancer ) { e.next.prev, e.prev.next = e.prev, e.next;	e.list.len--		    }
func (e *Element) reLinkSlow( d slowDancer ) { e.next.prev, e.prev.next = e, e;			e.list.len++		    }
