﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package looker

import (
	"dlx/list"
	"dlx/dance/turn"
)

type ElementSet map[*.list.Element]bool

func NewElementSet( cap int) ElementSet {
	return make(map[*.list.Element]bool,cap)
}

type LookAway struct {
	AwaySolos	ElementSet	//Away().IsSolo()
	AwayRoots	ElementSet	//Away().IsRoot()
	AwayNodes	ElementSet	//Away().IsNode()
}


type Looking struct {
	Level		int
}

func New() *Looking {
	var l = new(Looking)

	d.Level = 0


	return l
}

func NewLookAway( cap int ) *LookAway {
	var r = new(LookAway)
	r.AwaySolos = NewElementSet( cap )
	r.AwayRoots = NewElementSet( cap )
	r.AwayNodes = NewElementSet( cap )
	return r
}

func LookListAway (l *list.List) *LookAway {
	var r = NewLookAway( l.Len() )
	for e:=l.Front(); e!=nil; e=e.Next() {
		switch e {
		case e.IsSolo():	AwaySolos[e] = true
		case e.IsRoot():	AwayRoots[e] = true
		case e.IsNode():	AwayNodes[e] = true
		default:		panic("LookListAway: Unexpected kind of element")
		}
	}
	return r
}

/*
For each List (=eventual Col/Row):

- Lists of AwayNodes	=> AwayLists
- Lists of AwayRoots	=> TreeNodes
*/
