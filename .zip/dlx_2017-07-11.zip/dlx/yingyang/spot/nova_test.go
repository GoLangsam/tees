﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package spot_test

import (
	"dlx/list"

	"dlx/trix/anda"
	"dlx/trix/anda/aton"
	"dlx/trix/anda/apep"

	"dlx/trix/walk/kata"
	"dlx/trix/walk/akas"
	"dlx/trix/walk/move"

	"dlx/yingyang/spot"
)

func testNova(n spot.Nova) {}

func ExampleNova() {
	var list = list.NewList( "Test", 1, "2", "drei", false)
	testNova(list)

	var anda = anda.New( "Test", 1, "2", "drei", false)
	testNova(anda)
	var aton = aton.New( "Test", 1, "2", "drei", false)
	testNova(aton)
	var apep = apep.New( "Test", 1, "2", "drei", false)
	testNova(apep)

	var kata = kata.New( "Prev", move.Prev )
	testNova(kata)
	var move = move.MoveUp
	testNova(move)
	var akas = akas.New( "PrevUp", kata, move )
	testNova(akas)
}