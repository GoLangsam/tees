﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stack_test

import (
	stacknormal		"dlx/list/normal/element/stack"
	stackccsafe		"dlx/list/ccsafe/element/stack"
)

func ExampleElemStack() {
	var ns = stacknormal.New(7)
	testIsElemStack(ns)
	testElemStack(ns)
	testCanPrint(ns)
	testCanDrop(ns)
	testHasLen(ns)

	var cs = stackccsafe.New(7)
	testIsElemStack(cs)
	testElemStack(cs)
	testCanPrint(cs)
	testCanDrop(cs)
	testHasLen(cs)
}