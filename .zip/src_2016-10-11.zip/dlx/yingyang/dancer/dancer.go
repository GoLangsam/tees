﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go implements the callback-interfaces for list.Dancer & Tryer
(and further access to d.Stacker).
For performance reasons, calls on these functions is intentionally not monitored here.
See package dance
*/
package dancer

import (
	"dlx/list"
	"dlx/yingyang/call"
)

type Dance interface {
	Dancing
	Stacker
	Rhythm
	Scorer
}

type Dancing interface {
	Dancing(*list.List) (*list.List, bool)
}

type Stacker interface {
	list.Dancer
	ForStack
}
type ForDancer interface {
	Push( *list.Element )
	Pop() *list.Element

	Dance()
}
type ForStack interface {
	Top()    call.CallForElem
	Len()    int
	Solution() []interface{}
}

type Scorer interface {
//	OnGoal([]*list.List)
}

type Rhythm interface {
	DancerRhythm
	OnCall() call.CallWithList
	OnGoal() call.Callback
	OnDead() call.Callback
}

type DancerRhythm interface {
	OnLeaf() call.CallWithElem
	OnPush() call.CallWithElem
	OnPop()  call.CallForElem
}
