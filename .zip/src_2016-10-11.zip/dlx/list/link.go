﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
link.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- l.UnLeaf( d *Dancing )
	- l.ReLeaf( d *Dancing )

	- e.UnLeaf( d *Dancing )
	- e.ReLeaf( d *Dancing )

	- l.UnLink()
	- l.ReLink()

	- e.UnLink()
	- e.ReLink()

Note: For good performance, the functions are implemented directly
*/

package list

// ========================================================

func (l *List) UnLeaf( d *Dancing )	{
	for e := l.root.next; e != &l.root; e = e.next {
		e.next.prev = e.prev
		e.prev.next = e.next
		e.list.len--
		d.OnLeaf(e)
	}
}
func (l *List) ReLeaf( d *Dancing ) {
	for e := l.root.prev; e != &l.root; e = e.prev {
		e.next.prev = e
		e.prev.next = e
		e.list.len++
	}
}

func (e *Element) UnLeaf( d *Dancing ) {          e.next.prev, e.prev.next = e.prev, e.next;		e.list.len--;	d.OnLeaf(e)	}
func (e *Element) ReLeaf( d *Dancing ) {          e.next.prev, e.prev.next = e, e;			e.list.len++			}

// ========================================================

func (l *List) UnLink()	{
	for e := l.root.next; e != &l.root; e = e.next {
		e.next.prev = e.prev
		e.prev.next = e.next
		e.list.len--
	}
}
func (l *List) ReLink() {
	for e := l.root.prev; e != &l.root; e = e.prev {
		e.next.prev = e
		e.prev.next = e
		e.list.len++
	}
}

func (e *Element) UnLink()           {          e.next.prev, e.prev.next = e.prev, e.next;		e.list.len--}
func (e *Element) ReLink()           {          e.next.prev, e.prev.next = e, e;			e.list.len++}
