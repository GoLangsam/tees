﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package rhythm

import (
	"dlx/dance/dancing/rhythm/drummer"

	"dlx/list"

	"dlx/yingyang/stack"
)

type Rhythm struct {
	stack.DanceStack
	*drummer.Drummer
}

func New(stack stack.DanceStack, INI_Depth int, verbosedrums bool, verbosebeats bool) Rhythm {

	var drums = drummer.New( INI_Depth, verbosebeats )

	if verbosedrums {	drummer.Verbose = true
	} else {		drummer.Verbose = false }

	return Rhythm{stack, drums}
}

func (r Rhythm)OnGoal()			{	if Verbose {	r.Goal.Beat(r.Len())	}	}
func (r Rhythm)OnDead()			{	if Verbose {	r.Dead.Beat(r.Len())	}	}
func (r Rhythm)OnCall(l *list.List)	{	if Verbose {	r.Call.Beat(r.Len())	}	}
func (r Rhythm)OnLeaf(e *list.Element)	{	if Verbose {	r.Leaf.Beat(r.Len())	}	}

// Note: No drum for Push & Pop, as these occur in sync with Call