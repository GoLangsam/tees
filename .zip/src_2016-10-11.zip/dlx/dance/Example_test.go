﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dance_test
//package main

import (
	"dlx/dance/dancing"

	"dlx/list/test"

	"testing"
)

// ========================================================

func NQueensR( anz int ) {

//	fmt.Println()
//	fmt.Println( "Queens on a", anz, "Board" )

	var dancing = dancing.New(false, false, false, false, false)

	var cols = test.NQueensR( anz )
	var       dance = func(){ dancing.DanceFast(cols) }

	dancing.Dancing.Dance = dance
	dancing.Dancing.Dance()

	dancing.Print()
}

// ========================================================

func NQueensRTest(beg, end int) {
	for i := beg; i <= end; i++ {
		NQueensR( i )
	}
}

// ========================================================

func ExampleNQueensR(t *testing.T) {
// func main() {

	beg := 1
	end := 13

	NQueensRTest(beg, end)
}

// ========================================================

func BenchmarkNQueensR(b *testing.B) {
	b.ReportAllocs()
	for i := 1; i < b.N; i++ {
		NQueensR( 12 )
	}
}

// ========================================================
