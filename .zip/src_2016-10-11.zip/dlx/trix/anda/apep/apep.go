﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
Apep <=> Darkness & Chaos

	- New(v, vals...)

*/
package apep

import (
	"dlx/list"
)

// AndaApep represents the dark stuff
type AndaApep	struct{
	*list.List
}

// New returns an initialized apep.
func New(v interface{}, vals ...interface{}) *AndaApep {
	var atom = new(AndaApep)
	atom.List = list.NewList( v, vals... )
	return atom
}
