﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*

"GoTo" is an alias for a kind of function to reach another existing element (or nil) from some element e

"From" returns the *list.Element (or nil) reached from e by applying some Kata's (=[]GoTo)
"Grab" is greedy and returns the slice of all *list.Element reached from e
"Haul" is steady and returns the slice of *list.Element reached from e keeping going until seen or nil

"Walker" returns an hauling iterator
TODO: "Turner" returns an hauling iterator roundrobbing it's akas
*/
package walk

import (
	"dlx/list"
)

// GoTo's represent basic functions to Step from some element to another existing element (or nil)
type GoTo uint8	// func( *list.Element ) *list.Element

// Distance represents the 'length' of some movement
// for a Kata it is the sum of it's GoTo distances
// for a Atas it is the 'radius', that is the max of it's Kata's distances
type Distance uint

const (
	Next	GoTo = iota
	Prev
	Away
	Root
	Front
	Back
	Home
)

// Kata (Japanese) is a form of movement (in martial arts)
type Kata []GoTo // Japanese

// Akas (Burmese) is a slice of forms of movement (in martial arts, and dances :-) )
type Akas []Kata // Burmese


// ========================================================
// from returns the Element (or nil) reached from e by applying GoTo
func ( g GoTo ) from (e *list.Element) (*list.Element, Distance) {

	var dist Distance
	var next *list.Element	= e

	if e != nil {
		switch g {
		case Next:	next = e.Next()		; if next != nil { dist = 1 }
		case Prev:	next = e.Prev()		; if next != nil { dist = 1 }
		case Away:	next = e.Away()

		case Root:	next = e.Root()		; if next != nil { dist = Distance(e.List().Len()) }

		case Front:	next = e.Front()	; if next != nil { dist = Distance(e.List().Len()) }
		case Back:	next = e.Back()		; if next != nil { dist = Distance(e.List().Len()) }
		case Home:	next = e.Home()		; if next != nil { dist = Distance(e.List().Len()) }						// Homerun is long, but free :-)

		default:	panic( "Undefined value for GoTo" )
		}
	}
	return next, dist
}

// ========================================================

// From returns the Element (or nil) reached from e by steps
func (steps Kata) From ( e *list.Element ) (*list.Element, Distance) {
	var dist, dnow Distance
	goal := e
	for _, step := range steps {
		if goal == nil { return nil, dist }
		goal, dnow = step.from( goal )
		dist+=dnow
	}
	return goal, dist
}

// From returns the non-nil Elements reached from e by jumps
func (jumps Akas) From ( e *list.Element ) ([]*list.Element, Distance) {
	var dist, dnow Distance
	goal := e
	goals := make([]*list.Element,  0, len(jumps) )
	for _, steps := range jumps {
		goal, dnow = steps.From( e )
		if goal == nil { continue }
		goals = append(goals, goal)
		dist+=dnow
	}
	return goals, dist
}

// ========================================================

// Grab returns all Elements reached from e by steps
// until nil or same is found
// Note: Grab may be useful in debugging, as it returns a full trace
// To Grab is not intended for regular use - Don't be greedy :-)
func (steps Kata) Grab (e *list.Element) ([]*list.Element, Distance) {
	var dist, dnow Distance
	goal := e
	last := goal
	goals := make([]*list.Element,  0, len(steps) )
	for _, step := range steps {
		last = goal
		goal, dnow = step.from( goal )
		if goal == nil || goal == last { continue }
		goals = append(goals, goal)
		dist+=dnow
	}
	return goals, dist
}

// Grab returns all Elements reached from e by jumps
// Note: Grab may be useful in debugging, as it returns a full trace
// To Grab is not intended for regular use - Don't be greedy :-)
func (jumps Akas) Grab (e *list.Element) ([]*list.Element, Distance) {
	var dist Distance
	goals := make([]*list.Element,  0, len(jumps)*len(jumps) )
	for _, steps := range jumps {
		goal, dnow := steps.Grab( e )
		if goal == nil || len(goal) == 0 { continue }
		goals = append(goals, goal...)
		dist+=dnow
	}
	return goals, dist
}

// ========================================================

// Haul returns the Elements (or nil) From e by repeating steps
// until nil or seen is found
func (steps Kata) Haul ( e *list.Element ) ([]*list.Element, Distance) {
	var seen = make(map[*list.Element]bool)
	var dist, dnow Distance
	var goal = e
	goals := make([]*list.Element, 0, len(steps)*8 )
	for {
		goal, dnow = steps.From( goal )
		if goal == nil || seen[goal] { return goals, dist }
		seen[goal] = true
		goals = append(goals, goal)
		dist+=dnow
	}
}

// Haul returns the Elements (or nil) From e by hauling jumps
// Note: From any new goal, just the current Kata is repeated!
// Not all jumps are done again - this would imply loops.
func (jumps Akas) Haul ( e *list.Element ) ([]*list.Element, Distance) {
	var dist Distance
	goals := make([]*list.Element, 0, len(jumps)*len(jumps)*8 )
	for _, steps := range jumps {
		goal, dnow := steps.Haul( e )
		if goal == nil || len(goal) == 0 { continue }
		goals = append(goals, goal...)
		dist+=dnow
	}
	return goals, dist
}
// ========================================================
// Iterator

// Walk: an iterator
// Usage: for e := w(), e != nil, e = w() {}
type Walk func() *list.Element


// Walker returns an iterator repeating Kata.From(e) ...
func (steps Kata) Walker(e *list.Element) Walk {
	var seen = make(map[*list.Element]bool)
	var curr = e
	var kata = steps

	var move Walk = func() *list.Element {
		seen[curr] = true
		if curr == nil { return nil }
		curr, _ = kata.From( curr )
		if seen[curr] { return nil } // already seen
		return curr
	}
	return move
}

// Walker returns an iterator walking all Kata.From(e) ...
func (jumps Akas) Walker(e *list.Element) Walk {
	var here = e
	var akas = jumps
	var maxi = len(akas)-1
	var curr int // index of akas
	var next = akas[curr].Walker(here)

	var move Walk = func() *list.Element {
next:		goal := next()
		if goal == nil && curr < maxi {
			curr++
			next = akas[curr].Walker(here)
			goto next
		}
		return goal
	}
	return move
}
