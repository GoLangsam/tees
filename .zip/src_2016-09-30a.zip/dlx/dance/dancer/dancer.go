﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go defines a dancer

*/
package dancer

import (
	"dlx/list"

	"fmt"
)

type Dancer struct {
	stack []*list.List
	CallBack func()
	Chooser	func(*list.List) *list.List
	UpDateCount map[int]int	// UpDate counts unLink per Level
	UnDateCount map[int]int	// UnDate counts reLink per Level
	Level int
	LevelCount map[int]int
}

const INI_LEV = 10
const INI_SOL = 1000

func New() *Dancer {
	var d = new( Dancer )
	d.stack = make([]*list.List, 0, INI_SOL)
//	d.CallBack = Fold
//	d.Chooser = ChooseFront

	d.UpDateCount = make( map[int]int, INI_LEV )
	d.UnDateCount = make( map[int]int, INI_LEV )
	d.Level = 0
	d.LevelCount = make( map[int]int, INI_LEV )

	return d
}

// implement interface list.Dancer
func (d *Dancer) Fold( l *list.List ){	// Push
	d.stack = append(d.stack, l)
}
func (d *Dancer) Open() *list.List {	// Pop
	p := d.stack[len(d.stack)-1]
	d.stack = d.stack[:len(d.stack)-1]
	return p
}
func (d *Dancer) Dance() {		// CallBack
	d.CallBack()
}


func (d *Dancer) Solution() []*list.List {
	return d.stack
}

func (d *Dancer) Len() int {
	return len(d.stack)
}
func (d *Dancer) Top() *list.List {
	return d.stack[len(d.stack)-1]
}
// ========================================================
func (d *Dancer) UpDate() {
	d.UpDateCount[d.Level]++
}
func (d *Dancer) UnDate() {
	d.UnDateCount[d.Level]++
}

func (d *Dancer) NewLevel() {
	d.LevelCount[len(d.stack)]++
}

// ========================================================
func (d *Dancer) HiHoSlow(l *list.List) bool {
	d.NewLevel()
	return d.HiHo(l)
}

// ========================================================
func (d *Dancer) HiHo(l *list.List) bool {
	d.Level++
//	if d.Level != len(d.stack) {panic("Dancer: Level & Stack.len out of sync!")}
	return d.HiHoFast(l)
}

// ========================================================
func (d *Dancer) HiHoFast(l *list.List) bool {
	if l.Len() == 0 { // || l.Root().Away().List().Len() == 0 {
		d.Print()
		return false
		} else {
		return true
	}
}

// ========================================================
func (d *Dancer) Print() {
	fmt.Print( "Solution: ")
	fmt.Println( d.Len() )
	for _, l := range d.Solution() {
		l.PrintValue()
		fmt.Print( ": " )
		for e := l.Front(); e != nil; e = e.Next() {
			e.Away().List().Root().PrintValue()
			fmt.Print( " " )
		}
		fmt.Println( "." )
	}
}
