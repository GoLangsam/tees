﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dance.go allows to perform and control a dance of links

*/
package dance

import (
	"dlx/dance/dancer"

	"dlx/list"
)


// ========================================================
func DanceSlow(l *list.List, d *dancer.Dancer) {
	if d.HiHoSlow(l) {	// Say Hello to Dancer
		d.Chooser(l).DanceSlow( d )	// If Dance ain't finished: choose sth to dance on
	}
}

// ========================================================
