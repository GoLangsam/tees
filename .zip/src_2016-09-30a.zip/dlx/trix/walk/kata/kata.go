﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
kata (Japanese) is a form of movement (in martial arts)

	- New(v, vals...)

*/
package kata

import (
	"dlx/list"
	"dlx/trix/walk"
)

// Kata (Japanese) is a form of movement (in martial arts)
type Kata	struct{
	*list.List
}

// New returns an initialized kata.
func New(v interface{}, vals ...interface{}) *Kata {
	var atom = new(Kata)
	atom.List = list.NewList( v, vals... )
	return atom
}

// Walker returns an iterator repeating Kata.From(e) ...
func (steps Kata) Walker(e *list.Element) walk.Walk {
	var seen = make(map[*list.Element]bool)
	var curr = e

	var goTo = steps.Front()
	var jump = goTo.Value.(walk.GoTo)

	var move walk.Walk = func() *list.Element {
		seen[curr] = true
retry:		curr = jump( curr )
		if curr == nil {
			goTo = goTo.Next()
			if goTo == nil { return nil }
			jump = goTo.Value.(walk.GoTo)
			goto retry
		}
		if seen[curr] { return nil } // already seen
		return curr
	}
	return move
}

func (steps Kata) PrintWalker( from *list.Element ) {
	steps.PrintValue()
	steps.Walker(from).Print( from )
}
