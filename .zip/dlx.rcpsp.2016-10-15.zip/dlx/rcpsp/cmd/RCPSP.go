﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// RCPSP - Resource-Constrained Project Scheduling Problem
package main

import (
	"dlx/rcpsp"
	"dlx/rcpsp/sample"

	"fmt"
)

func main() {
	var p = sample.GetSample()
	for i, todoID := range rcpsp.TopoSort(p.TodoTodos) {
		fmt.Printf("%d:\t%s\n", i+1, todoID)
	}
}