﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//package dance_test
package main

import (
	"dlx/dance"
	"dlx/dance/chooser"
	"dlx/dance/dancer"
	"dlx/dance/drummer"
	"dlx/dance/test"

	stack "dlx/list/stack4list"

	"dlx/list"

	"fmt"

	"dlx/yingyang/stack"
)

var INI_Depth = 100
var Drummer = drummer.New( INI_Depth )
var Stacker *stack.Stack = stack.New()

var PrintSolutions bool = false


func chooseUpto3() chooser.Chooser {
	var f = chooser.ChooseUpto3
	return f
}

func onDead(d *dancer.Dancer) dancer.Callback     {	return func()			{Drummer.Deadend.Beat(d.Level)}	}
func onCall(d *dancer.Dancer) dancer.CallWithList {	return func(  *list.List)	{Drummer.Niveaus.Beat(d.Level)}	}
func onLeaf(d *dancer.Dancer) dancer.CallWithElem {	return func(e *list.Element )	{Drummer.UpDates.Beat(d.Level)}	}
func onPush(d *dancer.Dancer) dancer.CallWithList {	return func(l *list.List)	{        Stacker.Push(l) }	}
func onPop (d *dancer.Dancer) dancer.CallForList  {	return func() *list.List	{ return Stacker.Pop() }	}
func onLen (d *dancer.Dancer) dancer.CallForInt   {	return func() int		{ return Stacker.Len() }	}

func onGoal(d *dancer.Dancer) dancer.Callback     {
	var f = func() {
		Drummer.Grooves.Beat(Stacker.Len())
		if PrintSolutions { Stacker.Print() }
//		do sth with Stacker.Get()
	}
	return f
}


func Prepare( anz int ) *dancer.Dancer {
	var cols = test.NQueensR( anz )
//	cols.PrintAways()
	fmt.Printf("%s\t% 9d\t"+"\n", "Size:", Size( cols) ) // this just gives cols * rows (ignoring secondary)
	fmt.Printf("%s\t% 9d\t"+"\n", "Trix: ", Size( cols.AwayList() ) ) // this just gives cols * rows (ignoring secondary)

	d := dancer.New()

	d.CallOnDead = onDead(d) //func(){ Drummer.Deadend.Beat(d.Level) }			//
	d.CallOnCall = onCall(d) //func(*list.List) { Drummer.Niveaus.Beat(d.Level)}	//
	d.CallOnLeaf = onLeaf(d) //func( e *list.Element ){ Drummer.UpDates.Beat(d.Level) }
	d.CallOnPush = onPush(d)
	d.CallOnPop  = onPop(d)
	d.CallOnLen  = onLen(d)

//	chooser.Verbose = true
//	dancer.Verbose = true
	d.Chooser = chooseUpto3() // chooser.ChooseUpto3
//	d.Chooser = chooser.ChooseShortNonEmpty
//	d.Chooser = chooser.ChooseShort
//	d.Chooser = chooser.ChooseFront
	d.PrintSolutions = false
//	dancer.Verbose = true

	d.CallBack = func(){ dance.DanceSlow(cols, d) } // TODO: dance.DanceFast(cols, d)

	return d
}

func NQueensR( anz int ) {

	d := Prepare( anz )
	d.CallBack()
	PrintCounters()
}

func main() {
	beg := 6
	end := 8

	for i := beg; i < end; i++ {
		fmt.Println()
		fmt.Println( "Queens on a", i, "Board" )
		NQueensR( i )
	}
}

// ========================================================
// Printing

func PrintCounters() {
	Drummer.Grooves.Print()
	Drummer.Niveaus.Print()
	Drummer.UpDates.Print()
}

// Helpers
func Size( l *list.List ) int {
	var c int
	for e := l.Front(); e != nil; e = e.Next() {
		c+=e.AwayList().Len()
	}
	return c
}

