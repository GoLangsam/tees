﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main
// package list_test

import (
	"dlx/list"

	"dlx/trix/math"

	"dlx/trix/walk/move"

	"fmt"
)

//func ExampleIter() {
func main() {
	// Create a new list
	var chess = list.NewList( "Chess" )

	// Create new lists
	var cols = chess.AddBeam( "Spalten", "A", "B", "C", "D", "E" )
	var rows = chess.AddBeam( "Zeilen", 1, 2, 3, 4, 5 )
	fmt.Println("Starting")

	var board = math.Xross( cols, rows )
	board.PrintAways( "Schach" )
	var s = board.Front().Away().List().Front()		// A|1
	var m = s.Next().Next().Away().Next().Next().Away()	// C|3
	var e = board.Back().Away().List().Back()		// E|5
	if s.IsRoot() || m.IsRoot() || e.IsRoot() {}

	gotonext := move.GotoNext
	gotonext.PrintValue(); gotonext.From(m).Print(m)
	gotonext.PrintValue(); gotonext.Grab(m).Print(m)
//	move.GotoNext.PrintWalker(m)

	rightdown := move.DiagRightDown
	rightdown.PrintValue(); rightdown.From(m).Print(m)
	rightdown.PrintValue(); rightdown.Grab(m).Print(m)
// //	move.DiagRightDown.PrintWalker(m)
//	move.JumpKnight_NND.PrintWalker(m)

//	move.ChessKing.PrintWalker(m)

}
