﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
Akas <=> list of Kata

	- New(v, vals...)

*/
package akas

import (
	"dlx/list"
)

// Akas (Burmese) is a list of forms of movement (in martial arts, and dances :-) )
type Akas	struct{
	*list.List
}

// New returns an initialized akas.
func New(v interface{}, vals ...interface{}) *Akas {
	var atom = new(Akas)
	atom.List = list.NewList( v, vals... )
	return atom
}
