﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dance

import (
	"dlx/dance/dancer"

	"dlx/list"
)

// Dance - standard dancer-callback (incl. Level)
func Dance(l *list.List, dancer *dancer.Dancer) {
	if dance, dancing := dancer.Dancing(l); dancing {	// Say Hello to Dancer, and if dancing ain't finished:

		dancer.Level++


		dance.Dance( dancer )				// Dance on dance with dancer

		dancer.Level--
		if dancer.Level != dancer.Len() { panic("Dancer: Level & Stack.len out of sync!") }
	}
}

// ========================================================
