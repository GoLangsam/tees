﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package drummer

import (
)

type Drummer struct {
	Niveaus *Counter		// Niveaus counts dances per Level
	UpDates *Counter		// UpDates counts unLink per Level
	Grooves *Counter		// Grooves counts solutions per length
	Deadend *Counter		// Deadend counts dead ends per Level
}

func New(cap int) *Drummer {
	var d = new(Drummer)
	d = d.Init(cap)
	return d
}

func (d *Drummer) Init(cap int) *Drummer {
	d.Niveaus = NewDrum("Niveaus", cap)
	d.UpDates = NewDrum("UpDates", cap)
	d.Grooves = NewDrum("Grooves", cap)
	d.Deadend = NewDrum("Deadend", cap)
	return d
}
