﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//package dance_test
package main

import (
	"dlx/dance"
	"dlx/dance/chooser"
	"dlx/dance/dancer"
	"dlx/dance/test"

	"dlx/list"

	"fmt"
)

func Size( l *list.List ) int {
	var c int
	for e := l.Front(); e != nil; e = e.Next() {
		c+=e.AwayList().Len()
	}
	return c
}

func NQueensR( anz int ) {

	var cols = test.NQueensR( anz )
//	cols.PrintAways()
	fmt.Printf("%s\t% 9d\t"+"\n", "Size:", Size( cols) ) // this just gives cols * rows (ignoring secondary)
	fmt.Printf("%s\t% 9d\t"+"\n", "Trix: ", Size( cols.AwayList() ) ) // this just gives cols * rows (ignoring secondary)

	if true {
	d := dancer.New()
//	chooser.Verbose = true
//	dancer.Verbose = true
	d.Chooser = chooser.ChooseUpto3
//	d.Chooser = chooser.ChooseShortNonEmpty
//	d.Chooser = chooser.ChooseShort
//	d.Chooser = chooser.ChooseFront
	d.PrintSolutions = false
	d.CallBack = func(){ dance.DanceSlow(cols, d) } // TODO: dance.DanceFast(cols, d)
	d.CallBack()

	d.PrintCounters()
	}
}

func main() {
	beg := 6
	end := 8

	for i := beg; i < end; i++ {
		fmt.Println()
		fmt.Println( "Queens on a", i, "Board" )
		NQueensR( i )
	}
}