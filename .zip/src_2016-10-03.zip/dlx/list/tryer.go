﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
tryer.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- Tryer interface: Ask, Get, Try, OnNode

*/
package list

type Tryer interface {
	Ask( *List ) bool
	Get() *List
	Try()

	OnLeaf( *Element )

//	...
}
