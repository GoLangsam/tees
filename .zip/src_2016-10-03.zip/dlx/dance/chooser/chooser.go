﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
chooser.go defines some Chooser's = functions to choose sth for a dancer to dance on

*/
package chooser

import (
	"dlx/list"
)
// ========================================================

type Chooser func(*list.List) (*list.List, bool)

// ChooseFront simply returns the first column
func ChooseFront (l *list.List) (*list.List, bool) {
	if Verbose {
		l.PrintAways("Choosing from: ")
		if l == nil { panic( "List to choose from is nil!") }
		e := l.Front()
		if e == nil { return nil, false }
		e = l.Front().Away()
		if e == nil { return nil, false }
	}

	c := l.Front().Away().List()
	if c == nil { return nil, false }
	if Verbose { c.PrintAways("Chosen: ") }
	return c, true
}

// ========================================================

// ChooseShort returns the smallest column
func ChooseShort (l *list.List) (*list.List, bool) {
	return ChooseUpto(l, 0)
}

// ChooseShortNonEmpty returns the smallest non-empty column
func ChooseShortNonEmpty (l *list.List) (*list.List, bool) {
	return ChooseUpto(l, 1)
}

// ChooseUpto2 returns the smallest non-empty column
func ChooseUpto2 (l *list.List) (*list.List, bool) {
	return ChooseUpto(l, 2)
}

// ChooseUpto3 returns the smallest non-empty column
func ChooseUpto3 (l *list.List) (*list.List, bool) {
	return ChooseUpto(l, 3)
}

// ========================================================

// ChooseBelow returns the first non-empty column not longer than min
func ChooseUpto (l *list.List, min int) (*list.List, bool) {
	var found bool = false
	var c *list.List
	s := 999999999
	for j := l.Front(); j != nil; j = j.Next()	{
		list := j.Away().List()
		if list != nil {
			leng := list.Len()
			if leng < s {
				c = list
				s = leng
				found = true
				if s <= min {
					break
				}

			}
		}
	}
	if Verbose { c.PrintValue("Chosen: ") }
	return c, found
}

// ========================================================

// TODO: ChooseOrgan also considers the total length of the aways (=rows) - the higher the better

/*
	currlist curraway
	looklist lookaway

	d := looklist - currlist
	a := lookaway - curraway

	if a > d * weight { curr = look }

	switch d {
		d < 0: if a < 0 {if a < d	{ curr = look } }	// look is shorter; but should not have much less aways (not a>=0 or
		d = 0: if a > 0			{ curr = look }		// look has same len; look has more aways
		d > 0: if a > d * weight	{ curr = look }		// look is longer; look has weight more aways

	}


	if looklist <= currlist

	> currlist + curraway

*/
