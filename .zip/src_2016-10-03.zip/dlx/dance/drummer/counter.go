﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package drummer

import (
	"fmt"
	"sort"
)

type counter map[int]int64
type Counter struct {
	Nam string
	Cnt int
	Map counter
}

func NewDrum (nam string, cap int) *Counter {
	return new(Counter).Init( nam, cap )
}

func (c *Counter) Init (nam string, cap int) *Counter {
	c.Nam = nam
	c.Cnt = 0
	c.Map = make( counter, cap )
	return c
}

func (c *Counter) Beat (cur int) {
	c.Cnt++
	c.Map[cur]++
}

// Sort returns the keys of c.Map in a sorted slice
func (c *Counter) Sort() []int {
	var keys sort.IntSlice
	for key := range c.Map {
		keys = append(keys, key )
	}
	keys.Sort()	// Note: see also sort.Ints( []int )
	return keys
}

// Print prints a counter, if it's not empty, as lines of tab-terminated cells
func (c *Counter) Print() {
	if c.Cnt < 1 {return} // do not print empty counter
	fmt.Printf("%s\t% 9d\t"+"\n", c.Nam, c.Cnt)
	for _, key := range c.Sort() {
		fmt.Printf("%6d\t% 9d\t"+"\n", key, c.Map[key])
	}
}
