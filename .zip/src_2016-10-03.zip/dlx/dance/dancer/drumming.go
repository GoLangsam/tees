﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
drumming.go
*/
package dancer

import (
	"dlx/list"
)

// ========================================================

// OnLeaf (for extended interface list.Dancer & list.Tryer)
func (d *Dancer) OnLeaf( e *list.Element ) {
	d.Drummer.UpDates.Beat(d.Level)
}

// OnCall (for danceslow)
func (d *Dancer) OnCall( l *list.List ) {
	d.Drummer.Niveaus.Beat(d.Level)
}

// OnGoal
func (d *Dancer) OnGoal([]*list.List) {
	d.Drummer.Grooves.Beat(d.Len())
	if d.PrintSolutions { d.Stacker.Print() }
//	d.Stacker.Get()
}

// OnDead
func (d *Dancer) OnDead() {
	d.Drummer.Deadend.Beat(d.Level)
}

// ========================================================

func (d *Dancer) PrintCounters() {
	d.Drummer.Grooves.Print()
	d.Drummer.Niveaus.Print()
	d.Drummer.UpDates.Print()
}
