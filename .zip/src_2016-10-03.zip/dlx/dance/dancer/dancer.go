﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go defines a dancer and a tryer
*/
package dancer

import (
	"dlx/list"
	stack "dlx/list/stack4list"

	"dlx/dance/chooser"
	"dlx/dance/drummer"

	"fmt"
)

type Scorer interface{
	DoGoal( []*list.List )
}

type callback func()
var noop callback = func(){return}

// type chooser func(*list.List) (*list.List, bool)

type Dancer struct {

	CallBack callback

	Chooser	chooser.Chooser	// chooser
	Drummer	*drummer.Drummer
	Stacker *stack.Stack

	Level int

	PrintSolutions bool
}

var INI_Depth = 100

type dance func()

func New() *Dancer {			// cannot pass CallBack upon New, as it is a method of himself
	return new( Dancer ).Init()
}

func (d *Dancer) Init() *Dancer {
	d.CallBack = noop

	d.Chooser = chooser.ChooseShort // ..Front ..ShortNonEmpty ..Below( int )
	d.Drummer = drummer.New( INI_Depth )
	d.Stacker = stack.New()

	d.Level = 0

	d.PrintSolutions = true

	return d
}

// ========================================================

func (d *Dancer) Dancing(l *list.List) (*list.List, bool) {
	if Verbose {
		l.PrintValue()
		l.PrintAways()
		d.Stacker.Print()
		fmt.Println( "Level: ", d.Level)
	}

	if l.Len() == 0 {
		d.OnGoal(d.Stacker.Get())
		return nil, false
	} else {
		cols, look := d.Chooser(l)
		if !look {d.OnDead()}
		return cols, look
	}
}
