﻿// Copyright 2013 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package iter

import (
	"dlx/list"
	"fmt"
)

func (kata kata) PrintWalker( from *list.Element ) {
	kata.PrintValue()
	kata.Walker(from).Print( from )
}
/*
func (akas akas) PrintWalker( from *list.Element ) {
	akas.Walker(from).Print( from )
}
*/
func (next walk) Print( from *list.Element ) {
	from.PrintValue("\t=>")
	for x := next(); x != nil; x = next() {
		x.PrintValue(" ->")
	}
	fmt.Println()
}

