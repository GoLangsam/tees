﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go defines a dancer

*/
package dancer

import (
	"dlx/list"
	"fmt"
)

type Dancer struct {
	stack []*list.List
	CallBack func()
	Chooser	func(*list.List) *list.List
	Levelcount map[int]int
}

func New() *Dancer {
	var d = new( Dancer )
	d.stack = make([]*list.List, 0, 1000)
//	d.CallBack = Fold
//	d.Chooser = ChooseFront
	d.Levelcount = make( map[int]int )
	return d
}

// implement interface list.Dancer
func (d *Dancer) Fold( l *list.List ){	// Push
	d.stack = append(d.stack, l)
}
func (d *Dancer) Open() *list.List {	// Pop
	p := d.stack[len(d.stack)-1]
	d.stack = d.stack[:len(d.stack)-1]
	return p
}
func (d *Dancer) Dance() {		// CallBack
	d.CallBack()
}


func (d *Dancer) Solution() []*list.List {
	return d.stack
}

func (d *Dancer) Len() int {
	return len(d.stack)
}
func (d *Dancer) Top() *list.List {
	return d.stack[len(d.stack)-1]
}

func (d *Dancer) HiHo(l *list.List) bool {
	d.Levelcount[d.Len()]++
	if l.Len() == 0 { // || l.Root().Away().List().Len() == 0 {
		d.Print()
		return false
		} else {
		return true
	}
}

// ========================================================
func (d *Dancer) Print() {
	fmt.Print( "Solution: ")
	fmt.Println( d.Len() )
	for _, l := range d.Solution() {
		l.PrintValue()
		fmt.Print( ": " )
		for e := l.Front(); e != nil; e = e.Next() {
			e.Away().List().Root().PrintValue()
			fmt.Print( " " )
		}
		fmt.Println( "." )
	}
}
