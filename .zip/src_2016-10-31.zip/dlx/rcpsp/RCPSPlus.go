﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package rcpsp

// RCPSP - Resource-Constrained Project Scheduling Problem

import (
	"dlx/anything/normal/drum"
)

type TodoPreds map[TodoID]Todos

type RCPSPlus struct {
	*RCPSP
	TodoPreds	TodoTodos
	PredPreds	map[TodoID]map[TodoID]bool

	FoodTotal	Avail
	TimeTotal	Times

	AvailFood	*drum.Histogram
	TimesTodo	*drum.Histogram

}

func (r *RCPSP) Enrich() *RCPSPlus {

	var rp = new(RCPSPlus)
	rp.RCPSP = r

	rp.TodoPreds = rp.GetTodoPreds()

	rp.PredPreds = rp.GetPredTotal()

	for _, currAV := range r.FoodAvail {
		rp.FoodTotal += currAV
	}

	for _, currTM := range r.TodoTakes {
		rp.TimeTotal += currTM
	}

	drum.Verbose = true
	rp.AvailFood = drum.NewHistogram("Avail", 25)
	for _, v := range rp.FoodAvail {
		rp.AvailFood.Beat(int(v))
	}

	rp.TimesTodo = drum.NewHistogram("Times", 25)
	for _, v := range rp.TodoTakes {
		rp.TimesTodo.Beat(int(v))
	}

	return rp
}

func (r *RCPSPlus) GetTodoPreds() TodoTodos {

	var tp = make(map[TodoID]Todos)

	for currID, succ := range r.TodoTodos {
		for _, succID := range succ {
			tp[succID] = append(tp[succID], currID)
		}
	}
	return tp
}

func (r *RCPSPlus) GetPredTotal() map[TodoID]map[TodoID]bool {
	var m = make(map[TodoID]map[TodoID]bool)

	for _, todoID := range TopoSort(r.TodoPreds) {
		var t = make(map[TodoID]bool)
		for _, predID := range r.TodoPreds[todoID] {
			t[predID] = true
			for predID := range m[predID] {
				t[predID] = true
			}
		}
		m[todoID] = t
	}
	return m
}

