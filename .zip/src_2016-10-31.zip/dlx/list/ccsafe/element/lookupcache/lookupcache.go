﻿// Lookup provides a thread-safe mutex-guarded cache of *list.Element by some identifying string
package lookupcache

import (
	"dlx/list"

	"sync"
)

var cache = struct {
	sync.Mutex // guards mapping
	mapping map[string]*list.Element
	} {
	mapping: make(map[string]*list.Element),
}

// Lookup an Element given an identifying string
func Lookup(key string) *list.Element {
	cache.Lock()
	v := cache.mapping[key]
	cache.Unlock()
	return v
}
