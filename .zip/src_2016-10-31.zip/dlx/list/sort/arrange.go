// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package sort

import (
	"dlx/list"
	"dlx/list/math"

	"sort"
)

// Arrange rearranges l
func Arrange(l *list.List) *list.List {

	var keys sort.IntSlice
	var sizes = math.AwayListSizes(l)
	for size, _ := range sizes {
		keys = append(keys, size)
	}
	keys.Sort()
	
	var mark *list.Element
	for _, size := range keys {
		for _, e := range sizes[size] {
			mark = e.MoveToPrevOf( mark )
		}
	}
	return l
}
