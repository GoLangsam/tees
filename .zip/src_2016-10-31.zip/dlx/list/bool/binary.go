// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package bool

import (
	"dlx/list"
)

// ===========================================================================

// AreParallel reports if two elements are parallel with each other due to
// being on the same list, or on the same Root.AwayList
//	Note: nil is NOT considered parallel to nil
func AreParallel (x, y *list.Element) bool {
	if x == nil { return false }
	if y == nil { return false }
	
	return ( x.List() == y.List() || x.Root().AwayList() == y.Root().AwayList() )
}

// AreEqual reports if two elements are equal
//	Note: nil IS considered equal to nil
func AreEqual (x, y *list.Element) bool {
	if x == nil && y == nil { return true }
	if x == nil { return false }
	if y == nil { return false }

	return x.Equals(y)
}
