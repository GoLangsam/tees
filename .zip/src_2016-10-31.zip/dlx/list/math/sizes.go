// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package math

import (
	"dlx/list"
)

// ===========================================================================

func AwayListSizes(l *list.List) map[int][]*list.Element {
	var sizes = make(map[int][]*list.Element, l.Len())

	for e := l.Front(); e != nil; e = e.Next() {
		size := 0
		for f := e.AwayList().Front(); f != nil; f = f.Next() {
			size += f.AwayList().Size()
		}
		sizes[size] = append(sizes[size], e)
	}
	return sizes
}
