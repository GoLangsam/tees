﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dance

import (
	"dlx/list"
	"dlx/yingyang/spot"
)
// ========================================================

// Dance l is where the dancing begins
func Dance(l spot.Spot, d *list.Dancing ) {
	unC(l)
	DanceOn(l.Root(), d )
	reC(l)
}

// DanceOn e is where the dancing continues
func DanceOn(e spot.Spot, d *list.Dancing ) {
	ForEachNext(e, func(i *list.Element){
		d.OnGoal( i )		// Publish candidate
		unR(i.Away())
		d.Dance()		// Dance d is where the dancing recurs to
		reR(i.Away())
		d.OnFail()		// Pop
	} )
}

// ========================================================
func unC(c spot.Spot) { c.Away().UnLink();	unL(c)		}
func reC(c spot.Spot) { c.Away().ReLink();	reL(c)		}

func unR(r spot.Spot) { ForEachNext (r, unAf) }
func reR(r spot.Spot) { ForEachPrev (r, reAf) }

func unL(l spot.Spot) { ForEachNext (l, unEf) }
func reL(l spot.Spot) { ForEachPrev (l, reEf) }

func unE(e spot.Spot) { ForEachNext (e, unKf) }
func reE(e spot.Spot) { ForEachPrev (e, reKf) }

// ========================================================

var unAf = func( i *list.Element ){	unC(i.AwayList())}
var reAf = func( i *list.Element ){	reC(i.AwayList())}

var unEf = func( i *list.Element ){	unE(i.Away())}
var reEf = func( i *list.Element ){	reE(i.Away())}

var unKf = func( i *list.Element ){	i.Away().UnLink()}
var reKf = func( i *list.Element ){	i.Away().ReLink()}

// ========================================================

func ForEachNext( s spot.Spot, f func(*list.Element) ) {	s.ForEachNext(f)	}
func ForEachPrev( s spot.Spot, f func(*list.Element) ) {	s.ForEachPrev(f)	}

