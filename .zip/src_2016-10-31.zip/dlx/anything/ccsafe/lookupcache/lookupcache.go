﻿// Lookup provides a thread-safe mutex-guarded cache of *list.Element by some identifying string
package lookupcache

import (
	"sync"
)

var cache = struct {
	sync.Mutex // guards mapping
	mapping map[string]interface{}
	} {
	mapping: make(map[string]interface{}),
}

// Lookup sth given an identifying string
func Lookup(key string) interface{} {
	cache.Lock()
	v := cache.mapping[key]
	cache.Unlock()
	return v
}
