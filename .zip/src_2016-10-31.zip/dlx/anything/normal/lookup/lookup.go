﻿// Lookup provides a normal cache of interface{} by some identifying string
package lookup

import (
//	"sync"
)

var (
//	mu sync.Mutex // guards mapping
	mapping = make(map[string]interface{})
)

// Lookup sth given an identifying string
func Lookup(key string) interface{} {
//	mu.Lock()
	v := mapping[key]
//	mu.Unlock()
	return v
}
