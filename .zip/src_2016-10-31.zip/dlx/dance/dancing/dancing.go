﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dancing

import (
	"dlx/list"

	"dlx/dance/beat"	// Note: No drum for Push & Pop, as these occur in sync with Call
	"dlx/dance/turn"
)

type Dancing struct {
	Dancing		*list.Dancing
	Beating		*beat.Dancing
	Turning		*turn.Dancing

	Level		int

	Verbose		bool
	VerboseGoals	bool
	VerboseDrums	bool
	VerboseBeats	bool
}

func New(v, vg, rh, vd, vb bool) *Dancing {
	var d = new(Dancing)
	d = d.SetVerbose(v, vg, rh, vd, vb)	// before init, as init populates VerboseDrums
	return d
}

func (d *Dancing) SetVerbose(v, vg, rh, vb, vd bool) *Dancing {

	d.Verbose	= v
	d.VerboseGoals	= vg
	if rh {	beat.Verbose	= true
	} else {beat.Verbose	= false }
	d.VerboseBeats	= vb
	d.VerboseDrums	= vd

	return d
}
