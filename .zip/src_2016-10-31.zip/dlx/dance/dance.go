﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dance

import (
	"dlx/dance/beat"	// Note: No drum for Push & Pop, as these occur in sync with Call
	"dlx/dance/turn"
	"dlx/list"

	"dlx/dance/chooser"
	"dlx/dance/dancing"

	"dlx/list/normal/element/stack"
)

type Dance struct {
	Dancing		*dancing.Dancing

	Stacker		*stack.Stack
	Drummer		*beat.Drums
}

var INI_Depth = 100

func NewDance(v, vg, rh, vd, vb, vc bool) *Dance {
	var d = new(Dance)
	d.Dancing = dancing.New(v, vg, rh, vd, vb)
	d = d.SetBeating()
	d = d.SetDancing()
	d = d.SetTurning()

	if vc {	chooser.Verbose	= true
	} else {chooser.Verbose	= false }

	return d
}

func (d *Dance) SetBeating() *Dance {
	d.Drummer = beat.NewDrums( INI_Depth, d.Dancing.VerboseDrums )

	d.Dancing.Beating = beat.NewDancing()
	d.Dancing.Beating.Dance		= func(l *list.List)	{	d.Drummer.Goal.Beat(d.Dancing.Level)	}
	d.Dancing.Beating.OnGoal	= func(e *list.Element)	{	d.Drummer.Call.Beat(d.Dancing.Level)	}
	d.Dancing.Beating.OnFail	= func()		{	d.Drummer.Fail.Beat(d.Dancing.Level)	}
	d.Dancing.Beating.OnLeaf	= func(e *list.Element)	{	d.Drummer.Leaf.Beat(d.Dancing.Level)	}

	return d
}

func (d *Dance) SetDancing() *Dance {
	d.Stacker = stack.New()

	d.Dancing.Dancing = list.NewDancing()
	d.Dancing.Dancing.Dance		= func()		{	return }	// Client overrides
	d.Dancing.Dancing.OnGoal	= d.Stacker.Push
	d.Dancing.Dancing.OnFail	= d.Stacker.Pop
	d.Dancing.Dancing.OnLeaf	= d.Dancing.Beating.OnLeaf	// Note: defined in SetBeating above
	return d
}

func (d *Dance) SetTurning() *Dance {

	d.Dancing.Turning = turn.NewDancing()
	d.Dancing.Turning.Dance		= func(l *list.List) 	{	l.Dance(d.Dancing.Dancing)}
	d.Dancing.Turning.OnGoal	= d.onGoal			// YES We have a solution
	d.Dancing.Turning.OnFail	= chooser.ChooseShort		// YES We have to go on dancing & goaling
	d.Dancing.Turning.OnLeaf	= d.onLeaf			// YES We have to abort
	return d
}

func (d *Dance) onLeaf (l *list.List) bool {				// Do we have to abort?
	// d.Stacker.Top
	if d.Dancing.Verbose {
		l.PrintValue()
		l.PrintAways()
	}
	return false
}

func (d *Dance) onGoal (l *list.List) bool {				// Do we have a solution
	if l.IsEmpty() { // l.Len() == 0 // l.Size() == 0		// YES We have a solution
		if d.Dancing.VerboseGoals {d.PrintGoal()}		// ... we may show it
		return true
	} else {
		return false
	}
}