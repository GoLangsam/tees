﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
handler.go defines some Handler's = functions to handle a dancer dancing on sth

*/
package handler

import (
	"dlx/list"

	"dlx/dance/dancing"
)


// ========================================================

// GetHandlers returns all choosers defined in this package as a slice,
// which can be useful in benchmarking comparsions
func GetHandlers() []Handler {
	var c = make([]Handler, 0, 5)
	c = append(c, HandleDance)
	return c
}

// HandlerName returns the name of the chooser at index i of the result of GetChoosers
func HandlerName(i int) string {
	switch {
		case i == 0:	return "HandleDance"
		default:	return "<unknown>"
	}
}

// ========================================================

// Handler is the signature of a choosing function
type Handler func(d *dancing.Dancing, l *list.List)

// ========================================================

// HandleDance returns sth to dance on, or nil
func HandleDance(d *dancing.Dancing, l *list.List) {

	if d.Turning.OnLeaf(l){						// YES We have to abort
		return							// ... we quietly return
	}

	if d.Turning.OnGoal(l){						// YES We have a solution
		if d.VerboseBeats {d.Beating.Dance(l)}			// ... we count our happyness
		return
	}
	next, ok := d.Turning.OnFail(l); if !ok {			// YES We have a failure
		if d.VerboseBeats {d.Beating.OnFail()}			// ... we count our suffering
		return

	} else {							// YES We have to go on goaling
		if d.VerboseBeats {d.Beating.OnGoal(next.Root())}	// ... we count our effort
		if next == nil { panic("Confusing reply from Turning.OnFail: Cannot look into nil!")}
	}
	d.Level++
	d.Turning.Dance(next)
//	next.Dance(d.Dancing)
//	next.DanceFast(d.Dancing)
//	next.DanceSlow(d.Dancing)
	d.Level--
}
