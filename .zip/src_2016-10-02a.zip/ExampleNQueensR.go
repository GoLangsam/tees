﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//package dance_test
package main

import (
	"dlx/dance"
	"dlx/dance/chooser"
	"dlx/dance/dancer"
	"dlx/dance/test"

	"fmt"
)

func NQueensR( anz int ) {

	var cols = test.NQueensR( anz )
//	cols.PrintAways()

	if true {
	d := dancer.New()
//	chooser.Verbose = true
//	dancer.Verbose = true
	d.Chooser = chooser.ChooseShortNonEmpty
//	d.Chooser = chooser.ChooseShort
//	d.Chooser = chooser.ChooseFront
	d.PrintSolutions = false
	d.CallBack = func(){ dance.DanceSlow(cols, d) }
	d.CallBack()

	d.PrintCounters()
	}
}

func main() {
	for i := 1; i < 15; i++ {
		fmt.Println()
		fmt.Println( i, "Queens" )
		NQueensR( i )
	}
}