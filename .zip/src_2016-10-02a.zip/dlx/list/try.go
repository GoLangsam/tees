﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
try.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- l.Try( d Tryer )
	- e.Try( d Tryer )

*/
package list

type Tryer interface {
//	fastTryer
	Ask( *List ) bool
	Get() *List
	Try()

//	NewLevel()	// done outside (HiHoSlow)
	UpDate()
	UnDate()

//	...
}

// ========================================================

// Try l is where it begins
func (l *List)     Try( d Tryer ) {
	l.tryFold(d)
	l.root.Try( d )
	l.tryOpen(d)
}

// Try e is where it continues
func (e *Element)  Try( d Tryer ) {
	for i := e.next; i != e; i = i.next {
		if d.Ask( i.away.list ) {		// Push
			i.away.tryFold(d)
			d.Try()			// Try d is where it recurs to
			i.away.tryOpen(d)
		}
		d.Get()			// Pop
	}
}

// ========================================================
func (l *List)    tryFold( d Tryer ) { 						l.root.away.tryLink(d);	l.tryList(d)		    }
func (l *List)    tryOpen( d Tryer ) { 						l.root.away.yrtLink(d);	l.yrtList(d)		    }

func (e *Element) tryFold( d Tryer ) { for i := e.next; i != e; i = i.next { if i != &e.list.root {	i.away.list.tryFold(d)	} } }
func (e *Element) tryOpen( d Tryer ) { for i := e.prev; i != e; i = i.prev { if i != &e.list.root {	i.away.list.tryOpen(d)	} } }

func (l *List)    tryList( d Tryer ) { for i := l.root.next; i != &l.root; i = i.next { 			i.away.tryList(d)		  } }
func (l *List)    yrtList( d Tryer ) { for i := l.root.prev; i != &l.root; i = i.prev { 			i.away.yrtList(d)		  } }

func (e *Element) tryList( d Tryer ) { for i := e.next; i != e; i = i.next { if i != &e.list.root {	i.away.tryLink(d)	} } }
func (e *Element) yrtList( d Tryer ) { for i := e.prev; i != e; i = i.prev { if i != &e.list.root {	i.away.yrtLink(d)	} } }

func (e *Element) tryLink( d Tryer ) {          e.next.prev, e.prev.next = e.prev, e.next;		e.list.len--;	d.UpDate()	}
func (e *Element) yrtLink( d Tryer ) {          e.next.prev, e.prev.next = e, e;			e.list.len++;	d.UnDate()	}

/*
- on Cols:
	- l.fold()	l.unShow(col)			& tryLink( Col-Head )
	- l.open()	l.reShow(col)			& yrtLink( Col-Head )

- on Rows - walking hori:
	- e.fold()	e's.away.list.fold(col)		except e.list.root (row head)
	- e.open()	e's.away.list.open(col)		except e.list.root (row head)

- on Cols - walking vert: (no need to skip root explicitly, as it's called for l.root)
	- l.tryList()	l's.away.tryList(row)
	- l.yrtList()	l's.away.yrtList(row)

- on Rows - walking hori:
	- e.tryList()	e's.away.tryLink(col)		except e.list.root (row head)
	- e.yrtList()	e's.away.yrtLink(col)		except e.list.root (row head)

	- e.tryLink()
	- e.yrtLink()

*/