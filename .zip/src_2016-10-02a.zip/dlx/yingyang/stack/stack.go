﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stack

import (
	"dlx/list"
)

// ListStack abstracts the common behaviour of stacks for *list.List
type ListStack interface {
//	Init(int)	*ListStack
	Push(*list.List)
	Pop() *list.List
	Top() *list.List
	Len() int
}

// ElemStack abstracts the common behaviour of stacks for *list.Element
type ElemStack interface {
//	Init(int)	*ElemStack
	Push(*list.Element)
	Pop() *list.Element
	Top() *list.Element
	Len() int
}

// AnyStack abstracts the common behaviour of stacks for interface{}
type AnyStack interface {
//	Init(int)	*AnyStack
	Push(interface{})
	Pop() interface{}
	Top() interface{}
	Len() int
}
