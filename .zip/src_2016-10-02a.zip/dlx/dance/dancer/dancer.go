﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go defines a dancer

*/
package dancer

import (
	"dlx/list"
	stack "dlx/list/stack4list"

	"dlx/dance/chooser"

	"fmt"
)

import "sort"

type callback func()
var noop callback = func(){return}

type counter map[int]int
func newCounter() counter {
	return make( counter, INI_Depth )
}

type Dancer struct {
	stack *stack.Stack

	CallBack callback
	Chooser	chooser.Chooser

	UpDates int
	UpDateCount counter	// UpDate counts unLink per Level
	UnDates int
	UnDateCount counter	// UnDate counts reLink per Level

	Level int
	LevelCount counter

	PrintSolutions bool
}

var INI_Depth = 100

type dance func()

func New() *Dancer {			// cannot pass CallBack upon New, as it is a method of himself
	return new( Dancer ).Init()
}

func (d *Dancer) Init() *Dancer {
	d.stack = stack.New()

	d.CallBack = noop
	d.Chooser = chooser.ChooseShort // ..Front ..ShortNonEmpty ..Below( int )

	d.UpDates = 0
	d.UpDateCount = newCounter()
	d.UnDates = 0
	d.UnDateCount = newCounter()
	d.Level = 0
	d.LevelCount = newCounter()

	d.PrintSolutions = true

	return d
}

// ========================================================

// UpDate (for extended interface list.Dancer)
func (d *Dancer) UpDate() {
	d.UpDates++
	d.UpDateCount[d.Level]++
}
// UnDate (for extended interface list.Dancer)
func (d *Dancer) UnDate() {
	d.UnDates++
	d.UnDateCount[d.Level]++
}

// NewLevel (for extended interface list.Dancer)
func (d *Dancer) NewLevel() {
	d.LevelCount[d.Level]++
}

// ========================================================
// Ask (for interface list.Tryer) is a Push of the current stack
// and determination, if list is acceptable
func (d *Dancer) Ask( l *list.List ) bool {
	d.stack.Push(l)
	return true
}

// Try (for interface list.Tryer) is a callback
func (d *Dancer) Try() {
	d.CallBack()
}

// Get (for interface list.Tryer) is a Pop of the current stack
func (d *Dancer) Get() *list.List {
	return d.stack.Pop()
}


// ========================================================
// Fold (for interface list.Dancer) is a Push of the current stack
func (d *Dancer) Fold( l *list.List ){
	d.stack.Push(l)
}
// Open (for interface list.Dancer) is a Pop of the current stack
func (d *Dancer) Open() *list.List {
	return d.stack.Pop()
}

// Dance (for interface list.Dancer) is a callback
func (d *Dancer) Dance() {
	d.CallBack()
}

// Solution returns a copy of the current stack
func (d *Dancer) Solution() []*list.List {
	return d.stack.Get()
}

// Len returns the length of the current stack
func (d *Dancer) Len() int {
	return d.stack.Len()
}
// Top returns the top of the current stack
func (d *Dancer) Top() *list.List {
	return d.stack.Top()
}
// ========================================================


func (d *Dancer) Dancing(l *list.List) (*list.List, bool) {
	if Verbose {
		l.PrintValue()
		l.PrintAways()
		d.Print()
		fmt.Println( "Level: ", d.Level)
	}

	if l.Len() == 0 {
		if d.PrintSolutions {d.Print()}
		return nil, false
	} else {
		return d.Chooser(l)
	}
}

// ========================================================

// Print prints the current stack (= the solution)
func (d *Dancer) Print() {
//	fmt.Print( "Solution: ")
	d.stack.Print()
/*
	fmt.Println( d.Len() )
	for _, l := range d.stack {
		l.PrintValue()
		fmt.Print( ": " )
		for e := l.Front(); e != nil; e = e.Next() {
			e.Away().List().Root().PrintValue()
			fmt.Print( " " )
		}
		fmt.Println( "." )
	}
*/
}

func (d *Dancer) PrintCounters() {
	fmt.Println("Levels:")
	d.LevelCount.Print()

	fmt.Printf("%s\t%7d\n", "Updates", d.UpDates)
	d.UpDateCount.Print()

	fmt.Printf("%s\t%7d\n", "Undates", d.UnDates)
	d.UnDateCount.Print()
}

func (c counter) Print() {
	printCounter(c)
}

func printCounter(counter map[int]int) {
// import "sort"
	var names sort.IntSlice
	for name := range counter {
		names = append(names, name )
	}
	names.Sort()
	for _, name := range names {
		fmt.Printf("%7d\t%7d\t\n", name, counter[name])
	}
}