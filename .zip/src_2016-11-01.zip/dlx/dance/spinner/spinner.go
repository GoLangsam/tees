﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
spinner.go defines how to keep a dancer busy dancing a dance on sth to dance in search for goals

*/
package spinner

import (
	"dlx/list"

	"dlx/dance/dancing"
)


// ========================================================

// GetSpinners returns all choosers defined in this package as a slice,
// which can be useful in benchmarking comparsions
func GetSpinners() []Spinner {
	var c = make([]Spinner, 0, 5)
	c = append(c, Dance)
	return c
}

// SpinnerName returns the name of the chooser at index i of the result of GetChoosers
func SpinnerName(i int) string {
	switch {
		case i == 0:	return "Spinner"
		default:	return "<unknown>"
	}
}

// ========================================================

// Spinner is the signature of a choosing function
type Spinner func(d *dancing.Dancing, l *list.List)

