﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package beat

import (
	"dlx/list"
)

type Dancing struct {
	Dance   	func(e *list.List)

	OnGoal		func(e *list.Element)
	OnFail	   	func()
	OnLeaf		func(e *list.Element)
}

func NewDancing() *Dancing {
	return new( Dancing ).init()
}

func (d *Dancing) init() *Dancing {

	d.Dance		= func(e *list.List)	{return}

	d.OnGoal	= func(e *list.Element)	{return}
	d.OnFail	= func()		{return}
	d.OnLeaf	= func(e *list.Element)	{return}

	return d
}
