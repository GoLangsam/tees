﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package rcpsp

// RCPSP - Resource-Constrained Project Scheduling Problem

type TodoID string
type FoodID string

type Times int // Timeunits required
type Avail int // Foodunits required/available

type Todos []TodoID

type Needs map[FoodID]Avail

type TodoTakes map[TodoID]Times
type TodoNeeds map[TodoID]Needs
type TodoTodos map[TodoID]Todos

type FoodAvail map[FoodID]Avail

type RCPSP struct {
	TodoTakes
	TodoNeeds
	TodoTodos
	FoodAvail
}

