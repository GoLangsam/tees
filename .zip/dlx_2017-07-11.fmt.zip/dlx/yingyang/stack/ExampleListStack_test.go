// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stack_test

import (
	stackccsafe "dlx/list/ccsafe/list/stack"
	stacknormal "dlx/list/normal/list/stack"
)

func ExampleListStack() {
	var ns = stacknormal.New(7)
	testIsListStack(ns)
	testListStack(ns)
	testCanDrop(ns)
	testHasLen(ns)

	var cs = stackccsafe.New(7)
	testIsListStack(cs)
	testListStack(cs)
	testCanDrop(cs)
	testHasLen(cs)
}
