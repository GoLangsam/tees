// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stack_test

import (
	"dlx/yingyang/stack"
)

func testIsAnyStack(s stack.IsAnyStack) {}
func testAnyStack(s stack.AnyStack)     {}

func testIsListStack(s stack.IsListStack) {}
func testListStack(s stack.ListStack)     {}

func testIsElemStack(s stack.IsElemStack) {}
func testElemStack(s stack.ElemStack)     {}

// ========================================================

func testHasLen(s stack.StackHasLen)     {}
func testCanDrop(s stack.StackCanDrop)   {}
func testCanPrint(s stack.StackCanPrint) {}
