// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stack

// AnyStack abstracts the common behaviour of stacks for interface{}
type AnyStack interface {
//	Init(int)	*AnyStack
	Push( interface{} )
	Pop() interface{}
	Top() interface{}
	Get() []interface{}
}
