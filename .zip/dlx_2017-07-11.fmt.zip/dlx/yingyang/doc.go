// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
yingyang is a root for various packages which define interfaces,
in patricular for quasi-symmetric stuff such as List/Element, Akas/Kata
or very generic functionalities such as stack( interface{} ).

Related _test's should import and test ALL relevant objects for compliance!
*/
package yingyang
