// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package trixmove_test

import (
	"dlx/trix/walk/move"

	"dlx/yingyang/move/trixmove"
)

func test(m trixmove.Move) {}

func ExampleMove() {
	var kata = move.MoveUp
	test(kata)
	var akas = move.ChessKing
	test(akas)

}
