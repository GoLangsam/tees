// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package rcpsp

// RCPSP - Resource-Constrained Project Scheduling Problem

import (
	"fmt"

	"sort"
)

func (m TodoTakes) Sort() sort.StringSlice {
	var keys sort.StringSlice
	for key := range m {
		keys = append(keys, string(key))
	}
	keys.Sort()
	return keys
}

func (m TodoNeeds) Sort() sort.StringSlice {
	var keys sort.StringSlice
	for key := range m {
		keys = append(keys, string(key))
	}
	keys.Sort()
	return keys
}

func (m TodoTodos) Sort() sort.StringSlice {
	var keys sort.StringSlice
	for key := range m {
		keys = append(keys, string(key))
	}
	keys.Sort()
	return keys
}

func (m FoodAvail) Sort() sort.StringSlice {
	var keys sort.StringSlice
	for key := range m {
		keys = append(keys, string(key))
	}
	keys.Sort()
	return keys
}

// ===========================================================================

func (m TodoID) Print() {
	fmt.Printf("%s\t", m)
}

func (m FoodID) Print() {
	fmt.Printf("%s\t", m)
}

func (m TodoTakes) Print() {
	for _, id := range m.Sort() {
		fmt.Printf("%s:\t%2d\n", id, m[TodoID(id)])
	}
}

func (m TodoNeeds) Print() {
	for _, id := range m.Sort() {
		fmt.Printf("%s:\t", id)
		for id, need := range m[TodoID(id)] {
			fmt.Printf("%s: %2d\t", id, need)
		}
		fmt.Printf("\n")
	}
}

func (m TodoTodos) Print() {
	for _, id := range m.Sort() {
		fmt.Printf("%s:\t", id)
		for _, todo := range m[TodoID(id)] {
			todo.Print()
		}
		fmt.Printf("\n")
	}
}

func (m FoodAvail) Print() {
	for _, id := range m.Sort() {
		fmt.Printf("%s:\t%2d\n", id, m[FoodID(id)])
	}
}
