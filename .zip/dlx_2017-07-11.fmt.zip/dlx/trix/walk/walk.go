// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package walk

import (
	"dlx/list"
)

// GoTo's represent basic functions to Step from some element to another existing element (or nil)
type GoTo func(*list.Element) *list.Element

// Walk represents an iterator
// usage pattern: next := kata.Walker(e); for e := next(), e != nil, e = next() { /* ... */ }
type Walk func() *list.Element

// HiHo (or ZigZag) is a pair of Kata, the second one of which is applied once upon end of first
// type HiHo [2]kata.Kata

// Cursor
func Cursor(step GoTo, e *list.Element) Walk {
	var next = e
	var jump = step

	var move Walk = func() *list.Element {
		if next == nil { panic("Cannot walk away from nil!") }
		next = jump(next)
		return next
	}
	return move
}

/*
// Walker returns an iterator walking all Kata.From(e) ...
func (jumps akas.Akas) Walker(e *list.Element) Walk {
	var here = e
	var akas = jumps
	var maxi = len(akas)-1
	var curr int // index of akas
	var next = akas[curr].Walker(here)

	var move Walk = func() *list.Element {
next:		goal := next()
		if goal == nil && curr < maxi {
			curr++
			next = akas[curr].Walker(here)
			goto next
		}
		return goal
	}
	return move
}
*/

/*
func (jumps akas) Turner(e *list.Element) walk {
	var next = e
	var here = jumps.Front()
	var jump = here.Value.(GoTo)

	var move walk = func() *list.Element {
retry:		next = jump( next )
		if next == nil {
			here = here.Next()
			if here == nil { return next } // Note: next == nil
			jump = here.Value.(GoTo)
			goto retry
		}
		return next
	}
	return move
}
*/
