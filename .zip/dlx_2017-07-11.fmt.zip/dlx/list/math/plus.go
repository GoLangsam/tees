﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package math

import (
	"dlx/list"
)

// Append returns a new list: the union of l with some lists...
// ( recursively as [[[ l + l ] + l ] ... ] )
// Note: Append( l, nil ) returns a new copy of l with composedValues
// the root of which carries the CVs of the original l.Root()
// and the elements carry the CVs of the original elements
// Note: The Away's in the new list point to nil - thus, the new list is isolated.
func Append (l *list.List, lists ...*list.List ) *list.List {
	if len(lists) == 0 {	return plus( l, nil )  }
	if len(lists) == 1 {	return plus( l, lists[0] ) }
				return plus( l, Append( lists[0], lists[1:]... ) )
}

// ===========================================================================

// plus returns a new list with len(l) + len(X) Elements
// representing the union of the list l plus X
// Note: plus(X, nil ) returns a new copy of X with composedValues
// Note: The Away's in the new list point to nil - thus, the new list is isolated.
func plus ( X, Y *list.List ) *list.List {
	if X == nil{ return list.NewList( nil ) }
	newl := list.NewList( X.CVs() )
	for x := X.Front(); x != nil; x = x.Next() {
		newl.PushBack( x.CVs() )
	}
	if Y != nil {
		for y := Y.Front(); y != nil; y = y.Next() {
			newl.PushBack( y.CVs() )
		}
		newl.Root().Value = X.With(Y)
	}
	return newl
}
