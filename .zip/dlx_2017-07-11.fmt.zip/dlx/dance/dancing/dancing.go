// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dancing

import (
	"dlx/list"

	"dlx/dance/beat" // Note: No drum for Push & Pop, as these occur in sync with Call
	"dlx/dance/turn"
)

type Dancing struct {
	Dancing *list.Dancing
	Beating *beat.Dancing
	Turning *turn.Dancing

	Level int
}

func New(vd, vb, vt bool) *Dancing {
	var d = new(Dancing)

	d.Dancing = list.NewDancing()
	d.Beating = beat.NewDancing()
	d.Turning = turn.NewDancing()
	d.Level = 0

	Verbose = VerboseType(vd)
//	list.Verbose = list.VerboseType(vl)	// intentionally list does not have Verbose
	beat.Verbose = beat.VerboseType(vb)
	turn.Verbose = turn.VerboseType(vt)

	return d
}
