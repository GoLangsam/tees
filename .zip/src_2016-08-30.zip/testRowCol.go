﻿package main

import (
	"dlx/star"
	"dlx/list"
	"fmt"
)


// If I want to access by Index
var Cols []*list.List
var Rows []*list.List

func main() {
	fmt.Println("Starting")

	var root = star.NewBang( "Problem World / Board" )	// NewBang - a list of elements which are lists
//	fmt.Println("root")
//	fmt.Println( root )
//	fmt.Sprintf("type %T", root )
	fmt.Printf("%T %[1]v\n", root )
	var rows = root.AddDirt ( "Zeilen", 1, 2, 3, 4, 5, 6, 7, 8 )
	var cols = root.AddDirt ( "Spalten", "A", "B", "C", "D", "E", "F", "G", "H" )
	var stuf = root.AddDust ( "Staub", "Korn", "Korn", "Korn", "noch 'n Korn")

//	fmt.Println("rows")
//	fmt.Println( rows )
	fmt.Printf("%T %[1]v\n", rows )

//	fmt.Println("cols")
//	fmt.Println( cols )
	fmt.Sprintf("cols %T", cols )
	fmt.Printf("%T %[1]v\n", cols )

//	fmt.Println("stuf")
//	fmt.Println( stuf )
//	fmt.Sprintf("stuf %T", stuf )
	fmt.Printf("%T %[1]v\n", stuf )

	var this = root.GetThisValue( cols )
	fmt.Printf("%T %[1]v\n", this )
	fmt.Println("this")
	fmt.Println( this )

	var that = root.GetThatValue( cols )
	fmt.Printf("%T %[1]v\n", that )
	fmt.Println("that")
	fmt.Println( that )

	var axis = root.GetAxis( cols )
	fmt.Printf("%T %[1]v\n", axis )
//	fmt.Println("axis")
//	fmt.Println( axis )
//	for _, elem := range axis { fmt.Println( elem ) }

	var list = root.GetData( cols )
	fmt.Printf("%T %[1]v\n", list )
//	fmt.Println("list")
//	fmt.Println( list )
//	for _, elem := range list { fmt.Println( elem ) }

//	next := root.Root() // this is a function on a list, is it?


/*
	criss := root.PushBack
	fmt.Println("criss")
	fmt.Println( criss )
	fmt.Println( criss("Dimension"))

	cross := rows.Value.(*list.List).PushBack
	fmt.Println("cross")
	fmt.Println( cross )
	fmt.Println( cross("Row"))

	var x, y = star.AddEiksWithData(criss , "a dimension", cross, "a row")	// a new star ?!? but on which axises?

	fmt.Println("X")
	fmt.Println(x)

	fmt.Println("Y")
	fmt.Println(y)

	var x, y = star.AddEiksWithData(cross, "a row")

	len := root.Len()					// Bang has a 'Length"
	fmt.Println(len)

	len = rows.Value.(*list.List).Len()			// Dust has a 'Length"
	fmt.Println(len)

	len = cols.Value.(*list.List).Len()			// Dirt has a 'Length"
	fmt.Println(len)

/*
	var cols = list.New()

	criss := row.PushBack
	fmt.Println(criss("X"))
	cross := Cols[1].PushBack
	fmt.Println(cross("Y"))

	fmt.Println("X")
	fmt.Println(x)

	fmt.Println("Y")
	fmt.Println(y)
*/

/*
	fmt.Println("Rows")
	fmt.Println(Rows)

	fmt.Println("Row 0")
	fmt.Println(Rows[0] )
	fmt.Println("Row 0 Front")
	fmt.Println(Rows[0].Front() )
*/

/*
	var list = Rows[0].Front().Value.(list.List)
	fmt.Println(list.Front() )

	fmt.Println("Row 1")
	fmt.Println(Rows[1].Front() )

	fmt.Println("Cols")
	fmt.Println(Cols)

	fmt.Println("Col 2")
	fmt.Println(Cols[2] )

	row = Cols[1]
	fmt.Println(row.Front() )

	fmt.Println(Cols[0].Front() )

*/

//	e4 := l.PushBack(4)
//	e1 := l.PushFront(1)

//	l.InsertBefore(1, e4)
//	l.InsertBehind(2, e1)
//	l.InsertBelow(3, e4)
//	l.InsertAbove(4, e1)

//	l.BeforeAppend(t.Root, "A", "B", "C")
//	l.BehindAppend(t.Root, "A", "B", "C")
//	l.BelowAppend(t.Root, "A", "B", "C")
//	l.AboveAppend(t.Root, "A", "B", "C")



//	l.BeforeAppend(t.Root, "A", "B", "C")
//	l.BehindAppend(t.Root, "A", "B", "C")
//	l.BelowAppend(t.Root, "A", "B", "C")
//	l.AboveAppend(t.Root, "A", "B", "C")

/*
	// Iterate through list and print its contents.
	for e := l.Front(); e != nil; e = e.Next() {
		fmt.Println(e.Value)
	}
	fmt.Println("Incrementing")
	for e := l.Front(); e != nil; e = e.Next() {
		var c = e.Value.(int)
		c = c + 1
		fmt.Println(c)
	}
	fmt.Println(t)
	fmt.Println(c1)
*/
}
