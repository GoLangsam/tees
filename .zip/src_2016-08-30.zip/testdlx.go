package main

import (
	"dlx"
	"fmt"
)

func main() {
	fmt.Println("Starting")

	t := dlx.NewTorus() // a new Torus
	r := t.Root
	
	c1 := t.InsertBehind(1, r )

//	e4 := l.PushBack(4)
//	e1 := l.PushFront(1)

//	l.InsertBefore(1, e4)
//	l.InsertBehind(2, e1)
//	l.InsertBelow(3, e4)
//	l.InsertAbove(4, e1)

//	l.BeforeAppend(t.Root, "A", "B", "C")
//	l.BehindAppend(t.Root, "A", "B", "C")
//	l.BelowAppend(t.Root, "A", "B", "C")
//	l.AboveAppend(t.Root, "A", "B", "C")



//	l.BeforeAppend(t.Root, "A", "B", "C")
//	l.BehindAppend(t.Root, "A", "B", "C")
//	l.BelowAppend(t.Root, "A", "B", "C")
//	l.AboveAppend(t.Root, "A", "B", "C")

/*
	// Iterate through list and print its contents.
	for e := l.Front(); e != nil; e = e.Next() {
		fmt.Println(e.Value)
	}
	fmt.Println("Incrementing")
	for e := l.Front(); e != nil; e = e.Next() {
		var c = e.Value.(int)
		c = c + 1
		fmt.Println(c)
	}
*/
	fmt.Println(t)
	fmt.Println(c1)
}
