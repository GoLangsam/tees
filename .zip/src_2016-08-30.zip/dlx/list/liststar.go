﻿package list

// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
This file extends the (stolen and) extended list.go
with stuff, which is considered useful and helpfull, such as:

	- e.List()		*List
	- e.RaUp()		*Element
	- e.GetValues()		[]interface {}

	- e.Junk (x *Element)	// cross-links RaUp's

	- NewList( v )	returns a list, the Root() of which carries v as Value

	- l.Root()		*Element
	- l.GetValues()		[]interface {}

	- l.unListExcept(a *List, memo *Element)
	- l.reListExcept(a *List, memo *Element)
	- l.unList(a *List)
	- l.reList(a *List)
	- l.unLink(e *Element)
	- l.reLink(e *Element)

*/

// ===========================================================================
// func (e *Element) ...

// List returns the list this element belongs to
func (e *Element) List() *List {
	return e.list
}

// RaUp returns the raup element (an element of the orthogonal fiber-list)
func (e *Element) RaUp() *Element {
	return e.raup
}

func (e *Element) GetValues() []interface {} {
	return e.List().GetValues()

}


/* Is this needed by the outer world?
// SetRaUp sets the raup (an element of the orthogonal fiber-list)
// If e == mark or e and mark are element of the same list, the element is not modified.
// NOTE: only any new List's list-Element points to itself!
func (e *Element) SetRaUp(raup *Element) {
	if e == raup || e.list == raup.list {
		return
	}
	e.raup = raup
}
*/

// Junk is a Link as a Junc-tion of the elements
// Who needs such garbage? ;-)
func (e *Element) Junk (x *Element) {
	if e.raup != nil {panic("raup in e already set!")}
	if x.raup != nil {panic("raup in x already set!")}
	x.raup = e
	e.raup = x
}

// ===========================================================================
// func (l *List) ...

// NewList( v ) returns a list, the Root() of which carries v, (and is RaUp to nil)
func NewList ( v interface{} ) *List {
	var beam = New()
	beam.Root().Value = v
	return beam
}

// Root returns the root element of list l
func (l *List) Root() *Element {
	return &l.root
}

func (l *List) GetValues() []interface{} {
	var data = make( []interface{}, 0, l.Len() )
	for e := l.Front(); e != nil; e = e.Next() {
		data = append( data, e.Value )
	}
	return data
}


// NOTE: Bullshit: we must not start walking from root, we must xxLink root from it's orthogonal list!!!
// NOTE: We must look at what l a and root.orthogonal lists are:
//       a != e
//       a == memo.list
//       l == root.raup's list ?!?
func (l *List) unListExcept(a *List, memo *Element) {
	for e := a.Root(); e != nil; e = e.Next() {
		if e != memo {
			l.unLink(e)
		}
	}
}

func (l *List) reListExcept(a *List, memo *Element) {
	for e := a.Root(); e != nil; e = e.Next() {
		if e != memo {
			l.reLink(e)
		}
	}
}

// could also be done by calling l.ccListExcept(a, nil)
func (l *List) unList(a *List) {
	for e := a.Root(); e != nil; e = e.Next() {
		l.unLink(e)
	}
}

func (l *List) reList(a *List) {
	for e := a.Root(); e != nil; e = e.Prev() {
		l.reLink(e)
	}
}


func (l *List) unLink(e *Element) {
	if e.list != l {panic("not a member!")}
	e.prev.next = e.next
	e.next.prev = e.prev
	e.list.len--
}

func (l *List) reLink(e *Element) {
	if e.list != l {panic("not a member!")}
	e.list.len++
	e.prev.next = e
	e.next.prev = e
}
