package dlx

var stack []*Point

// push Point
func push(v *Point) {
	stack = append(stack, v)
}

// top of stack
func top() *Point {
	return stack[len(stack)-1]
}

// pop Point
func pop() *Point {
	p := top()
	stack = stack[:len(stack)-1]
	return p
}

/*
func (s stack) len() int {
	return len(s)
}
*/