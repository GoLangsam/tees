package dlx

// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// axis is a double-link in some dimension among points on a torus.
type axis struct {
	prev *Point
	next *Point
	head *Point
	len int
}

// Init initializes or clears axis x
func (x *axis) Init(head *Point) *axis {
	x.prev = head
	x.next = head
	x.head = head
	x.len = 0
	return x
}

// New returns an initialized axis
func (p *Point) newAxis() *axis { return new(axis).Init(p) }

// lazyInit lazily initializes a zero axis value.
func (x *axis) lazyInit( here *Point ) {
	if x.head == nil {
		x = here.newAxis()
	}
}

func (p *Point) InsertBetween (to Fold, behind, before *Point) *axis {

	if behind.link[to].head != before.link[to].head {panic( "Not same fiber!" ) }

	p.link[to].lazyInit( p )

	before.link[to].prev = p
	behind.link[to].next = p

	p.link[to].prev = before
	p.link[to].next = behind

	p.link[to].head = behind.link[to].head

	p.link[to].len++

	return &p.link[to]	
}
