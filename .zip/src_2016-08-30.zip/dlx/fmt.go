package dlx

import "fmt"

// Println for easy access
func Println(a ...interface{}) (n int, err error) {
	return fmt.Println(a)
}
