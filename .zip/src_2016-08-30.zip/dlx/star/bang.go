﻿package star

// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
Here is stuff, which is considered useful and helpfull
when dealing with some Big Bang, such as:

	- big.GetThisValue(tiny *Star)		interface{}
	- big.GetThatValue(tiny *Star)		interface{}

	- big.GetAxis(tiny *Star)		[]interface{}	/ from cris / This
	- big.GetData(tiny *Star)		[]interface{}	/ from cros / That

*/

/*
func IsBigBang ( bing *Star ) boolean {
	if e.prev == e.
}
func IsDust ( bing *Star ) boolean {
	if e.prev == e.
}
*/
func (big *Bang) GetThisValue(tiny *Star) interface{} {
	return tiny.cris.Value
}

func (big *Bang) GetThatValue(tiny *Star) interface{} {
	return tiny.cros.Value
}

func (big *Bang) GetAxis(tiny *Star) []interface{} {

	var list = tiny.cris.List()	// we use cris here, not cros
	return list.GetValues()
}

func (big *Bang) GetData(tiny *Star) []interface{} {

	var list = tiny.cros.List()	// we use cros here, not cris
	return list.GetValues()
}