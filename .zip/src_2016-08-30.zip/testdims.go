package main

import (
	"dlx"
	"fmt"
)

// axis is a double-link in some dimension among points on a torus.
type axis struct {
	prev *Point
	next *Point
	head *Point
	len int
}


// Point is an element of a torus.
type Point struct {
	link [dlx.DIMS] axis

	// Value stored with this element.
	Value interface{}
}

func (p *Point) show(n dlx.Fold) int {
	return p.link[n].len
} 

// add first arg: "N Fold, "
// ".hori" => .link[HORI]
// ".vert" => .link[VERT]


func main() {
	fmt.Println("Starting")

	fmt.Println(dlx.DIMS)

	var p = new (Point)
	var q = new (Point)
	var r = new (Point)
	
	p.link[dlx.HORI].next = q
	p.link[dlx.HORI].prev = r
	p.link[dlx.HORI].head = p

	p.link[dlx.VERT].next = q
	p.link[dlx.VERT].prev = r
	p.link[dlx.VERT].head = p


	fmt.Println(p)

	fmt.Println(p.show(dlx.HORI))

}