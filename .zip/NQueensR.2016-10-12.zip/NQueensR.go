﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//package dance_test
package main

import (
	"dlx/dance/dancing"
	"dlx/dance/dancing/chooser"

	"dlx/list/test"

	"flag"
	"fmt"
	"time"
)

// ========================================================

var	C		chooser.Chooser = chooser.ChooseShort	// default

var (
	beg   = flag.Int("Beg",  1, "Begin with Boardsize (min=1, max=End)")
	end   = flag.Int("End", 12, "End with Boardsize (min=1)")

	fast  = flag.Bool("Fast", false, "Use DanceFast")
	slow  = flag.Bool("Slow", false, "Use DanceSlow")

	beats = flag.Bool("b",   false, "Beats: Print counters per Level (sets -d)")
	drums = flag.Bool("d",   false, "Drums: Print counters (sets -r)")
	rhyth = flag.Bool("r",   false, "Rhythm: Collect counters")
	goals = flag.Bool("s",   false, "Print solutions")
	times = flag.Bool("t",   true , "Print times")
	choos = flag.Bool("u",   false, "Verbose Chooser: Print all choices made")
	verbs = flag.Bool("v" ,  false, "Verbose Dancer: Prints a lot of details")
	tests = flag.Bool("x",   false, "Execute Chooser-test")

//	s = flag.String("s", " ", "separator")
)

func flagParse() {
	flag.Parse()
	if *beats { *drums = true }
	if *drums { *rhyth = true }

	if *beg < 1    { *beg = 1 }
	if *end < 1    { *end = 1 }
	if *beg > *end { *beg = *end }

	if *slow && *fast {panic("Either or: -Slow, or -Fast")}
}

// ========================================================

func NQueensR( anz int ) {

	var dancing = dancing.New(*verbs, *goals, *rhyth, *drums, *beats, *choos)

	dancing.Chooser = C	// only needed for Choose-tests!

	var cols = test.NQueensR( anz )

	var t time.Time
	if *times { t = time.Now()}

	var       dance = func(){ dancing.Dance(cols) }
	if *slow {dance = func(){ dancing.DanceSlow(cols) }}
	if *fast {dance = func(){ dancing.DanceFast(cols) }}

	dancing.Dancing.Dance = dance
	dancing.Dancing.Dance()

	dancing.Print()
	if *times { fmt.Println("Time =", time.Since(t) ) }
}

// ========================================================

func NQueensRChooserTest(beg, end int) {
	for i := beg; i <= end; i++ {
		fmt.Println()
		fmt.Println( "Queens on a", i, "*", i, "Board" )
		ChooserTest( i )
	}
}
func ChooserTest(anz int) {
	for i, c := range chooser.GetChoosers() {
		C = c
		fmt.Println("Chooser No", i+1, "=", chooser.ChooserName(i) )
		NQueensR( anz )
	}
}


func ChooserNQueensRTest(beg, end int) {
	for i, c := range chooser.GetChoosers() {
		C = c
		fmt.Println()
		fmt.Println("Chooser No", i+1, "=", chooser.ChooserName(i) )
		NQueensRTest( beg, end )
	}
}
func NQueensRTest(beg, end int) {
	for i := beg; i <= end; i++ {
		fmt.Println( "Queens on a", i, "*", i, "Board" )
		NQueensR( i )
	}
}


// ========================================================

// func ExampleTestChoosers(t *testing.T) {
func main() {
	flagParse()

	if *tests {
		if *beg == *end {
			NQueensRChooserTest(*beg, *end)
		} else {
			ChooserNQueensRTest(*beg, *end)
		}
	} else {
		if *beg == *end {
			fmt.Println()
			fmt.Println( "Queens on a", *beg, "*", *beg, "Board" )
			NQueensR(*beg)
		} else {
			fmt.Println()
			NQueensRTest(*beg, *end)
		}
	}
}

// ========================================================
