﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dance_test

import (
	"dlx/dance"
	"dlx/dance/chooser"
	"dlx/dance/dancer"

	"dlx/list"

	"fmt"
)


func ExampleDanceFast() {
	fmt.Println("Starting")

	// Create a new list and put some beams in it.
	var cols = list.NewList( "Cols" )
	var C1 = cols.AddBeam( "A" )
	var C2 = cols.AddBeam( "B" )
	var C3 = cols.AddBeam( "C" )
	var C4 = cols.AddBeam( "D" )
	var C5 = cols.AddBeam( "E" )
	var C6 = cols.AddBeam( "F" )
	var C7 = cols.AddBeam( "G" )

/*
	A B C D E F G

	0 0 1 0 1 1 0
	1 0 0 1 0 0 1
	0 1 1 0 0 1 0
	1 0 0 1 0 0 0
	0 1 0 0 0 0 1
	0 0 0 1 1 0 1

*/

	var rows = list.NewList( "Rows" )
	rows.Root().Junk( cols.Root() )

//	fmt.Println( "Rows in disorder, with Elements in disorder!!!" )
	rows = list.NewList( "Dis-Disorderd Rows" )
	rows.AddOnes( "R-4", C1, C4 )
	rows.AddOnes( "R-5", C7, C2 )
	rows.AddOnes( "R-1", C6, C3, C5 )
	rows.AddOnes( "R-2", C7, C4, C1 )
	rows.AddOnes( "R-3", C6, C2, C3 )
	rows.AddOnes( "R-6", C7, C5, C4 )

	d := dancer.New()
	d.Chooser = chooser.ChooseShort
	d.CallBack = func(){ dance.DanceFast(cols, d) }
	dance.DanceFast(cols, d)
//	fmt.Println(d.Levelcount )

	// Output:
	// Starting
	// Solution: 3
	// R-4: A D .
	// R-1: F C E .
	// R-5: G B .
}
