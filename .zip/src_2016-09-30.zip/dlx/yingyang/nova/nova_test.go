﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package nova_test

import (
	"dlx/list"

	"dlx/trix/anda"
	"dlx/trix/anda/aton"
	"dlx/trix/anda/apep"

	"dlx/yingyang/nova"
//	"dlx/yingyang/spot"
)

func test(n nova.Nova) {}

func ExampleNova() {
	var list = list.NewList( "Test", 1, "2", "drei", false)
	test(list)
	var anda = anda.New( "Test", 1, "2", "drei", false)
	test(anda)
	var aton = aton.New( "Test", 1, "2", "drei", false)
	test(aton)
	var apep = apep.New( "Test", 1, "2", "drei", false)
	test(apep)
}