﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package nova

import (
	"dlx/list"
	"dlx/yingyang/spot"
)

// Nova is a spot which can create new elements
// Nova abstracts the common behaviour of *list.List & *anda.Anda, Aton, Apep ...
type Nova interface {
	spot.Spot	// Nova extends "dlx/yingyang/spot"

//	Front()					*list.Element
//	Back()					*list.Element
//	Root()					*list.Element

	Len()					int
	PushFront( interface{} )		*list.Element
	PushBack( interface{} )			*list.Element

	ValuesPushFront( ...interface{})
	ValuesPushBack( ...interface{})
}

