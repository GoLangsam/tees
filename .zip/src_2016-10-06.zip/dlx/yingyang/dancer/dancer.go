﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
stacking.go implements the callback-interfaces for list.Dancer & Tryer
(and further access to d.Stacker).
For performance reasons, calls on these functions is intentionally not monitored here.
See package dance
*/
package dancer

import (
	"dlx/list"
)

type Dance interface {
	Dancing
	Stacker
	Scorer
	Drummer
}

type Dancing interface {
	Dancing(*list.List) (*list.List, bool)
}

type Stacker interface {
	ForDancer
	ForTryer
	ForStack
}
type ForDancer interface {
	Dance()
	Fold(*list.List )
	Open() *list.List
}
type ForTryer interface {
	Try()
	Ask( *list.List ) bool
	Get() *list.List
}
type ForStack interface {
	Top() *list.List
	Len() int
	Solution() []*list.List
}

type Scorer interface {
	OnGoal([]*list.List)
}

type Drummer interface {
	OnLeaf( *list.Element )
	OnCall( *list.List )
	OnDead()
}
