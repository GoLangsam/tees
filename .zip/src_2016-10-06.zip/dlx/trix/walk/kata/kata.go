﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
kata (Japanese) is a form of movement (in martial arts)

	- New(v, vals...)

*/
package kata

import (
	"dlx/list"
	"dlx/trix/walk"
)

// Kata (Japanese) is a form of movement (in martial arts)
type Kata	struct{
	*list.List
}

// New returns an initialized kata.
func New(v interface{}, vals ...interface{}) *Kata {
	var atom = new(Kata)
	atom.List = list.NewList( v, vals... )
	return atom
}

func getGoTo(e *list.Element) walk.GoTo {
	if e == nil {return nil}
	return e.Value.(walk.GoTo)
}

func (steps Kata) from(e *list.Element) *list.Element {
	var curr = e
	for step := steps.Front(); step != nil; step = step.Next() {
		jump := getGoTo(step)
		if jump != nil && curr != nil {
			curr = jump( curr )
		}
	}
	return curr
}

// From returns an iterator for a Kata
func (steps Kata) From(e *list.Element) walk.Walk {
	var seen = make(map[*list.Element]bool)
	var curr = e
	var kata = steps

	var move walk.Walk = func() *list.Element {
		seen[curr] = true
		curr = kata.from(curr)
		if seen[curr] { return nil } // already seen
		return curr
	}
	return move
}

// Grab returns an iterator for a Kata
func (steps Kata) Grab(e *list.Element) walk.Walk {
	var seen = make(map[*list.Element]bool)
	var curr = e
	var kata = steps
	var goTo = kata.Front()
	var jump = getGoTo(goTo)

	var move walk.Walk = func() *list.Element {
		if jump == nil { return nil }
		seen[curr] = true
		curr = jump( curr )
		if seen[curr] { return nil } // already seen
		goTo = goTo.Next()
		jump = getGoTo(goTo)
		return curr
	}
	return move
}


// Walker returns an iterator repeating Kata.From(e) ...
func (steps Kata) Walker(e *list.Element) walk.Walk {
	var seen = make(map[*list.Element]bool)
	var curr = e
	var kata = steps

	var goTo = kata.Front()
	var jump = getGoTo(goTo)

	var move walk.Walk = func() *list.Element {
		seen[curr] = true
retry:		if jump == nil { return nil }
		curr = jump( curr )
		if curr == nil || seen[curr] { // at end, or already seen
			goTo = goTo.Next()
			jump = getGoTo(goTo)
			goto retry
		}
		return curr
	}
	return move
}

func (steps Kata) PrintGraber( from *list.Element ) {
	steps.PrintValue()
	steps.Grab(from).Print( from )
}

func (steps Kata) PrintWalker( from *list.Element ) {
	steps.PrintValue()
	steps.Walker(from).Print( from )
}
