﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// package flag provides a list-of-lists
package flag

import (
	"dlx/list"
	"dlx/trix/math"
)

type Flag struct {*list.List}

func New() Flag {
	var flag = new(Flag)
	flag.List = list.New()
	return *flag
}

// Init initializes or clears list l.
func (flag Flag) Init() Flag {
	flag.List.Init()
	return flag
}

// NewFlag( v, vals ) returns a list, the Root() of which carries v, (and is Away to nil)
func NewFlag ( v interface{}, vals ...interface{} ) Flag {
	var flag = new(Flag)
	flag.List = list.NewList(v, vals...)
	return *flag
}

// Junk links another flags Root() as a mutual Junc-tion of their Away's
func (l Flag) Junk (x Flag) {
	l.List.Junk( x.List )
}

// With returns a new *ComposedValue to be used for new Elements
func(flag Flag) With( list Flag ) *list.ComposedValue {
	return flag.List.With( list.List )
}

// ===========================================================================
// AddBeam returns a new list with root-value v and new elements with values dots,
// the root of which is Junk'ed to a new PushBack-Element (with same value v) of flag
func (flag Flag) AddBeam ( v interface{}, vals ...interface{} ) Flag {

	var list = list.NewList( v )
	list.ValuesPushBack( vals... )
	flag.AddList( list )
	return flag
}

// AddRays Add's lists to flag and returns flag
func (flag Flag) AddRays ( lists ...*list.List ) Flag {
	for _, list := range lists {
		flag.AddList( list )
	}
	return flag
}

// AddFlag adds a new element with value v to flag
// Junk'es it with the flag's root
// and returns the new flag (not flag) - useful for calculated lists
func (flag Flag) AddFlag ( list Flag ) Flag {

	var head = flag.List.PushBack( flag.With(list) )
	head.Junk( list.List.Root() )

	return list
}

// AddList adds a new element with value v to flag
// Junk'es it with the list's root
// and returns the new list (not flag) - useful for calculated lists
func (flag Flag) AddList ( list *list.List ) *list.List {

	var head = flag.List.PushBack( flag.List.With(list) )
	head.Junk( list.Root() )

	return list
}

// ===========================================================================
// AddJunk adds Junk'ed pairs of new elements to flag across respective flags
// The new elements carry pointers to both Roots() as Values.
// Thus, they carry their coordinates, so to say.
func (flag Flag) AddJunk ( v interface{}, lists ...Flag) Flag {

	var list = NewFlag( v )

	for _, head := range lists {
		var vert = head.PushBack( head.With(list) )
		var hori = list.PushBack( list.With(head) )
		vert.Junk( hori )
	}
	flag.AddFlag( list )
	return flag
}

// AddOnes adds Junk'ed pairs of new elements to list l across respective lists
// The new elements carry no Values. They are light, so to say.
func (flag Flag) AddOnes ( v interface{}, lists ...Flag) Flag {

	var list = NewFlag( v )

	for _, head := range lists {
		vert := head.PushBack( nil )
		hori := list.PushBack( nil )
		vert.Junk( hori )
	}
	flag.AddFlag( list )
	return flag
}

// ===========================================================================
func (flag Flag) AddAppend (f Flag, flags ...Flag ) *list.List {
	return flag.AddList( Append(f, flags...) )
}

func (flag Flag) AddTimes (f Flag, flags ...Flag ) *list.List {
	return flag.AddList( Times(f, flags...) )
}

// ===========================================================================

func Append (flag Flag, flags ...Flag ) *list.List {
	lists := make([]*list.List,0,len(flags) )
	for _, f := range flags {
		lists = append(lists, f.List )
	}
	return math.Append( flag.List, lists... )
}

func Times (flag Flag, flags ...Flag ) *list.List {
	lists := make([]*list.List,0,len(flags) )
	for _, f := range flags {
		lists = append(lists, f.List )
	}
	return math.Times( flag.List, lists... )
}

// Xross returns a new flag: the cross product of X with Y
// the returned list is a handle to the X-Dimension
// the elements are Junk'ed
// such Xross may be explored by Step Jump Walk Tour ...
func Xross ( X, Y Flag ) Flag {

	cols := make([]Flag,0,X.Len() )

	var xl = NewFlag( X.CVs )
	for x := X.List.Front(); x != nil; x = x.Next() {
		cols = append( cols, xl.AddBeam( x.CVs() ) )
	}

	var yl = NewFlag( Y.CVs )
	for y := Y.List.Front(); y != nil; y = y.Next() {
		yl.AddJunk( y.CVs(), cols... )		// use AddOnes to keep elements light (Value = <nil>)
	}
	xl.Junk( yl )

	return xl
}
