﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package drummer

import (
	"dlx/dance/beater"
)

type Drummer struct {
	Niveaus *beater.Beater		// Niveaus counts dances per Level
	UpDates *beater.Beater		// UpDates counts unLink per Level
	Grooves *beater.Beater		// Grooves counts solutions per length
	Deadend *beater.Beater		// Deadend counts dead ends per Level
}

func New(cap int) *Drummer {
	var d = new(Drummer)
	d = d.Init(cap)
	return d
}

func (d *Drummer) Init(cap int) *Drummer {
	d.Niveaus = beater.NewDrum("Niveaus", cap)
	d.UpDates = beater.NewDrum("UpDates", cap)
	d.Grooves = beater.NewDrum("Grooves", cap)
	d.Deadend = beater.NewDrum("Deadend", cap)
	return d
}

func (d *Drummer) Print() {
	if Verbose {
		d.Niveaus.Print()
		d.UpDates.Print()
		d.Grooves.Print()
		d.Deadend.Print()
	}
}
