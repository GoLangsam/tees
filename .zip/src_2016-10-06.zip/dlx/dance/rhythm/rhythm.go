﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package rhythm

import (
	"dlx/dance/drummer"

	"dlx/yingyang/call"
	"dlx/yingyang/spot"
	"dlx/yingyang/stack"
)

type Rhythm struct {
	stack.AnyDanceStack
	*drummer.Drummer
}

func New(stack stack.AnyDanceStack, drums *drummer.Drummer) Rhythm {
	return Rhythm{stack, drums}
}

func (r Rhythm)OnGoal() call.Callback     {	return func()			{        r.Grooves.Beat(r.Len())}	}
func (r Rhythm)OnDead() call.Callback     {	return func()			{        r.Deadend.Beat(r.Len())}	}
func (r Rhythm)OnCall() call.CallWithSpot {	return func(spot.Spot)		{        r.Niveaus.Beat(r.Len())}	}
func (r Rhythm)OnLeaf() call.CallWithSpot {	return func(spot.Spot)		{        r.UpDates.Beat(r.Len())}	}
func (r Rhythm)OnPush() call.CallWithSpot {	return func(l spot.Spot)	{        r.Push(l)		}	}
func (r Rhythm)OnPop () call.CallForAny  {	return func() interface{}	{ return r.Pop()		}	}
