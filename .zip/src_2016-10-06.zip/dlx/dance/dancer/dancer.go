﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go defines a dancer and a tryer
*/
package dancer

import (
	"dlx/list"

	"dlx/yingyang/call"
	"dlx/yingyang/spot"
)

type Rhythm interface {
	OnCall() call.CallWithSpot
	OnLeaf() call.CallWithSpot
	OnPush() call.CallWithSpot
	OnPop()  call.CallForAny
}

type Dancer struct {

	CallBack   call.Callback

	CallOnCall call.CallWithSpot
	CallOnLeaf call.CallWithSpot

	CallOnPush call.CallWithSpot
	CallOnPop  call.CallForAny
}

func New() *Dancer {			// cannot pass CallBack upon New, as it is a method of himself
	return new( Dancer ).Init()
}

func (d *Dancer) Init() *Dancer {
	d.CallBack   = call.NoOp

	d.CallOnCall = call.NoOpWithSpot
	d.CallOnLeaf = call.NoOpWithSpot

	d.CallOnPush = call.NoOpWithSpot
	d.CallOnPop  = call.NoOpForAny

	return d
}

func (d *Dancer) SetDrumming(R Rhythm) *Dancer {
	d.CallOnCall = R.OnCall()
	d.CallOnLeaf = R.OnLeaf()

	d.CallOnPush = R.OnPush()
	d.CallOnPop  = R.OnPop()

	return d
}

// ========================================================
// Drumming

// OnCall (for danceslow)
func (d *Dancer) OnCall( l spot.Spot ) {	d.CallOnCall(l) }
// OnLeaf (for extended interface list.Dancer & list.Tryer)
func (d *Dancer) OnLeaf( e *list.Element ) {	d.CallOnLeaf(e)	}

// ========================================================
// Stacking

// Dance (for interface list.Dancer) is a callback
func (d *Dancer) Dance() {			d.CallBack()	}
// Try (for interface list.Tryer) is a callback
func (d *Dancer) Try() {			d.CallBack()	}

// Fold (for interface list.Dancer) is a Push of the current stack
func (d *Dancer) Fold( l *list.List ){		d.CallOnPush(l)	}

// Ask (for interface list.Tryer) is a Push of the current stack
// and determination, if list is acceptable
func (d *Dancer) Ask( l *list.List ) bool {	d.CallOnPush(l)
						return true	// Note: If e.g. resources are consumed, l may not qualify for a (temporary) solution
}

// Open (for interface list.Dancer) is a Pop of the current stack
func (d *Dancer) Open() *list.List {		return d.CallOnPop().(*list.List)	}
// Get (for interface list.Tryer) is a Pop of the current stack
func (d *Dancer) Get()  *list.List {		return d.CallOnPop().(*list.List)	}
