﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
chooser.go defines some Chooser's = functions to choose sth for a dancer to dance on

*/
package chooser

import (
	"dlx/yingyang/spot"
)


// ========================================================

// GetChoosers returns all choosers defined in this package as a slice,
// which can be useful in benchmarking comparsions
func GetChoosers() []Chooser {
	var c = make([]Chooser, 0, 5)
	c = append(c, ChooseUpto3)
	c = append(c, ChooseUpto2)
	c = append(c, ChooseShortNonEmpty)
	c = append(c, ChooseShort)
	c = append(c, ChooseFront)
	return c
}

// ========================================================

type Chooser func(spot.Spot) (spot.Spot, bool)

// ChooseFront simply returns the first column
func ChooseFront (l spot.Spot) (spot.Spot, bool) {

	if l == nil { panic( "List to choose from is nil!") }
	if Verbose {	l.PrintAways("Choosing from: ")	}

	e := l.Front()
	if e == nil { return nil, false }
	e = e.Away()
	if e == nil { return nil, false }

	awaylist := e.List()
	if awaylist == nil { return nil, false }
	if Verbose { awaylist.PrintAways("Chosen: ") }
	return awaylist, awaylist.Len() > 0
}

// ========================================================

// ChooseShort returns the smallest column
func ChooseShort (l spot.Spot) (spot.Spot, bool) {
	return ChooseUpto(l, 0)
}

// ChooseShortNonEmpty returns the smallest non-empty column
func ChooseShortNonEmpty (l spot.Spot) (spot.Spot, bool) {
	return ChooseUpto(l, 1)
}

// ChooseUpto2 returns the smallest non-empty column
func ChooseUpto2 (l spot.Spot) (spot.Spot, bool) {
	return ChooseUpto(l, 2)
}

// ChooseUpto3 returns the smallest non-empty column
func ChooseUpto3 (l spot.Spot) (spot.Spot, bool) {
	return ChooseUpto(l, 3)
}

// ========================================================

// ChooseBelow returns the first non-empty column not longer than min
func ChooseUpto (l spot.Spot, min int) (spot.Spot, bool) {
	var found bool = false
	var c spot.Spot
	s := 999999999
	for j := l.Front(); j != nil; j = j.Next()	{
		list := j.Away().List()
		if list != nil {
			leng := list.Len()
			if leng < s {
				c = list
				s = leng
				found = true
				if s <= min {
					break
				}

			}
		}
	}
	if Verbose { c.PrintValue("Chosen: ") }
	return c, found
}

// ========================================================

// TODO: ChooseOrgan also considers the total length of the aways (=rows) - the higher the better

/*
	currlist curraway
	looklist lookaway

	d := looklist - currlist
	a := lookaway - curraway

	if a > d * weight { curr = look }

	switch d {
		d < 0: if a < 0 {if a < d	{ curr = look } }	// look is shorter; but should not have much less aways (not a>=0 or
		d = 0: if a > 0			{ curr = look }		// look has same len; look has more aways
		d > 0: if a > d * weight	{ curr = look }		// look is longer; look has weight more aways

	}


	if looklist <= currlist

	> currlist + curraway

*/
