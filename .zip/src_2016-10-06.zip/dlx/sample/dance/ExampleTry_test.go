﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dance_test

import (
	"dlx/sample/dance"
	"dlx/sample/dance/dancer"

	"dlx/dance/chooser"

	"dlx/dance/test"
)


func ExampleTry() {

	var dancing = test.SmallMatrix()

	var dancer = dancer.New()
	_ = chooser.ChooseShort // dancer.Chooser = chooser.ChooseShort
	dancer.CallBack = func(){ dance.Try(dancing, dancer) }
	dancer.CallBack()

	// Output:
	// Solution: 3
	// R-4: A D .
	// R-1: F C E .
	// R-5: G B .
}
