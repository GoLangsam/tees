﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
stacking.go implements the callback-interfaces for list.Dancer & Tryer
(and further access to d.Stacker).
For performance reasons, calls on these functions is intentionally not monitored here.
See package dance
*/
package dancer

import (
	"dlx/list"
)

// ========================================================

// Dance (for interface list.Dancer) is a callback
func (d *Dancer) Dance() {
	d.CallBack()
}
// Try (for interface list.Tryer) is a callback
func (d *Dancer) Try() {
	d.CallBack()
}

// Fold (for interface list.Dancer) is a Push of the current stack
func (d *Dancer) Fold( l *list.List ){
	d.Stacker.Push(l)
}
// Ask (for interface list.Tryer) is a Push of the current stack
// and determination, if list is acceptable
func (d *Dancer) Ask( l *list.List ) bool {
	d.Stacker.Push(l)
	return true	// Note: If e.g. resources are consumed, l may not qualify for a (temporary) solution
}

// Open (for interface list.Dancer) is a Pop of the current stack
func (d *Dancer) Open() *list.List {
	return d.Stacker.Pop()
}
// Get (for interface list.Tryer) is a Pop of the current stack
func (d *Dancer) Get() *list.List {
	return d.Stacker.Pop()
}

// ========================================================

// Top returns the top of the current stack
func (d *Dancer) Top() *list.List {
	return d.Stacker.Top()
}
// Len returns the length of the current stack
func (d *Dancer) Len() int {
	return d.Stacker.Len()
}
// Solution returns a copy of the current stack
func (d *Dancer) Solution() []*list.List {
	return d.Stacker.Get()
}
