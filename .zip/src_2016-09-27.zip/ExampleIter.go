﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main
// package list_test

import (
	"dlx/list"
	"dlx/list/iter"
	"fmt"
)

//func ExampleIter() {


func main() {
	// Create a new list
	var chess = list.NewList( "Chess" )

	// Create new lists
	var rows = chess.AddBeam( "Zeilen", 1, 2, 3, 4, 5 )
	var cols = chess.AddBeam( "Spalten", "A", "B", "C", "D", "E" )
	var board = chess.Xross( cols, rows )
	s := board.Front().Away().List().Front()	// A|1
	m := s.Next().Away().Next().Away()		// B|2
	e := board.Back().Away().List().Back()		// E|5
	if s.IsRoot() || m.IsRoot() || e.IsRoot() {}

//	kata := Kata{ list.NewList( "Kata", JumpNext ) }.Walker( m )
//	walk := kata.Walker( m )
	var kata = iter.NewKata( "Goto Next", iter.Next )
	next := kata.Walker(m)
	m.PrintValue()
	for x := next(); x != nil; x = next() {
		x.PrintValue(" ->")
	}
	fmt.Println()
}
