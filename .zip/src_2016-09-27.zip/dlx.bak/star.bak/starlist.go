﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package star

import (
	"dlx/list"
)

/*
This file connects stars with the (stolen and extended ) package list
with stuff, which is considered useful and helpfull, such as:

	- Bang	struct (currently: bang *List)
	- Star	struct (pair [cris,cros] of *Element)

	- star	make a new star		from two *Element
	- bang	make a new bang		currently: *List
	- NewBang ( v interface{} ) *Bang	// not used yet, see bang()


	- big.Junk( bing, bong *list.Element ) *Star	//

	- TODO: Clarify, what else we need :-)
	- TODO: Add:
	- IsValid (RaUp's link mutually)

	- e.IsListRoot() => list/liststar.go


*/

/*
type Beam struct {		// a Beam is a disguised list
	beam *list.List
}

type Spot struct {		// a Spot is a disguised list element
	spot *list.Element
}
*/


type Bang struct {		// a Bang bang's to a Beam (list)
	bang *list.List		// => Beam
}

type Star struct {		// a Star is a cris/cros-pair of RaUp-Junk-Spots
	cris *list.Element	// => Spot
	cros *list.Element	// => Spot
}

func star (x *list.Element, y *list.Element) *Star {

	var spot = new( Star )

	spot.cris = x
	spot.cros = y

	spot.cris.Junk( spot.cros ) // now, the are mutually connected

	return spot
}

// NOTE: not useful yet! dirty, as tester can access the list directly
func bang ( v interface{} ) *list.Element {

	var bing = new( Bang )

	bing.bang = list.NewList( v )

	var bong = bing.bang.Root()

	return bong
}

func NewBang ( v interface{} ) *Bang {
	var bang = new(Bang)
	bang.bang = list.NewList( v )
	return bang
}

func (big *Bang) Junk ( bing, bong *list.Element ) *Star {
	return star( bing, bong )
}


//
// big.Anti() will create an opposite Bang, and cross it with big
// returning a FlipFlopWorld (a star of big and Anti-big)?
//   where Dust can be added to existing AntiDust orthogonally
//
