﻿// Copyright 2013 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main

// package list_test

import (
	"dlx/list"
)

//func ExampleDance() {
func main() {
	// Create a new list
	var chess = list.NewList( "Chess" )

	var rows = chess.AddBeam( "Zeilen", 1, 2, 3, 4, 5, 6, 7, 8 )
	var cols = chess.AddBeam( "Spalten", "A", "B", "C", "D", "E", "F", "G", "H" )
// So far, we have 2 * 8 Atom's - and that's all we need.
// All else is going to be built from these atoms

	chess.Print( "Starting" )
	chess.PrintAtomValues( "chess" )
	chess.PrintAways()

	chess.AddList( rows.Times( cols ) )
	chess.Print( "Growing" )
	chess.PrintAtomValues()
	chess.PrintAways()

// Note: now we use 'illegal' constructors, omitting the "chess.AddBeam( v, eVs... )"

	l := rows.Append()
	l.Print( "rows.Append()" )
//	l.PrintValues()
//	l.PrintAtomValues()

	l = rows.Append( cols )
	l.Print( "rows.Append( cols )" )
//	l.PrintValues()
//	l.PrintAtomValues()

	l = rows.Times()
	l.Print( "rows.Times()" )
//	l.PrintValues()
//	l.PrintAtomValues()

	l = rows.Times( cols )
	l.Print( "rows.Times( cols )" )
//	l.PrintValues()
//	l.PrintAtomValues()

	l = cols.Times( rows )
	l.Print( "rows.Times( cols )" )
//	l.PrintValues()
//	l.PrintAtomValues()

	l = chess.Xross( cols, rows )
	l.Print( ".Xross( cols, rows )" )
//	l.PrintValues()
	l.PrintAtomValues()
/*
*/
/*
	board := chess.Xross( rows, cols )
	board.Print( ".Xross( rows, cols )" )
//	board.PrintValues()
//	board.PrintAtomValues()
	board.PrintAways()
	board.Away().List().PrintAways()
	board.Away().List().PrintAtomValues( "l.Away().List()")
*/
}
