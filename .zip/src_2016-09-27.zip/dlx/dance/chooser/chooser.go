﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
chooser.go defines some Chooser's = functions to choose sth for a dancer to dance on

*/
package chooser

import (
	"dlx/list"
)
// ========================================================
/*
To choose a column object c, we could simply set
c =: root.Next().Away().List(); this is the leftmost uncovered column.
Or if we want to minimize the branching factor, we could
*/
func ChooseFront (l *list.List) *list.List {
	return l.Front().Away().List()
}

// ========================================================
/*
To choose a column object c, we could simply set
c =: root.Next().Away().List(); this is the leftmost uncovered column.
Or if we want to minimize the branching factor, we could
*/
func ChooseShort (l *list.List) *list.List {
	var c = list.NewList( nil )
	s := 999999999
	for j := l.Front(); j != nil; j = j.Next()	{
		list := j.Away().List()
		leng := list.Len()
		if leng < s {
			c = list
			s = leng
		}
	}
	return c
}
