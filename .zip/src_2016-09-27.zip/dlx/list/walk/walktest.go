﻿// Copyright 2013 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package walk

// package list_test

import (
	"dlx/list"
	"fmt"
)

func (walk Kata) PrintFullWalk ( e *list.Element ) {
	fmt.Print("From: ")
	from, d := walk.From( e )
	e.PrintValue(); fmt.Print("> ")
	from.PrintValue(); fmt.Print(" -> ")
	fmt.Print( "End <" )
	fmt.Printf( "\tDistance: %v\n", d )

	fmt.Print("Grab: ")
	grab, d := walk.Grab( e )
	e.PrintValue(); fmt.Print("> ")
	for _, e := range grab {
		if e != nil { e.PrintValue(); fmt.Print(" -> ") }
	}
	fmt.Print( "End <" )
	fmt.Printf( "\tDistance: %v\n", d )

	fmt.Print("Haul: ")
	haul, d := walk.Haul( e )
	e.PrintValue(); fmt.Print("> ")
	for _, e := range haul {
		if e != nil { e.PrintValue(); fmt.Print(" -> ") }
	}
	fmt.Print( "End <" )
	fmt.Printf( "\tDistance: %v\n", d )
}

func (walk Akas) PrintFullWalk ( e *list.Element ) {
	fmt.Print("From: ")
	from, d := walk.From( e )
	e.PrintValue(); fmt.Print("> ")
	for _, e := range from {
		if e != nil { e.PrintValue(); fmt.Print(" -> ") }
	}
	fmt.Print( "End <" )
	fmt.Printf( "\tDistance: %v\n", d )

	fmt.Print("Grab: ")
	grab, d := walk.Grab( e )
	e.PrintValue(); fmt.Print("> ")
	for _, e := range grab {
		if e != nil { e.PrintValue(); fmt.Print(" -> ") }
	}
	fmt.Print( "End <" )
	fmt.Printf( "\tDistance: %v\n", d )

	fmt.Print("Haul: ")
	haul, d := walk.Haul( e )
	e.PrintValue(); fmt.Print("> ")
	for _, e := range haul {
		if e != nil { e.PrintValue(); fmt.Print(" -> ") }
	}
	fmt.Print( "End <" )
	fmt.Printf( "\tDistance: %v\n", d )
}
