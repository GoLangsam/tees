﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package walk

// For Your convenience: Some predefined Moves:

// for the basic GoTo's
	var GotoPrev	Kata = []GoTo{ Prev }
	var GotoNext	Kata = []GoTo{ Next }
	var GotoAway	Kata = []GoTo{ Away }
	var GotoRoot	Kata = []GoTo{ Root }
	var GotoFront	Kata = []GoTo{ Front }
	var GotoBack	Kata = []GoTo{ Back }
	var GotoHome	Kata = []GoTo{ Home }

// for composed movement
// Orthogonal
// Hint: Think of a right-hand matrix (or chessboard), look at a horizontal element
// Note: A Spreadsheet or Matrix is usually left(!)-handed, Rows go down!!!
	var MoveAwayPrev	Kata = []GoTo{ Away, Prev, Away }		//	= Up
	var MoveAwayNext	Kata = []GoTo{ Away, Next, Away }		//	= Down
	var MoveUp		Kata = MoveAwayPrev
	var MoveDown		Kata = MoveAwayNext

// next/prev orthogonal fiber
	var TrixNextFront	Kata = []GoTo{ Root, Away, Next, Away, Front }
	var TrixNextBack	Kata = []GoTo{ Root, Away, Next, Away, Back }
	var TrixPrevFront	Kata = []GoTo{ Root, Away, Prev, Away, Front}
	var TrixPrevBack	Kata = []GoTo{ Root, Away, Prev, Away, Back }

// Diagonal
	var JumpDiagonalNU	Kata = []GoTo{ Next, Away, Prev, Away }		//	= Next, AwayPrev
	var JumpDiagonalND	Kata = []GoTo{ Next, Away, Next, Away }		//	= Next, AwayNext
	var JumpDiagonalPU	Kata = []GoTo{ Prev, Away, Prev, Away }		//	= Prev, AwayPrev
	var JumpDiagonalPD	Kata = []GoTo{ Prev, Away, Next, Away }		//	= Prev, AwayPrev

// Diagonal - chess: King:Jump, Bishop:Tour, Queen:Tour
	var DiagRightUp		Kata = JumpDiagonalNU
	var DiagRightDown	Kata = JumpDiagonalND
	var DiagLeftUp		Kata = JumpDiagonalPU
	var DiagLeftDown	Kata = JumpDiagonalPD

// Knight's
	var JumpKnight_NNU	Kata = []GoTo{ Next, Next, Away, Prev, Away }	//	= Next, RightUp
	var JumpKnight_NND	Kata = []GoTo{ Next, Next, Away, Next, Away }	//	= Next, RightDown
	var JumpKnight_PPU	Kata = []GoTo{ Prev, Prev, Away, Prev, Away }	//	= Prev, RightUp
	var JumpKnight_PPD	Kata = []GoTo{ Prev, Prev, Away, Next, Away }	//	= Prev, RightDown
	var JumpKnight_UUP	Kata = []GoTo{ Away, Prev, Prev, Away, Prev }	//
	var JumpKnight_UUN	Kata = []GoTo{ Away, Prev, Prev, Away, Next }	//
	var JumpKnight_DDP	Kata = []GoTo{ Away, Next, Next, Away, Prev }	//
	var JumpKnight_DDN	Kata = []GoTo{ Away, Next, Next, Away, Next }	//

// Chess
	var ChessKing		Akas = []Kata{ GotoPrev, GotoNext, MoveUp, MoveDown, DiagRightUp, DiagRightDown, DiagLeftUp, DiagLeftDown }
// Note: King Grab's only, for others use Haul or Walker!
	var ChessQueen		Akas = ChessKing
	var ChessRook		Akas = []Kata{ GotoPrev, GotoNext, MoveUp, MoveDown }
	var ChessBishop		Akas = []Kata{                                       DiagRightUp, DiagRightDown, DiagLeftUp, DiagLeftDown }

	var ChessKnight		Akas = []Kata{
		JumpKnight_NNU,
		JumpKnight_NND,
		JumpKnight_PPU,
		JumpKnight_PPD,
		JumpKnight_UUP,
		JumpKnight_UUN,
		JumpKnight_DDP,
		JumpKnight_DDN }