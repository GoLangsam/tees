﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package iter

import (
	"dlx/list"
)

// GoTo's represent basic functions to Step from some element to another existing element (or nil)
type GoTo func(*list.Element) *list.Element

// walk represents an iterator
// usage pattern: next := kata.Walker(e); for e := next(), e != nil, e = next() { /* ... */ }
type walk func() *list.Element

// kata (Japanese) is a form of movement (in martial arts)
type kata struct {
	*list.List // Japanese - each element carries one GoTo
}

func NewKata( v interface{}, gotos ...GoTo ) kata {
	var k = kata{ list.NewList( v ) }
	for step := range( gotos ) {
		k.PushBack( step )
	}
	return k
}

// akas (Burmese) is a list of forms of movement (in martial arts, and dances :-) )
type akas struct {
	*list.List // Burmese
}

func NewAkas( v interface{}, steps ...kata ) akas {
	var k = akas{ list.NewList( v ) }
	for step := range( steps ) {
		k.PushBack( step )
	}
	return k
}

// HiHo (or ZigZag) is a pair of Kata, the second one of which is applied once upon end of first
type HiHo [2]kata


// Cursor
func Cursor(step GoTo, e *list.Element) walk {
	var next = e
	var jump = step

	var move walk = func() *list.Element {
		if next == nil { panic("Cannot walk away from nil!") }
		next = jump( next )
		return next
	}
	return move
}


func (steps kata) Walker(e *list.Element) walk {
	var next = e
	var here = steps.Front()
	var jump = here.Value.(GoTo)

	var move walk = func() *list.Element {
retry:		next = jump( next )
		if next == nil {
			here = here.Next()
			if here == nil { return next } // Note: next == nil
			jump = here.Value.(GoTo)
			goto retry
		}
		return next
	}
	return move
}

/*
func (jumps akas) Turner(e *list.Element) walk {
	var next = e
	var here = jumps.Front()
	var jump = here.Value.(GoTo)

	var move walk = func() *list.Element {
retry:		next = jump( next )
		if next == nil {
			here = here.Next()
			if here == nil { return next } // Note: next == nil
			jump = here.Value.(GoTo)
			goto retry
		}
		return next
	}
	return move
}
*/