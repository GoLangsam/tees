﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
listaway.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- e.Junk (x *Element)	// cross-links Away's

	- l.Away()		*Element
	- e.Away()		*Element
	- l.AwayNext()		*Element
	- e.AwayNext()		*Element
	- l.AwayPrev()		*Element
	- e.AwayPrev()		*Element
	- e.Home()		*Element

	- l.Junks( *List )	bool
	- e.Junks( *Element )	bool

	- l.IsSolo()		bool
	- e.IsSolo()		bool

	- e.IsNode()		bool

	- e.IsJunk()		bool

	- l.AddBeam
	- l.AddRays
	- l.AddList
	- l.AddOnes

*/
package list

// ===========================================================================
// func (e *Element) ...
// Move

// Away returns the away element (an element of the orthogonal fiber-list)
func (l *List) Away() *Element {
	return l.root.away
}

// AwayNext returns next of the away element (an element of the orthogonal fiber-list)
func (l *List) AwayNext() *Element {
	return l.root.AwayNext()
}

// AwayPrev returns prev of the away element (an element of the orthogonal fiber-list)
func (l *List) AwayPrev() *Element {
	return l.root.AwayPrev()
}

// Away returns the away element (an element of the orthogonal fiber-list)
func (e *Element) Away() *Element {
	return e.away
}

// AwayNext returns next of the away element (an element of the orthogonal fiber-list)
func (e *Element) AwayNext() *Element {
	if e.away == nil { return e.away }
	return e.away.Next()
}

// AwayPrev returns prev of the away element (an element of the orthogonal fiber-list)
func (e *Element) AwayPrev() *Element {
	if e.away == nil { return e.away }
	return e.away.Prev()
}

// Home returns prev of the away element (an element of the orthogonal fiber-list)
func (e *Element) Home() *Element {
	if &e.list == nil { return nil }
	if &e.list.root == nil { return nil }
	return e.list.root.away
}


// SetAway sets the away (an element of the orthogonal fiber-list)
// If e == mark or e and mark are element of the same list, the element is not modified.
// NOTE: only any new List's list-Element points to itself!
/* Is this needed by the outer world?
func (e *Element) SetAway(away *Element) {
	if e == away || e.list == away.list {
		return
	}
	e.away = away
}
*/

// Junk links another element as a mutual Junc-tion of their Away's
func (e *Element) Junk (x *Element) {
	if e.away != nil {panic("away in e already set!")}
	if x.away != nil {panic("away in x already set!")}
	x.away = e
	e.away = x
}



// AddBeam returns a new list with root-value v and new elements with values dots,
// the root of which is Junk'ed to a new PushBack-Element (with same value v) of l
func (l *List) AddBeam ( v interface{}, dots ...interface{} ) *List {

	var list = NewList( v )
	list.ValuesPushBack( dots... )

	return l.AddList( list )
}

// AddRays Add's lists to l
// and returns l
func (l *List) AddRays ( lists ...*List ) *List {
	for _, list := range lists {
		l.AddList( list )
	}
	return l
}

// AddList adds a new element with value v to list l
// Junk'es it with the list's root
// and returns list (not l) - useful for calculated lists
func (l *List) AddList ( list *List ) *List {

	var head = l.PushBack( l.With(list) )
	list.root.Junk( head )	//	:SameAs head.Junk( list.Root() )

	return list
}


// AddJunk adds Junk'ed pairs of new elements to list l across respective lists
// The new elements carry pointers to both Roots() as Values.
// Thus, they carry their coordinates, so to say.
func (l *List) AddJunk ( v interface{}, lists ...*List) *List {

	var list = NewList( v )

	for _, head := range lists {
		vert := head.PushBack( head.With(list) )
		hori := list.PushBack( list.With(head) )
		vert.Junk( hori )
	}
	return l.AddList( list )
}

// AddOnes adds Junk'ed pairs of new elements to list l across respective lists
// The new elements carry no Values. They are light, so to say.
func (l *List) AddOnes ( v interface{}, lists ...*List) *List {

	var list = NewList( v )

	for _, head := range lists {
		vert := head.PushBack( nil )
		hori := list.PushBack( nil )
		vert.Junk( hori )
	}
	return l.AddList( list )
}

// ===========================================================================
// func (l *List) ...

// bool

// IsSolo reports whether the list l has no Away()
func (l *List) IsSolo() bool {
	return l.root.away == nil
}

// ===========================================================================
// func (e *Element) ...

// Binary bool

// Junks reports whether the elements e and i are Junk'ed
func (e *Element) Junks(i *Element) bool {
	return ( e.away == i ) && ( i.away == e )
}

// IsSolo reports whether the element e has no Away()
func (e *Element) IsSolo() bool {
	return e.away == nil
}

// IsJunk reports whether the element e has it's Away() Junk'ed
func (e *Element) IsJunk() bool {
	return ( e.away != nil ) && ( e == e.away.away )
}
