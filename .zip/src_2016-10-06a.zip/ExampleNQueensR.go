﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//package dance_test
package main

import (
	"dlx/dance/chooser"
	"dlx/dance/dancer"
	"dlx/dance/drummer"
	"dlx/dance/rhythm"

	"dlx/list/test"

	"dlx/anything/stack/normal/stack"

//	dANCE "dlx/list/dancef"

	"fmt"

	"dlx/yingyang/spot"
)

var Verbose = false
var Level int

var PrintSolutions bool = false

var INI_Depth = 100
var Chooser chooser.Chooser = chooser.ChooseFront
var R = rhythm.New(stack.New(), drummer.New( INI_Depth ))

// ========================================================

func Dancing(d *dancer.Dancer, l spot.Spot) (spot.Spot, bool) {
	if Verbose {
		l.PrintValue()
		l.PrintAways()
		fmt.Println( "Level: ", Level)
	}

	if cols, look := Chooser(l); !look {
		if cols == nil {
			if rhythm.Verbose {R.OnDead()()}
	//		d.OnDead()
		} else if l.Len() == 0 {
			if rhythm.Verbose {R.OnGoal()()} // Drummer.Grooves.Beat(Stacker.Len())
	//		if PrintSolutions { R.Print() }
			_ = R.Get()
		}
		return cols, look
	} else {
		return cols, look
	}
}

// ========================================================
// Dance - standard dancer-callback (incl. Level)

func Dance(l spot.Spot, dancer *dancer.Dancer) {
	if dance, dancing := Dancing(dancer, l); dancing {	// Say Hello to Dancer, and if dancing ain't finished:
		if Verbose {Level++}
		if rhythm.Verbose {R.OnCall()(l)}
		dance.Dance( dancer )					// Dance on dance with dancer
//		dance.DanceFast( dancer )				// Dance on dance with dancer
//		dance.DanceSlow( dancer )				// Dance on dance with dancer
//		dANCE.Dance( dance, dancer )
		if Verbose {Level--}
	}
}

// ========================================================

func SetCallBackNQueens( d *dancer.Dancer, anz int ) *dancer.Dancer {
	var cols = test.NQueensR( anz )
	if Verbose {
//		cols.PrintAways()
		fmt.Printf("%s\t% 9d\t"+"\n", "Size: ", cols.Size() ) // this just gives cols * rows (ignoring secondary)
		fmt.Printf("%s\t% 9d\t"+"\n", "Trix: ", cols.AwayList().Size() ) // this gives ??? TODO: this is NOT correct!!!
	}
	d.CallBack = func(){ Dance(cols, d) } 			// TODO: dance.DanceFast(cols, d)
	return d
}

// ========================================================
func Prepare( anz int ) *dancer.Dancer {

	var d = dancer.New()
	d.SetDrumming(R)
	d.CallOnAsk = func(interface{}) bool {return true}	// TODO: more ...
	return d
}

// ========================================================

/*
TODO: Where put? listtrix?
// Print prints the current stack (= the solution)
func Print(r Rhythm) {
	fmt.Print( "Solution: ")
	fmt.Println( r.Len() )
	var s = r.Get().([]*list.List)
	for _, l := range s {
		l.PrintValue()
		fmt.Print( ": " )
		for e := l.Front(); e != nil; e = e.Next() {
			e.Away().List().Root().PrintValue()
			fmt.Print( " " )
		}
		fmt.Println( "." )
	}
}
*/

// ========================================================

func TestChoosers(anz int) {
	for _, c := range chooser.GetChoosers() {
		Chooser = c
		NQueensR( anz )
	}
}

func NQueensR( anz int ) {

	d := Prepare( anz )
	d = SetCallBackNQueens( d, anz )
	d.CallBack()
	R.Print()
	R = rhythm.New(stack.New(), drummer.New( INI_Depth ))

}

func main() {

	beg := 8
	end := 9

	drummer.Verbose = true

	for i := beg; i <= end; i++ {
		fmt.Println()
		fmt.Println( "Queens on a", i, "Board" )
//		NQueensR( i )
		TestChoosers( i )
	}
}

