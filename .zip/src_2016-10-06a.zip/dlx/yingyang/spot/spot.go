﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package spot

import (
	"dlx/list"
)

// Spot abstracts the common behaviour of *list.Element & *list.List
type Spot interface {
	Away
	Beam
	Dust
	Sama
}

// Away abstracts the 'orthogonal' behaviour common to *list.Element & *list.List
type Away interface {

	AwayBeam
	AwayDust
}

// AwayBeam abstracts the 'orthogonal' beam-behaviour common to *list.Element & *list.List
type AwayBeam interface {

	AwayList() *list.List
	AwayNext() *list.Element
	AwayPrev() *list.Element

	Home() *list.Element

	PrintAways(args ...interface{})
}

// AwayDust abstracts the 'orthogonal' dust-behaviour common to *list.Element & *list.List
type AwayDust interface {
	Away() *list.Element
	IsJunk() bool
	IsSolo() bool

}

// Beam abstracts the 'lengthy' behaviour common to *list.Element & *list.List
type Beam interface {

	ForEachNext( f func(*list.Element) )
	ForEachPrev( f func(*list.Element) )

	Elements() []*list.Element		// => list.Dots

	Front() *list.Element
	Back() *list.Element

	Len() int

	Root() *list.Element
}

// Dust abstracts the 'pointy' behaviour common to *list.Element & *list.List
type Dust interface {

	CVs() *list.ComposedValue

	IsAtom() bool
	IsComposed() bool

	PrintAtomValues(args ...interface{})
	PrintValue(args ...interface{})
	Values() list.Values
}

// Sama abstracts the 'dancing' behaviour common to *list.Element & *list.List
type Sama interface {

	Dance(d list.Dancer)
	DanceFast(d list.Dancer)
	DanceSlow(d list.Dancer)
}

// ========================================================

// dummy is here for internal documentation only
type dummy interface {
// New() *List
// NewList(v interface{}, vals ...interface{}) *List
// (l *List) AddBeam(v interface{}, vals ...interface{}) *List			=> trix
// (l *List) AddJunk(v interface{}, lists ...*List) *List			=> trix
// (l *List) AddList(list *List) *List						=> trix
// (l *List) AddOnes(v interface{}, lists ...*List) *List			=> trix
// (l *List) AddRays(lists ...*List) *List					=> trix
// (l *List) NewCalc() *List							=> trix
// (l *List) Size() int								=> trix

	Away() *list.Element
	AwayNext() *list.Element
	AwayPrev() *list.Element
	Back() *list.Element
	CVs() *list.ComposedValue
// (l *List) Clear() *List							=> trix ?

	Dance(d list.Dancer)
// 	fold()
// 	open()

	DanceFast(d list.Dancer)
// fast	foldFast(d list.Dancer)
// fast	openFast(d list.Dancer)
// fast	unListFast(d list.Dancer)
// fast	reListFast(d list.Dancer)

	DanceSlow(d list.Dancer)
// slow	foldSlow(d list.Dancer)
// slow	openSlow(d list.Dancer)
// slow	unListSlow(d list.Dancer)
// slow	reListSlow(d list.Dancer)

	ForEachNext( f func(*list.Element) )
	ForEachPrev( f func(*list.Element) )

	Elements() []*list.Element		// => list.Dots

//	Equals(i Spot) bool			// pair!

	Front() *list.Element
	Home() *list.Element
// (l *List) Init() *List
// (l *List) InsertAfter(v interface{}, mark *Element) *Element
// (l *List) InsertBefore(v interface{}, mark *Element) *Element

	IsAtom() bool
	IsComposed() bool
// (l *List) IsEmpty() bool		// TODO? ???

	IsJunk() bool
// (e *Element) IsNode() bool		// TODO? l.IsNode == false
// (e *Element) IsRoot() bool		// TODO? l.IsRoot == true

	IsSolo() bool
// (e *Element) Junk(x *Element)	// TODO? Junk Roots - no way, compile errors
//	Junks(i Spot) bool			// pair!

	Len() int
// (l *List) MoveAfter(e, mark *Element)
// (l *List) MoveBefore(e, mark *Element)
// (l *List) MoveToBack(e *Element)
// (l *List) MoveToFront(e *Element)

// (e *Element) Next() *Element		// TODO?
// (e *Element) Prev() *Element		// TODO?

// (l *List) Print(args ...interface{})	// TODO!
	PrintAtomValues(args ...interface{})
	PrintAways(args ...interface{})
	PrintValue(args ...interface{})

// (l *List) PushBack(v interface{}) *Element		==> Beam
// (l *List) PushBackList(other *List)
// (l *List) PushFront(v interface{}) *Elemen		==> Beamt
// (l *List) PushFrontList(other *List)

// (l *List) Remove(e *Element) interface{}

	Root() *list.Element
	Values() list.Values

// (l *List) ValuesPushBack(values ...interface{})	==> Beam
// (l *List) ValuesPushFront(values ...interface{})	==> Beam

//	With( Spot ) *list.ComposedValue	// pair!
}
