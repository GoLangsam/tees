﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stack

import (
	"dlx/list"
)

// AnyDanceStack
type AnyDanceStack interface {
	AnyStack
	StackHasLen
}

// DanceStack
type DanceStack interface {
	ListStack
	StackHasLen
}

// ListStack abstracts the common behaviour of stacks for *list.List
type ListStack interface {
//	Init(int)	*ListStack
	Push( *list.List )
	Pop() *list.List
	Top() *list.List
	Get() []*list.List
}

// ElemStack abstracts the common behaviour of stacks for *list.Element
type ElemStack interface {
//	Init(int)	*ElemStack
	Push( *list.Element )
	Pop() *list.Element
	Top() *list.Element
	Get() []*list.Element
}

// AnyStack abstracts the common behaviour of stacks for interface{}
type AnyStack interface {
//	Init(int)	*AnyStack
	Push( interface{} )
	Pop() interface{}
	Top() interface{}
	Get() []interface{}
}

type StackHasLen interface {
	Len() int
}

type StackCanPrint interface {
	Print()
}
