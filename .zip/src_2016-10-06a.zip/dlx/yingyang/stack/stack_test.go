﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package stack_test

import (
	"dlx/yingyang/stack"

	stacknormal		"dlx/anything/stack/normal/stack"
	stackccsafe		"dlx/anything/stack/concurrencysafe/stack"
)

func testAnyStack(s stack.AnyStack) {}

func testHasLen(s stack.StackHasLen) {}
func testCanPrint(s stack.StackCanPrint) {}

func ExampleSpot() {
	var ns = stacknormal.New()
	testAnyStack(ns)
	testHasLen(ns)

	var cs = stackccsafe.New()
	testAnyStack(cs)
	testHasLen(cs)
}