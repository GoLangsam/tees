﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
call defines typical calls
*/
package call

import (
	"dlx/list"
	"dlx/yingyang/spot"
)

type Rhythm interface {
	OnCall() CallWithAny
	OnLeaf() CallWithAny
	OnPush() CallWithAny
	OnPop()  CallForAny
}


type Callback               func()
var  NoOp                 = func(){return}

type CallWithAny            func(  interface{} )
var  NoOpWithAny          = func(  interface{} ){return}

type CallWithAnyForBool     func(  interface{} ) bool
var  NoOpWithAnyForBool   = func(  interface{} ) bool {return false}

type CallWithSpot           func(  spot.Spot )
var  NoOpWithSpot         = func(  spot.Spot ){return}

type CallWithList           func(  *list.List )
var  NoOpWithList         = func(  *list.List ){return}

type CallWithListForBool    func(  *list.List ) bool
var  NoOpWithListForBool  = func(  *list.List ) bool {return false}

type CallWithElem           func(  *list.Element )
var  NoOpWithElem         = func(  *list.Element ){return}

type CallForList            func() *list.List
var  NoOpForList          = func() *list.List {return nil}

type CallForAny             func() interface{}
var  NoOpForAny           = func() interface{} {return nil}

type CallForBool            func() bool
var  NoOpForBool          = func() bool {return false}

type CallForSpot            func() spot.Spot
var  NoOpForSpot          = func() spot.Spot {return nil}

