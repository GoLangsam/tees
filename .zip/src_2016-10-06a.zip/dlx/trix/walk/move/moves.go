﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package move

import (
	"dlx/list"

	"dlx/trix/walk"
	"dlx/trix/walk/akas"
	"dlx/trix/walk/kata"
)

// For Your convenience: Some predefined Moves:

// for the basic GoTo's
	var Next walk.GoTo = (*list.Element).Next
	var Prev walk.GoTo = (*list.Element).Prev
	var Away walk.GoTo = (*list.Element).Away
	var Root walk.GoTo = (*list.Element).Root
	var Front walk.GoTo = (*list.Element).Front
	var Back walk.GoTo = (*list.Element).Back
	var Home walk.GoTo = (*list.Element).Home

// the basic GoTo's
	var GotoNext		= kata.New( "Goto Next" , Next )
	var GotoPrev		= kata.New( "Goto Prev" , Prev )
	var GotoAway		= kata.New( "Goto Away" , Away )
	var GotoRoot		= kata.New( "Goto Root" , Root )
	var GotoFront		= kata.New( "Goto Front", Front )
	var GotoBack		= kata.New( "Goto Back" , Back )
	var GotoHome		= kata.New( "Goto Home" , Home )

// for composed movement
// Orthogonal
// Hint: Think of a right-hand matrix (or chessboard), look at a horizontal element
// Note: A Spreadsheet or Matrix is usually left(!)-handed, Rows go down!!!
	var MoveAwayPrev	= kata.New( "Away Prev", Away, Prev, Away )	//	= Up
	var MoveAwayNext	= kata.New( "Away Next", Away, Next, Away )	//	= Down
	var MoveUp		= kata.New( "Up",       Away, Prev, Away )	//	= MoveAwayPrev
	var MoveDown		= kata.New( "Down",     Away, Next, Away )	//	= MoveAwayNext

// next/prev orthogonal fiber
	var TrixNextFront	= kata.New( "Next Front", Root, Away, Next, Away, Front )
	var TrixNextBack	= kata.New( "Next Back",  Root, Away, Next, Away, Back )
	var TrixPrevFront	= kata.New( "Prev Front", Root, Away, Prev, Away, Front )
	var TrixPrevBack	= kata.New( "Prev Back" , Root, Away, Prev, Away, Back )

// Diagonal
	var JumpDiagonalNU      = kata.New( "Diag NU"   , Next, Away, Prev, Away )//	= Next, AwayPrev
	var JumpDiagonalND      = kata.New( "Diag ND"   , Next, Away, Next, Away )//	= Next, AwayNext
	var JumpDiagonalPU      = kata.New( "Diag PU"   , Prev, Away, Prev, Away )//	= Prev, AwayPrev
	var JumpDiagonalPD      = kata.New( "Diag PD"   , Prev, Away, Next, Away )//	= Prev, AwayPrev

// Diagonal - chess: King:Jump, Bishop:Tour, Queen:Tour
	var DiagRightUp		= kata.New( "Right Up"  , Next, Away, Prev, Away )
	var DiagRightDown	= kata.New( "Right Down", Next, Away, Next, Away )
	var DiagLeftUp		= kata.New( "Left Up"   , Prev, Away, Prev, Away )
	var DiagLeftDown	= kata.New( "Left Down" , Prev, Away, Next, Away )

// Knight's
	var JumpKnight_NNU	= kata.New("NNU", Next, Next, Away, Prev, Away )	//	= Next, RightUp
	var JumpKnight_NND	= kata.New("NND", Next, Next, Away, Next, Away )	//	= Next, RightDown
	var JumpKnight_PPU	= kata.New("PPU", Prev, Prev, Away, Prev, Away )	//	= Prev, RightUp
	var JumpKnight_PPD	= kata.New("PPD", Prev, Prev, Away, Next, Away )	//	= Prev, RightDown
	var JumpKnight_UUP	= kata.New("UUP", Away, Prev, Prev, Away, Prev )	//
	var JumpKnight_UUN	= kata.New("UUN", Away, Prev, Prev, Away, Next )	//
	var JumpKnight_DDP	= kata.New("DDP", Away, Next, Next, Away, Prev )	//
	var JumpKnight_DDN	= kata.New("DDN", Away, Next, Next, Away, Next )	//

// Chess
	var ChessKing		= akas.New("King", GotoPrev, GotoNext, MoveUp, MoveDown, DiagRightUp, DiagRightDown, DiagLeftUp, DiagLeftDown )
// Note: King Grab's only, for others use Haul or Walker!
	var ChessQueen		*akas.Akas = ChessKing
	var ChessRook		= akas.New("Rook", GotoPrev, GotoNext, MoveUp, MoveDown )
	var ChessBishop		= akas.New("Bishop",                                     DiagRightUp, DiagRightDown, DiagLeftUp, DiagLeftDown )

	var ChessKnight		= akas.New("Knight",
		JumpKnight_NNU,
		JumpKnight_NND,
		JumpKnight_PPU,
		JumpKnight_PPD,
		JumpKnight_UUP,
		JumpKnight_UUN,
		JumpKnight_DDP,
		JumpKnight_DDN )