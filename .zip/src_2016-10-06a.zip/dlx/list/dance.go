﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dance.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- l.Dance( d Dancer )
	- e.Dance( d Dancer )

*/
package list

// ========================================================

// Dance l is where the dancing begins
func (l *List)     Dance( d Dancer ) {
	l.fold(d)
	l.root.Dance( d )
	l.open(d)
}

// Dance e is where the dancing continues
func (e *Element)  Dance( d Dancer ) {
	for i := e.next; i != e; i = i.next {
		if d.Ask( i.away.list ) {	// Push
			i.away.fold(d)
			d.Dance()		// Dance d is where the dancing recurs to
			i.away.open(d)
		}
		_ =d.Get().(*List)		// Pop
	}
}

// ========================================================
func (l *List)      fold( d Dancer ) { 						l.root.away.unLink(d);	l.unList(d)		    }
func (l *List)      open( d Dancer ) { 						l.root.away.reLink(d);	l.reList(d)		    }

func (e *Element)   fold( d Dancer ) { for i := e.next; i != e; i = i.next { if i != &e.list.root {	i.away.list.fold(d)	} } }
func (e *Element)   open( d Dancer ) { for i := e.prev; i != e; i = i.prev { if i != &e.list.root {	i.away.list.open(d)	} } }

func (l *List)    unList( d Dancer ) { for i := l.root.next; i != &l.root; i = i.next { 			i.away.unList(d)		  } }
func (l *List)    reList( d Dancer ) { for i := l.root.prev; i != &l.root; i = i.prev { 			i.away.reList(d)		  } }

func (e *Element) unList( d Dancer ) { for i := e.next; i != e; i = i.next { if i != &e.list.root {	i.away.unLink(d)	} } }
func (e *Element) reList( d Dancer ) { for i := e.prev; i != e; i = i.prev { if i != &e.list.root {	i.away.reLink(d)	} } }

func (e *Element) unLink( d Dancer ) {          e.next.prev, e.prev.next = e.prev, e.next;		e.list.len--;	d.OnLeaf(e)	}
func (e *Element) reLink( d Dancer ) {          e.next.prev, e.prev.next = e, e;			e.list.len++}

func (e *Element) UnLink()           {          e.next.prev, e.prev.next = e.prev, e.next;		e.list.len--}
func (e *Element) ReLink()           {          e.next.prev, e.prev.next = e, e;			e.list.len++}

/*
- on Cols:
	- l.fold()	l.unShow(col)			& unLink( Col-Head )
	- l.open()	l.reShow(col)			& reLink( Col-Head )

- on Rows - walking hori:
	- e.fold()	e's.away.list.fold(col)		except e.list.root (row head)
	- e.open()	e's.away.list.open(col)		except e.list.root (row head)

- on Cols - walking vert: (no need to skip root explicitly, as it's called for l.root)
	- l.unList()	l's.away.unList(row)
	- l.reList()	l's.away.reList(row)

- on Rows - walking hori:
	- e.unList()	e's.away.unLink(col)		except e.list.root (row head)
	- e.reList()	e's.away.reLink(col)		except e.list.root (row head)

	- e.unLink()
	- e.reLink()

*/