﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.


package dance

import (
//	"dlx/list"
	"dlx/yingyang/spot"
)

//Dancer interface: Fold, Open, Dance
type Dancer interface {
	Fold( spot.Spot )
	Open() spot.Spot
	Dance()

//	...
}
