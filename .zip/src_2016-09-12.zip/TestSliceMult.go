﻿// test algebra of slices
package main

import (
	"dlx/list"
	"fmt"
)

var cols = []string{ "A", "B", "C", "D", "E", "F", "G", "H" }
var rows = []string{ "1", "2", "3", "4", "5", "6", "7", "8" }
var stuf = []string{ "Staub", "Korn", "Körnchen", "noch 'n Korn" }


// sum - iterative version
func sum(faktors... []string) []string {

	var newcap = 0
	for _, faktor := range faktors {
		newcap =+ len(faktor)
	}

	var data = make ([]string, 0, newcap )

	for _, faktor := range faktors {
		for _, e := range faktor {
			data = append ( data , e )
		}
	}
	return data
}


func main() {

/*
	var sum = sum( cols, rows, stuf )
//	var sum = mult( axis )

	fmt.Println(sum)

	// lenghtes
	var X = len(cols)
	var Y = len(rows)
	var Z = len(stuf)
	fmt.Println(X, Y, Z)	// "B"

	var x = 2
	fmt.Println(cols[x - 1])	// "B"
	var y = 4
	fmt.Println(rows[y - 1])	// "4"
	var z = 3
	fmt.Println(stuf[z - 1])	// "Körnchen"



	var coord = 0

	coord = ( (x-1) * (Y+Z) ) + ( (y-1) * Y ) + (z-1)
	coord = 5
	fmt.Println(sum[coord])	// "?"

	coord = (x - 1) * (Y + 1 ) * (Z + 1)
	coord = (x - 1) * (Y + 1 ) * (Z + 1)
*/
	fmt.Println( "Root & Co" )
	var root = list.NewList( "Board" )
	var Cols = root.AddBeam( "Spalten", "A", "B", "C", "D", "E", "F", "G", "H" )	// )
	var Rows = root.AddBeam( "Zeilen", "1", "2", "3", "4", "5", "6", "7", "8" )	// )
	var Stuf = root.AddBeam( "Stuff", "Staub", "Korn", `Körnchen`, "noch 'n Korn" )	// )

	root.Print()

	fmt.Println( "================================================================================" )
	fmt.Println( "Cols * nil" )
	Nil := Cols.Times( nil )
	Nil.PrintValues()

	fmt.Println( "================================================================================" )
	fmt.Println( "Adding 'Cols * nil' to root" )
	Nix := root.AddList( "Spalten-Zeilen-Stuff", Cols.Times( nil ) )
	Nix.PrintValues()

	fmt.Println( "================================================================================" )
	fmt.Println( "Adding 'Cols * Rows * Stuff' to root" )
	CRS := root.AddList( "Spalten-Zeilen-Stuff", Cols.Times( Rows, Stuf ) )
	CRS.Print( "Spalten * (Zeilen * Stuff) ")

	fmt.Println( "================================================================================" )
	fmt.Println( "Adding 'Rows * Cols * Stuff' to root" )
	RCS := root.AddList( "Spalten-Zeilen-Stuff", Rows.Times( Cols, Stuf ) )
	RCS.Print( "Zeilen * ( Spalten * Stuff) ")

	fmt.Println( "================================================================================" )
	root.PrintValues()

	for e := root.Front(); e != nil; e = e.Next() {
		e.PrintAways( "Listen in Root: " )
	}


}
