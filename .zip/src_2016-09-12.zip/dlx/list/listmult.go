﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
listmult.go extends the (stolen and extended) list.go
with operations such as addition and multiplication
*/
package list

// Times returns a new list: the cross product with some lists
// ( recursively as l [ * [ l * [ ... ]]] )
// Note: l.Times( nil ) returns a new empty list
//func x ( v interface{}, lists... *List ) *List { // What is new title???

func (l *List) Times ( lists... *List ) *List {
	if len(lists) == 0 {	return NewList( []*List{ l } )  }
	if lists[0] == nil {	return NewList( []*List{ l } )  }
	if len(lists) == 1 {	return l.times( lists[0] ) }
				return l.times( lists[0].Times( lists[1:]... ) )
}

// times returns a new list with len(l) * len(X) Elements
// representing the cross-product of the list l times X
// Note: l.times( nil ) returns a new list with no elements
func (l *List) times ( X *List ) *List {
	prod := NewList( []*List{ l, X } )
	for y := l.Front(); y != nil; y = y.Next() {
		for x := X.Front(); x != nil; x = x.Next() {
			prod.PushBack( []*Element{x, y} )
		}
	}
	return prod
}
