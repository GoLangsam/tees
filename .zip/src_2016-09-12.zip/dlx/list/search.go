﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
search.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

*/
package list

import (
	"fmt"
)


// ========================================================
/*
To choose a column object c, we could simply set
c =: root.Next().Away().List(); this is the leftmost uncovered column.
Or if we want to minimize the branching factor, we could
*/
func (l *List)	ChooseFront () *List {
	return l.Front().Away().List()
}

// ========================================================
/*
To choose a column object c, we could simply set
c =: root.Next().Away().List(); this is the leftmost uncovered column.
Or if we want to minimize the branching factor, we could
*/
func (l *List)	ChooseShort () *List {
	var c = NewList( nil )
	s := 999999999
	for j := l.Front(); j != nil; j = j.Next()	{
		list := j.Away().List()
		if list.Len() < s {
			c = list
			s = list.Len()
		}
	}
//	fmt.Print( "Short=")
//	fmt.Println( s )
	return c
}

func PrintSolution() {
	fmt.Println( "Solution: ")
	for _, s := range stack {
		for e := s.Front(); e != nil; e = e.Next() {
			fmt.Print( e.Away().List().Root().Value )
			fmt.Print( " " )
		}
		fmt.Println()
	}
}

var Levelcount = make ( map[int]int )

// ========================================================
func (l *List)	Search ( depth int ) {

	Levelcount[depth]++

	if l.Len() == 0 { // || l.Root().Away().List().Len() == 0 {
		PrintSolution()
	} else {
		// Otherwise: choose a column object c
//		list := l.Front().Away().List()
//		list := l.ChooseFront()
		list := l.ChooseShort()
		list.Dance( func() {l.Search( depth + 1 )} )
	}
}

// ========================================================
