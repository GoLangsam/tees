﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dance.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- l.Dance( dance func() )

	- l.fold()
	- l.open()

	- e.fold()
	- e.open()

	- e.unList()
	- e.reList()

	- e.unLink()
	- e.reLink()

*/
package list

// ========================================================
// Dance is where the dancing begins
func (l *List)	Dance ( dance func() ) {
	l.fold()
	for i := l.root.next; i != &l.root && i != nil; i = i.next	{
		push( i.away.list )
		i.away.fold()
		dance()		// recursive callback
		i.away.open()
		pop()
	}
	l.open()
}

// ========================================================
// fold is part of the dance
func (l *List)	fold() {

	l.root.away.unLink()

	for i := l.root.next; i != &l.root; i = i.next	{

		if l != i.away.list {
			i.away.list.root.away.unLink()
		}
	 	i.away.unList()
	}
}
// open is part of the dance
func (l *List)	open() {

	for i := l.root.prev; i != &l.root; i = i.prev	{

		i.away.reList()

		if l != i.away.list {
			i.away.list.root.away.reLink()
		}
	}

	l.root.away.reLink()
}

// ========================================================
func (e *Element)   fold() { for i := e.next; i != e; i = i.next { if i != &e.list.root { i.away.list.fold() } } }
func (e *Element)   open() { for i := e.prev; i != e; i = i.prev { if i != &e.list.root { i.away.list.open() } } }

func (e *Element) unList() { for i := e.next; i != e; i = i.next { if i != &e.list.root { i.away.unLink() } } }
func (e *Element) reList() { for i := e.prev; i != e; i = i.prev { if i != &e.list.root	{ i.away.reLink() } } }

// ========================================================
// unLink an element (temporarily!) from it's list
func (e *Element) unLink() {
	e.next.prev, e.prev.next = e.prev, e.next
	e.list.len--
}

// reLink a temporarily unLinked element to it's list
func (e *Element) reLink() {
	e.list.len++
	e.next.prev, e.prev.next = e, e
}
