﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package star

// Eiks - Element X (= iks) - basics for a Xross-product
// TODO: currently just a playfield

import (
	"dlx/list"
)

func Eiks (criss, cross func( v interface{} ) *list.Element ) *Star {
	var x = criss( nil )
	var y = cross( nil )
	return star(x, y)
}

func EiksWithData (criss func( v interface{} ) *list.Element, cris interface{}, cross func( v interface{} ) *list.Element, cros interface{} ) *Star {
	var x = criss( cris )
	var y = cross( cros )
	return star(x, y)
}

