﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dancer.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- dancer interface: Push, Pop, Dance, Leaf

*/
package list

//Dancer interface: Push, Pop, Dance and Leaf
type Dancer interface {
	Push( *Element )
	Pop() *Element
	Dance()
	OnLeaf( *Element )
}
