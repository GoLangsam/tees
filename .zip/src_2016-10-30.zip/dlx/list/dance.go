﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dance.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- l.Dance( d *Dancing )
	- e.Dance( d *Dancing )

*/
package list

// ========================================================

// Dance l is where the dancing begins
func (l *List)     Dance( d *Dancing ) {
	l.fold(d)
	l.root.Dance( d )
	l.open(d)
}

// Dance e is where the dancing continues
func (e *Element)  Dance( d *Dancing ) {
	for i := e.next; i != e; i = i.next {
		d.Push( i )		// Push
		i.away.fold(d)
		d.Dance()		// Dance d is where the dancing recurs to
		i.away.open(d)
		_ =d.Pop()		// Pop
	}
}

// ========================================================
func (l *List)      fold( d *Dancing ) { 						l.root.away.UnLeaf(d);	l.unList(d)		    }
func (l *List)      open( d *Dancing ) { 						l.root.away.ReLeaf(d);	l.reList(d)		    }

func (e *Element)   fold( d *Dancing ) { for i := e.next; i != e; i = i.next { if i != &e.list.root {	i.away.list.fold(d)	} } }
func (e *Element)   open( d *Dancing ) { for i := e.prev; i != e; i = i.prev { if i != &e.list.root {	i.away.list.open(d)	} } }

func (l *List)    unList( d *Dancing ) { for i := l.root.next; i != &l.root; i = i.next { 		i.away.unList(d)	  } }
func (l *List)    reList( d *Dancing ) { for i := l.root.prev; i != &l.root; i = i.prev { 		i.away.reList(d)	  } }

func (e *Element) unList( d *Dancing ) { for i := e.next; i != e; i = i.next { if i != &e.list.root {	i.away.UnLeaf(d)	} } }
func (e *Element) reList( d *Dancing ) { for i := e.prev; i != e; i = i.prev { if i != &e.list.root {	i.away.ReLeaf(d)	} } }

/*
- on Cols:
	- l.fold()	l.unShow(col)			& unLink( Col-Head )
	- l.open()	l.reShow(col)			& reLink( Col-Head )

- on Rows - walking hori:
	- e.fold()	e's.away.list.fold(col)		except e.list.root (row head)
	- e.open()	e's.away.list.open(col)		except e.list.root (row head)

- on Cols - walking vert: (no need to skip root explicitly, as it's called for l.root)
	- l.unList()	l's.away.unList(row)
	- l.reList()	l's.away.reList(row)

- on Rows - walking hori:
	- e.unList()	e's.away.unLink(col)		except e.list.root (row head)
	- e.reList()	e's.away.reLink(col)		except e.list.root (row head)

	- e.unLink()
	- e.reLink()

*/