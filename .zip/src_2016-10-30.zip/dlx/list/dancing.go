﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package list

type Dancing struct {
	Dance   	func()
	Push		func(e *Element)
	Pop		func() *Element
	OnLeaf		func(e *Element)
}

func NewDancing() *Dancing {		// cannot pass CallBack upon New, as it is a method of himself
	return new( Dancing ).Init()
}

func (d *Dancing) Init() *Dancing {

	d.Dance		= func(){return}

	d.Push		= func(e *Element){return}
	d.Pop		= func() *Element {return nil}
	d.OnLeaf	= func(e *Element){return}
	return d
}
