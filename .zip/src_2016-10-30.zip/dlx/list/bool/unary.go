// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package bool

import (
	"dlx/list"
)

// ===========================================================================

// IsEdge determines, if it makes sense to go further upward from element x 
func IsEdge (x *list.Element) bool {
//	if x == nil { return false }
//	if x.IsNode() { return false }
//	if x.IsSolo() { return true }
	return (x != nil && x.IsRoot() && x.Away() != nil && x.Away().IsNode() )
}

// ===========================================================================

func IsRoot (x *list.Element) bool {
	if x == nil { return false }
	return x.IsRoot()
}

func IsNode (x *list.Element) bool {
	if x == nil { return false }
	return x.IsNode()
}

func IsSolo (x *list.Element) bool {
	if x == nil { return false }
	return x.IsSolo()
}

