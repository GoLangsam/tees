﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
stack.go provides a normal stack for *list.List
guarded by a sync.Mutex

*/
package stack

import (
	"dlx/list"
//	"sync"

	"fmt"
)

// Stack implements a concurrency-safe stack for *list.List
// guarded by a sync.Mutex
type Stack struct {
	stack []*list.List
//	sync.Mutex
}

var INI_Depth = 100

type dance func()

func New() *Stack {
	return new( Stack ).Init( INI_Depth )
}

func (s *Stack) Init( cap int ) *Stack {
	s.stack = make([]*list.List, 0, cap)
	return s
}

// Push sth onto the current stack
func (s *Stack) Push( l *list.List ){
//	s.Lock()
//	defer s.Unlock()

	s.stack = append(s.stack, l)
}

// Pop sth off the current stack
func (s *Stack) Pop() *list.List {
//	s.Lock()
//	defer s.Unlock()

	var p = s.stack[len(s.stack)-1]
	s.stack = s.stack[:len(s.stack)-1]
	return p
}

// Top returns the top of the current stack
func (s *Stack) Top() *list.List {
//	s.Lock()
//	defer s.Unlock()

	return s.stack[len(s.stack)-1]
}

// Get returns a copy of the current stack
func (s *Stack) Get() []*list.List {
//	s.Lock()
//	defer s.Unlock()

	var stack = make([]*list.List, len(s.stack) )
	copy (stack, s.stack)
	return stack
}

// Len returns the length of the current stack
func (s *Stack) Len() int {
//	s.Lock()
//	defer s.Unlock()

	return len(s.stack)
}
// ========================================================

// Print prints the current stack (= the solution)
func (s *Stack) Print() {
//	s.Lock()
//	defer s.Unlock()

	fmt.Print( "Solution: ")
	fmt.Println( s.Len() )
	for _, l := range s.stack {
		l.PrintValue()
		fmt.Print( ": " )
		for e := l.Front(); e != nil; e = e.Next() {
			e.Away().List().Root().PrintValue()
			fmt.Print( " " )
		}
		fmt.Println( "." )
	}
}
