// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package test_test

import (
	"dlx/list/test"
)

func ExampleZip() {
	var N = 7
	var s = test.Stick(N)
	var l = test.Ladder(N)

	s.PrintAways("Stick")
	s.AwayList().PrintAways("Stick-Away")
	l.PrintAways("Ladder")
	l.AwayList().PrintAways("Ladder-Away")
	// Output:
	// Stick: List=Stick | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// Stick-Away: List=Stick | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// => : List=Stick	S-1 | S-2 | S-3 | S-4 | S-5 | S-6 | S-7 | Total=7
	// Ladder: List=LLeft | Total=7
	// => : List=Right	R-1 | R-2 | R-3 | R-4 | R-5 | R-6 | R-7 | Total=7
	// => : List=Right	R-1 | R-2 | R-3 | R-4 | R-5 | R-6 | R-7 | Total=7
	// => : List=Right	R-1 | R-2 | R-3 | R-4 | R-5 | R-6 | R-7 | Total=7
	// => : List=Right	R-1 | R-2 | R-3 | R-4 | R-5 | R-6 | R-7 | Total=7
	// => : List=Right	R-1 | R-2 | R-3 | R-4 | R-5 | R-6 | R-7 | Total=7
	// => : List=Right	R-1 | R-2 | R-3 | R-4 | R-5 | R-6 | R-7 | Total=7
	// => : List=Right	R-1 | R-2 | R-3 | R-4 | R-5 | R-6 | R-7 | Total=7
	// Ladder-Away: List=Right | Total=7
	// => : List=LLeft	L-1 | L-2 | L-3 | L-4 | L-5 | L-6 | L-7 | Total=7
	// => : List=LLeft	L-1 | L-2 | L-3 | L-4 | L-5 | L-6 | L-7 | Total=7
	// => : List=LLeft	L-1 | L-2 | L-3 | L-4 | L-5 | L-6 | L-7 | Total=7
	// => : List=LLeft	L-1 | L-2 | L-3 | L-4 | L-5 | L-6 | L-7 | Total=7
	// => : List=LLeft	L-1 | L-2 | L-3 | L-4 | L-5 | L-6 | L-7 | Total=7
	// => : List=LLeft	L-1 | L-2 | L-3 | L-4 | L-5 | L-6 | L-7 | Total=7
	// => : List=LLeft	L-1 | L-2 | L-3 | L-4 | L-5 | L-6 | L-7 | Total=7
}
