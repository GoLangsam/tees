﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
Anda (Sanskrit) <=> Cosmic Egg

	- New(v, vals...)



	- l.AddBeam
	- l.AddList
	- l.AddJunk
	- l.AddOnes

*/
package anda

import (
	"dlx/list"

	"dlx/trix/anda/apep"
	"dlx/trix/anda/aton"

)

// Aten/Aton (Sun-Disk/Sun-Globe) <=> Apep (darkness&chaos) => Duat (Underworld) / Luna (moon)

type Anda	struct{*list.List}		// ListOfListsOfLists...
type Duat	struct{*list.List}		// The trix stuff TODO: How to link into Anda

/*
Maat

*/

// ===========================================================================

// New returns an initialized anda.
func New(v interface{}, vals ...interface{}) *Anda {
	var aton = aton.New( v, vals... )
	var apep = apep.New( aton.CVs() )	// TODO: bessere Lösung
	return newAnda( aton, apep )
}

func newAnda(aton *aton.AndaAton, apep *apep.AndaApep) *Anda {
	var atom = new(Anda)
	atom.List = aton.List
	aton.List.Root().Junk( apep.List.Root() )
	return atom
}
// ===========================================================================
func (l *Anda) addList ( atom *list.List ) *Anda {
	var head = l.List.PushBack( l.List.With(atom) )
	atom.Root().Junk( head )	//	:SameAs head.Junk( list.Root() )
	return l
}

func (l *Anda) addAton ( atom *aton.AndaAton ) *Anda {
	var head = l.List.PushBack( l.List.With(atom.List) )
	atom.List.Root().Junk( head )	//	:SameAs head.Junk( list.Root() )
	return l
}

func (l *Anda) addApep ( atom *apep.AndaApep ) *Anda {
	var head = l.List.PushBack( l.List.With(atom.List) )
	atom.List.Root().Junk( head )	//	:SameAs head.Junk( list.Root() )
	return l
}

// ===========================================================================

/* TODO:
AddBeam => AddAton

*/
/*
// ===========================================================================
// AddAton returns a new list with root-value v and new elements with values dots,
// the root of which is Junk'ed to a new PushBack-Element (with same value v) of l
func (l *Anda) AddAton ( v interface{}, vals ...interface{} ) *AndaAton {
	var aton = newAton( v, vals... )
	var head = l.PushBack( l.With(aton.List) )
	aton.List.Root().Junk( head )
	return aton
}

// AddApep add's apeps to l and returns l
func (l *Anda) AddApep ( lists ...AndaApep ) *Anda {
	for _, apep := range lists {
		l.AddList( apep )
		var head = l.List.PushBack( l.With(apep) )
		apep.root.Junk( head )
	}
	return l
}

// AddList adds a new element with value v to list l
// Junk'es it with the list's root
// and returns list (not l) - useful for calculated lists
func (l *AndaAton) AddList ( list *AndaApep ) *AndaApep {
	var head = l.PushBack( l.With(list) )
	list.root.Junk( head )	//	:SameAs head.Junk( list.Root() )

	return list
}
*/

/*
// ===========================================================================
// AddJunk adds Junk'ed pairs of new elements to list l across respective lists
// The new elements carry pointers to both Roots() as Values.
// Thus, they carry their coordinates, so to say.
func (l AndaApep) AddJunk ( v interface{}, lists ...AndaApep) AndaApep {

	var list = list.NewList( v )

	for _, head := range lists {
		vert := head.List.PushBack( head.With(list) )
		hori := list.List.PushBack( list.With(head) )
		vert.Junk( hori )
	}
	return l.addList( list )
}

// AddOnes adds Junk'ed pairs of new elements to list l across respective lists
// The new elements carry no Values. They are light, so to say.
func (l AndaApep) AddOnes ( v interface{}, lists ...AndaApep) AndaApep {

	var list = list.NewList( v )

	for _, head := range lists {
		vert := head.List.PushBack( nil )
		hori := list.List.PushBack( nil )
		vert.Junk( hori )
	}
	return l.addList( list )
}
*/