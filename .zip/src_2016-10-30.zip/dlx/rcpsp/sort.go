﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package rcpsp

import (
	"sort"
)

func TopoSort(m map[TodoID]Todos) Todos {
	var order Todos
	seen := make(map[TodoID]bool)
	var visitAll func(items Todos)
	visitAll = func(items Todos) {
		for _, item := range items {
			if !seen[item] {
				seen[item] = true
				visitAll(m[item])
				order = append(order, item)
			}
		}
	}

	var keys Todos
	for key := range m {
		keys = append(keys, key)
	}

	keys.Sort()
	visitAll(keys)
	return order
}


func (p Todos) Len() int           { return len(p) }
func (p Todos) Less(i, j int) bool { return p[i] < p[j] }
func (p Todos) Swap(i, j int)      { p[i], p[j] = p[j], p[i] }

// Sort is a convenience method.
func (p Todos) Sort() { sort.Sort(p) }
