﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package drummer

import (
	"dlx/anything/normal/drum"
)

type Drums struct {
	Goal *drum.Drum		// Niveaus counts dances per Level
	Dead *drum.Drum		// Deadend counts dead ends per Level
	Call *drum.Drum		// Grooves counts solutions per length
	Leaf *drum.Drum		// UpDates counts unLink per Level
	// Note: No drum for Push & Pop, as these occur in sync with Call
}

func New(cap int, verbose bool) *Drums {
	var d = new(Drums)
	d = d.Init(cap, verbose)
	return d
}

func (d *Drums) Init(cap int, verbose bool) *Drums {
	d.Goal = drum.NewDrum("Grooves", cap)
	d.Dead = drum.NewDrum("Deadend", cap)
	d.Call = drum.NewDrum("Niveaus", cap)
	d.Leaf = drum.NewDrum("UpDates", cap)

	if verbose {	drum.Verbose = true
	} else {	drum.Verbose = false	}

	return d
}

func (d *Drums) Print() {
	if Verbose {
		d.Goal.Print()
		d.Dead.Print()
		d.Call.Print()
		d.Leaf.Print()
	}
}
