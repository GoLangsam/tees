﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dlx

/*

import (
	"reflect"
)

type Point struct {
	row int
	col int
}

func addDimension(dim int, cube interface{}) interface{} {
	t := reflect.TypeOf(cube)
	//	if t.Kind() == reflect.Slice {
	//		t.Elem()

	c := reflect.MakeSlice(t, 0, i)

	return c
}

// NSpace creates a space for Points, which are a struct
// initial capacities are given as slice of int
func NSpace(point interface{}, caps []int) interface{} {
	p := reflect.TypeOf(point)
	k := reflect.Kind(p)

	var c interface{}
	for _, i := range dim {
		c = addDimension(i, c)
	}
	return c
}
*/

func play() {
	/*
	   	type Point interface{}

	   	var dim = 4

	   	var TwoBoard [][]Point

	   	size := [...]int(2,4,4)
	   	dlx.Println(size)

	   	var s = nSpace( size )

	   	dlx.Println(TypeOf(s))

	   	var dll = dll.New()
	   	dlx.Println(dll)

	   //	var dlt = dlt.New()

	   	if false {
	   		dlx.Println(dll)
	   	}
	*/

}
