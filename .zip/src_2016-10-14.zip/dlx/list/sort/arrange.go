﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package sort

import (
	"dlx/list"

	"sort"
)

// Arrange rearranges l
func Arrange(l *list.List) *list.List {

	var sizecol = make(map[int][]*list.Element, l.Len())

	for e := l.Front(); e != nil; e = e.Next() {
		size := 0
		for f := e.AwayList().Front(); f != nil; f = f.Next() {
			size += f.Away().Size()
		}
		sizecol[size] = append(sizecol[size], e)
	}

	var keys sort.IntSlice
	for size, _ := range sizecol {
		keys = append(keys, size)
	}
	keys.Sort()

	var mark *list.Element
	for _, size := range keys {
		for _, e := range sizecol[size] {
			if mark == nil {
				l.MoveToBack(e)
			} else {
				l.MoveBefore(e, mark)
			}
			mark = e
		}
	}
	return l
}
