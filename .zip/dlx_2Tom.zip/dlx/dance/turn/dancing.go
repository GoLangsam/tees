﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package turn

import (
	"dlx/list"
)

type Dancing struct {
	Dance   	func(l *list.List)

	OnGoal		func(l *list.List) 		bool
	OnFail	   	func(l *list.List) (*list.List,	bool)
	OnLeaf		func(l *list.List) 		bool
}

func NewDancing() *Dancing {
	return new( Dancing ).init()
}

func (d *Dancing) init() *Dancing {

	d.Dance		= func(*list.List)			{return}

	d.OnGoal	= func(*list.List) 		bool	{return false}
	d.OnFail	= func(*list.List) (*list.List,	bool)	{return nil, false}
	d.OnLeaf	= func(*list.List) 		bool	{return false}

	return d
}
