﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
dance.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- l.Search ( depth int )
	- l.search ( e, depth )

*/
package list

import (
	"fmt"
)

type solution []*List // Rows


// ========================================================
/*
To choose a column object c, we could simply set
c =: root.Next().Away().List(); this is the leftmost uncovered column.
Or if we want to minimize the branching factor, we could
*/
func (l *List)	ChooseFront () *List {
	c := l.Front().Away().List()
	return c
}

// ========================================================
/*
To choose a column object c, we could simply set
c =: root.Next().Away().List(); this is the leftmost uncovered column.
Or if we want to minimize the branching factor, we could
*/
func (l *List)	ChooseShort () *List {
	var c = NewList( nil )
	s := 999999999
	for j := l.Front(); j != nil; j = j.Next()	{
		list := j.Away().List()
		if list.Len() < s {
			c = list
			s = list.Len()
		}
	}
	fmt.Print( "Short=")
	fmt.Println( s )
	return c
}
func PrintSolution() {
	if stack == nil { return }
	fmt.Println( "Solution: ")
	for _, s := range stack {
		for e := s.Front(); e != nil; e = e.Next() {
			fmt.Print( e.Away().List().Root().Value )
			fmt.Print( " " )
		}
		fmt.Println()
	}
//	fmt.Println( " <=Solution")
}

// ========================================================
func (l *List)	Search ( depth int ) {
//	l.PrintValues( "Cols: " )
//	l.Root().Away().List().PrintValues( "Rows: " )

//	var c = l.Front()
	// If R[h] = h, (no more cols) print the current solution (see below) and return.
//	if c.away.list.root.next == &c.away.list.root {
//	if c.away.list.Len() == 0 {
//	if l.Front() == nil {
//	if l.Root().Away().List().Len() == 0 {
	if l.Len() == 0 && l.Root().Away().List().Len() == 0 {
		PrintSolution()
		return
	} else {
		// Otherwise: choose a column object c
		list := l.Front().Away().List()
		l.search( list, depth )
		return
	}
}

// ========================================================
// search from e, return solution
func (l *List)	search (c *List, depth int ) {
	c.unCover()
	for i := c.root.next; i != &c.root && i != nil; i = i.next	{
		push( i.away.list )
		for j := i.away.list.root.next; j != &i.away.list.root && j != nil; j = j.next	{
	 		if j != i.away {
	 		j.away.list.unCover()
	 		}
		}

		l.Search( depth + 1 )

		i.away.list = pop()	// e = r.Away().column
		for j := i.away.list.root.prev; j != &i.away.list.root && j != nil; j = j.prev	{
	 		if j != i.away {
	 		j.away.list.reCover()
	 		}
		}
	}
	c.reCover()
	return
}

// ========================================================
// unCover is part of DLX-Algoritm
func (l *List) unCover() {
	l.root.away.unLink()
	for i := l.root.next; i != &l.root && i != nil; i = i.next	{
		if l != i.away.list { i.away.list.root.away.unLink() }
	 	for j := i.away.list.root.next; j != &i.away.list.root && j != nil; j = j.next	{
	 		if j != i.away { j.away.unLink() }
		}
	}
}
// reCover is part of DLX-Algoritm
func (l *List) reCover() {
	for i := l.root.prev; i != &l.root && i != nil; i = i.prev	{
		for j := i.away.list.root.prev; j != &i.away.list.root && j != nil; j = j.prev	{
	 		if j != i.away { j.away.reLink() }
			}
		if l != i.away.list { i.away.list.root.away.reLink() }
	}
	l.root.away.reLink()
}

/*
// unCover is part of DLX-Algoritm
func (e *Element) unCover() {
	e.away.unLink()
	for i := e.next; i != e && i != nil; i = i.next	{
//		i.away.unListAway()
		for j := i.away.next; j != i.away && j != nil; j = j.next	{
			j.away.unLink()
		}
	}
}

// reCover is part of DLX-Algoritm
func (e *Element) reCover() {
	for i := e.prev; i != e && i != nil; i = i.prev	{
		i.away.reListAway()
//		for j := i.away.prev; j != i.away && j != nil; j = j.prev	{
//			j.away.reLink()
//		}
	}
	e.away.reLink()
}
*/

/*
// ========================================================
// unListAway unLink's the away's along an element's list
func (e *Element) unListAway() {
	for i := e.next; i != e && i != nil; i = i.next	{
		i.away.unLink()
	}
}

// reListAway reLink's the away's along an element's list
func (e *Element) reListAway() {
	for i := e.prev; i != e && i != nil; i = i.prev	{
		i.away.unLink()
	}
}
*/