﻿// Copyright 2013 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package list_test

import (
	"dlx/list"
)

func ExampleTimes() {
	// Create a new list
	var chess = list.NewList( "Chess" )

	var rows = chess.AddBeam( "Zeilen", 1, 2, 3, 4, 5, 6, 7, 8 )
	var cols = chess.AddBeam( "Spalten", "A", "B", "C", "D", "E", "F", "G", "H" )
	var game = chess.AddBeam( "Partien", "Fischer / Kasparski", "John / Doe", "Foo / Bar")

	chess.Print( "Starting" )
	chess.PrintValues()
	for e := chess.Front(); e != nil; e = e.Next() {
		e.PrintAways( "Lists in Root: " )
	}

	chess.AddList( "Row * Col * Game", rows.Times( cols, game ) )
	chess.AddList( "Game * ( Row * Col )", game.Times( cols.Times( rows ) ) )

	chess.Print( "Growing" )
	chess.PrintValues()

	// Output:
	// [Starting]List=Chess | Total=3
	// List=Chess
	// Zeilen | Spalten | Partien | Total=3
	// [Lists in Root: ]List=Zeilen
	// 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | Total=8
	// [Lists in Root: ]List=Spalten
	// A | B | C | D | E | F | G | H | Total=8
	// [Lists in Root: ]List=Partien
	// Fischer / Kasparski | John / Doe | Foo / Bar | Total=3
	// [Growing]List=Chess | Total=5
	// List=Chess
	// Zeilen | Spalten | Partien | Row * Col * Game | Game * ( Row * Col ) | Total=5

}
