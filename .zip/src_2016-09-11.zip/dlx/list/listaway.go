﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
listaway.go extends the (stolen and extended) list.go
with stuff, which is considered useful and helpfull, such as:

	- e.Away()		*Element
	- e.Junk (x *Element)	// cross-links Away's
	- e.unCover()
	- e.reCover()
	- e.unListAway()
	- e.reListAway()

	- l.Away()		*Element
	- l.AddBeam
	- l.AddList
	- l.AddOnes

*/
package list

// Away returns the away element (an element of the orthogonal fiber-list)
func (l *List) Away() *Element {
	return l.root.away
}

// Away returns the away element (an element of the orthogonal fiber-list)
func (e *Element) Away() *Element {
	return e.away
}

// SetAway sets the away (an element of the orthogonal fiber-list)
// If e == mark or e and mark are element of the same list, the element is not modified.
// NOTE: only any new List's list-Element points to itself!
/* Is this needed by the outer world?
func (e *Element) SetAway(away *Element) {
	if e == away || e.list == away.list {
		return
	}
	e.away = away
}
*/

// Junk links another element as a mutual Junc-tion of their Away's
func (e *Element) Junk (x *Element) {
	if e.away != nil {panic("away in e already set!")}
	if x.away != nil {panic("away in x already set!")}
	x.away = e
	e.away = x
}



// AddBeam returns a new list with root-value v and new elements with values dots,
// the root of which is Junk'ed to a new PushBack-Element (with same value v) of l
func (l *List) AddBeam ( v interface{}, dots... interface{} ) *List {

	var list = NewList( v )
	list.ValuesPushBack( dots... )

	return l.AddList( v, list )
}

// AddList adds a new element with value v to list l and Junk'es it with the list's root
func (l *List) AddList ( v interface{}, list *List ) *List {

	var head = l.PushBack( v )
	list.root.Junk( head )	//	:SameAs head.Junk( list.Root() )

	return list
}

// AddOnes adds Junk'ed pairs of new elements to list respective l
func (l *List) AddOnes ( v interface{}, lists... *List) *List {

	var list = NewList( v )

	for _, head := range lists {
		vert := head.PushBack( nil )
		hori := list.PushBack( nil )
		vert.Junk( hori )
	}
	return l.AddList( v, list )
}

