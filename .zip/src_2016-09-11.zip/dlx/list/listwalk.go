﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*

// GoTo is an alias for a kind of function to StepTo another existing element (or nil) from some element e
// StepTo returns the *Element (or nil) reached from e by applying a single GoTo
// Step returns the *Element (or nil) reached from e by StepTo GoTo's
// Jump returns the *Element (or nil) reached from e by JumpTo Jump's (= []GoTo's)
// Walk returns the slice of *Element (or nil) reached from e through each of it's Jump's

*/
package list

// GoTo's represent basic functions to Step from some element to another existing element (or nil)
type GoTo uint8	// func( *Element ) *Element

const (
	Prev	GoTo = iota
	Next
	Away
	Root
	Head
	Tail
)

// StepTo returns the Element (or nil) reached from e by applying a GoTo
func (e *Element) StepTo ( g GoTo ) *Element {
	switch g {
	case Prev:	return e.Prev()
	case Next:	return e.Next()
	case Away:	return e.Away()
	case Root:	return e.List().Root()
	case Head:	return e.List().Front()
	case Tail:	return e.List().Back()
	default:	panic( "Undefined value for GoTo" )
	}
}

// Step returns the Element (or nil) reached from e by applying GoTo's
func (e *Element) Step ( gotos... GoTo ) *Element {
	goal := e
	for _, step := range gotos {
		goal = goal.StepTo( step )
		if goal == nil { break }
	}
	return goal
}

// Jump returns the Element (or nil) reached from e by a slice of GoTo's
func (e *Element) Jump ( jumps... []GoTo ) *Element {
	goal := e
	for _, steps := range jumps {
		for _, step := range steps {
			goal = goal.Step( step )
			if goal == nil { break }
		}
		if goal == nil { break }
	}
	return goal
}

// Walk returns the Elements (or nil) reached from e by applying Jump's
func (e *Element) Walk ( jumps... []GoTo ) []*Element {
	goal := e
	goals := make([]*Element, 0, len(jumps))
	for _, jump := range jumps {
		goal = goal.Jump( jump )
		if goal == nil { break }
		goals = append(goals, goal)
	}
	return goals
}


// For Your convenience: Some predefined Jump's:
// for the basic GoTo's
	var JumpPrev	= []GoTo{ Prev }
	var JumpNext	= []GoTo{ Next }
	var JumpAway	= []GoTo{ Away }
	var JumpRoot	= []GoTo{ Root }
	var JumpHead	= []GoTo{ Head }
	var JumpTail	= []GoTo{ Tail }

// for composed movement
// Orthogonal
	var JumpAwayPrev	= []GoTo{ Away, Prev, Away }			//	= Up
	var JumpAwayNext	= []GoTo{ Away, Next, Away }			//	= Down
// Hint: Think of a right-hand matrix, look at a horizontal element
	var JumpUp		= JumpAwayPrev
	var JumpDown		= JumpAwayNext
// Diagonal
	var JumpRightUp		= []GoTo{ Next, Away, Prev, Away }		//	= Next, AwayPrev
	var JumpRightDown	= []GoTo{ Next, Away, Next, Away }		//	= Next, AwayNext
	var JumpLeftUp		= []GoTo{ Prev, Away, Prev, Away }		//	= Prev, AwayPrev
	var JumpLeftDown	= []GoTo{ Prev, Away, Next, Away }		//	= Prev, AwayPrev
// next/prev orthogonal fiber
	var JumpNextHead	= []GoTo{ Root, Away, Next, Away, Head }
	var JumpNextTail	= []GoTo{ Root, Away, Next, Away, Tail }
	var JumpPrevHead	= []GoTo{ Root, Away, Prev, Away, Head }
	var JumpPrevTail	= []GoTo{ Root, Away, Prev, Away, Tail }

// a chess-horse
	var JumpHorseNNU	= []GoTo{ Next, Next, Away, Prev, Away }	//	= Next, RightUp
	var JumpHorseNND	= []GoTo{ Next, Next, Away, Next, Away }	//	= Next, RightDown
	var JumpHorsePPU	= []GoTo{ Prev, Prev, Away, Prev, Away }	//	= Next, RightUp
	var JumpHorsePPD	= []GoTo{ Prev, Prev, Away, Next, Away }	//	= Next, RightDown
	var JumpHorseUUP	= []GoTo{ Away, Prev, Prev, Away, Prev }	//
	var JumpHorseUUN	= []GoTo{ Away, Prev, Prev, Away, Next }	//
	var JumpHorseDDP	= []GoTo{ Away, Next, Next, Away, Prev }	//
	var JumpHorseDDN	= []GoTo{ Away, Next, Next, Away, Next }	//

