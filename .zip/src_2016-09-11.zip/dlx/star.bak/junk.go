﻿// Copyright 2016 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package star

import (
	"fmt"
)

// AddJunk is for stuff which
func (big *Bang) AddJunk (v interface{}, dots... interface{} ) *Star {

	panic( "We do not know (yet) what this means!" )
// This might become useful for (Junk'ed) Stars of dust & dirt ...
}

// Can Dust be dirty? No (it only can settle ... thus, sth becomes dusty)
// Can Dirt be dusty? Yes!
// - A dusty pile-of-shit is still shit ;-)
// - A pile of gold ain't (smell) dirty, even if dusty (Well, money dosn't have bad smell - anyway / "Pecunia non olet")
// Thus, Dust is below Dirt / Dirt is above Dust


// AddDirt is for stuff which
// - You distinguish (by "Token"'s such as "shit", "mud", 4711, anotherBigBang )
// - You may like to find again later using the Token
func (big *Bang) AddDirt (v interface{}, dots... interface{} ) *Star {

// NOTE: Keep a map[interface{}]*Spot or *Star

	return big.addDots( v, dots... )
}

// AddDust is for stuff which
// - You do not care about,
// - You do not distinguish, and
// - You do not need to find again (by "Token")
func (big *Bang) AddDust (v interface{}, dots... interface{} ) *Star {
	return big.addDots( v, dots... )
}

func (big *Bang) addDots (v interface{}, dots... interface{} ) *Star {

	var dirt = bang( v )			// the root of the new list List() with the dots

	for _, dot := range dots {
		dirt.List().PushBack( dot )
	}

	var dust = big.bang.PushBack( dirt )	// element added to big as new dimension

	fmt.Println("dust")			// dust is in dimension list, orthogonal is
	fmt.Println( dirt )			// dirt is the list of elements in this dimension "dust"
						// dots are not(yet) orthogonal to anything
	return big.Junk(dust, dirt)
}
